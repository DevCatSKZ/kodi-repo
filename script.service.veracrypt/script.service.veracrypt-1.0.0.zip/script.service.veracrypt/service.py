"""VeraCrypt Manager - Kodi background service.

Startup:  run the configured auto-mount policy (master-password prompt
          once, external/local keyfile unattended, or nothing).
          If unlocked successfully the vault stays locked afterwards -
          secrets are only pulled per mount.
Monitor:  unmounts all addon-managed volumes on Kodi shutdown /
          system sleep so no dm/loop mounts are left behind.
"""

import os
import sys
import threading
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lib import kodifrontend as K  # noqa: E402

import xbmc  # noqa: E402

from vcaddon import automount, log  # noqa: E402
from vcaddon.errors import VCError  # noqa: E402


def _master_prompt():
    return K.ask_password(K.L(32114))


def _boot_automount(mgr):
    settings = K.sync_settings(mgr)
    if not settings.automount:
        return
    profiles = mgr.profiles.auto_mount_profiles()
    if not profiles:
        return
    if settings.vault_unlock == "prompt" and not settings.prompt_at_start:
        return
    if settings.vault_unlock == "prompt":
        if not K.yesno(K.L(32142)):
            return
        callback = _master_prompt
    else:
        callback = None

    res = automount.run_boot(mgr, settings, unlock_callback=callback)
    if res.mounted or res.failed:
        K.notify(K.L(32141) % (len(res.mounted), len(res.failed)))
    log.info("boot automount: %s" % res.message)


def main():
    try:
        mgr = K.get_manager()
    except Exception as exc:
        log.error("cannot init manager: %s" % exc)
        K.notify("vcaddon init failed")
        return

    # make the runtime usable before any mount (exec bits, kernel
    # modules, /usr/sbin helper overlay)
    try:
        K.ensure_runtime(K.resolve_runtime_dir())
    except Exception as exc:
        log.warn("runtime setup failed: %s" % exc)

    # preflight once; warn but keep running (user may install deps later)
    try:
        rep = mgr.preflight()
        if not rep.ok:
            log.warn("preflight failed:\n%s" % rep.render())
            K.notify(K.L(32133), time_ms=8000)
    except Exception as exc:
        log.warn("preflight error: %s" % exc)

    threading.Thread(target=_boot_automount, args=(mgr,),
                     daemon=True).start()

    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        if monitor.waitForAbort(2.0):
            break

    log.info("service stopping - unmounting managed volumes")
    try:
        failures = mgr.shutdown()
        if failures:
            for f in failures:
                log.warn("unmount failed: %s" % f)
        else:
            log.info(K.L(32143))
    except Exception as exc:
        log.error("shutdown unmount error: %s" % exc)


if __name__ == "__main__":
    main()
