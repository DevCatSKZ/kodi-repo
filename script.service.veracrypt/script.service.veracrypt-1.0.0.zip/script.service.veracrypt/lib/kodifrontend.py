"""Kodi frontend glue shared by service.py and default.py.

Bootstraps sys.path for the vendored vcaddon package
(resources/lib/vcaddon) and provides Kodi UI helpers.
"""

import os
import platform
import shutil
import subprocess
import sys

import xbmc
import xbmcaddon
import xbmcgui


def xbmcvfs_translate(p):
    try:
        import xbmcvfs
        return xbmcvfs.translatePath(p)
    except Exception:
        return p


ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_NAME = ADDON.getAddonInfo("name")
ADDON_PATH = xbmcvfs_translate(ADDON.getAddonInfo("path"))
PROFILE_PATH = xbmcvfs_translate(ADDON.getAddonInfo("profile"))

_LIB = os.path.join(ADDON_PATH, "resources", "lib")
if _LIB not in sys.path:
    sys.path.insert(0, _LIB)


def xbmcvfs_translate(p):
    try:
        import xbmcvfs
        return xbmcvfs.translatePath(p)
    except Exception:
        return p


def L(sid):
    return ADDON.getLocalizedString(sid)


def runtime_arch():
    """Bundled runtime arch: aarch64 (RPi4/5) or armhf (RPi1/2/3).

    The armhf bundle uses the VeraCrypt 1.26.18 Raspbian build; it is
    the last release VeraCrypt shipped for 32-bit ARM.
    """
    return ("aarch64" if platform.machine().lower()
            in ("aarch64", "arm64") else "armhf")


def bundled_runtime_dir():
    return os.path.join(ADDON_PATH, "resources", "runtime",
                        runtime_arch())


def resolve_runtime_dir():
    """Writable runtime dir holding bin/veracrypt (+ lib/, sysbin/).

    If the configured dir lacks the binary but the addon ships a
    bundled runtime, copy it over (addons live on writable /storage).
    """
    runtime_dir = (ADDON.getSetting("runtime_dir")
                   or "/storage/veracrypt")
    if not os.path.isfile(os.path.join(runtime_dir, "bin", "veracrypt")):
        bundled = bundled_runtime_dir()
        if os.path.isfile(os.path.join(bundled, "bin", "veracrypt")):
            try:
                shutil.copytree(bundled, runtime_dir, dirs_exist_ok=True)
            except OSError:
                return bundled
    return runtime_dir


def runtime_env(runtime_dir):
    """Extra env for the veracrypt process tree on LibreELEC.

    runtime_dir holds the private deployment (bin/, lib/) because
    LibreELEC's /usr is read-only. The DM_UDEV_DISABLE_* flags stop
    libdevmapper from waiting on udev cookies that never complete on
    LE's minimal udev setup (dmsetup would otherwise hang).
    """
    env = {}
    if runtime_dir:
        b = os.path.join(runtime_dir, "bin")
        l = os.path.join(runtime_dir, "lib")
        if os.path.isdir(b):
            env["PATH"] = b + os.pathsep + os.environ.get("PATH", "")
        if os.path.isdir(l):
            prev = os.environ.get("LD_LIBRARY_PATH", "")
            env["LD_LIBRARY_PATH"] = (l + os.pathsep + prev
                                      if prev else l)
        env["DM_UDEV_DISABLE_SYNC_FLAG"] = "1"
        env["DM_UDEV_DISABLE_OTHER_RULES_FLAG"] = "1"
        env["DM_UDEV_DISABLE_SUBSYSTEM_RULES_FLAG"] = "1"
    return env


def ensure_runtime(runtime_dir):
    """Prepare the runtime before first use (idempotent).

    Zip installs drop exec bits; the overlay makes helpers visible in
    veracrypt's fixed search dirs; modprobe is a no-op when built-in.
    """
    for d in (os.path.join(runtime_dir, "bin"),
              os.path.join(runtime_dir, "sysbin")):
        if os.path.isdir(d):
            for f in os.listdir(d):
                try:
                    os.chmod(os.path.join(d, f), 0o755)
                except OSError:
                    pass
    for mod in ("dm_mod", "dm-mod", "loop", "fuse"):
        try:
            subprocess.call(["modprobe", mod], stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL, timeout=10)
        except (OSError, subprocess.TimeoutExpired):
            pass
    script = os.path.join(ADDON_PATH, "resources", "bin",
                          "setup-overlay.sh")
    if os.path.isfile(script):
        try:
            os.chmod(script, 0o755)
            subprocess.call(["/bin/sh", script, runtime_dir],
                            stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL, timeout=30)
        except (OSError, subprocess.TimeoutExpired):
            pass


def get_manager():
    """Build a vcaddon Manager configured from Kodi addon settings."""
    from vcaddon import log
    from vcaddon.manager import Config, Manager

    mount_root = ADDON.getSetting("mount_root") or "/media/veracrypt"
    runtime_dir = resolve_runtime_dir()
    binary = ADDON.getSetting("veracrypt_binary") or ""
    if not binary:
        cand = os.path.join(runtime_dir, "bin", "veracrypt")
        if os.path.isfile(cand):
            binary = cand
    kc_sel = ADDON.getSetting("kernel_crypto") or "auto"
    kernel_crypto = {"auto": "auto", "on": True, "off": False}.get(
        kc_sel, "auto")
    cfg = Config(data_dir=PROFILE_PATH, mount_root=mount_root,
                 veracrypt_binary=binary or None,
                 env=runtime_env(runtime_dir),
                 kernel_crypto=kernel_crypto)
    level = ADDON.getSetting("log_level")
    log.set_verbose(level == "2")

    def kodi_log(level_, msg):
        lvl = {"DEBUG": xbmc.LOGDEBUG, "INFO": xbmc.LOGINFO,
               "WARN": xbmc.LOGWARNING, "ERROR": xbmc.LOGERROR}.get(
            level_, xbmc.LOGINFO)
        xbmc.log("vcaddon: %s" % msg, lvl)
    log.set_bridge(kodi_log)
    return Manager(cfg)


def sync_settings(mgr):
    """Mirror relevant Kodi settings into the core settings file."""
    from vcaddon.settings import Settings
    s = Settings.load(mgr.cfg.settings_path)
    s.automount = ADDON.getSettingBool("automount")
    s.vault_unlock = ADDON.getSetting("vault_unlock") or "prompt"
    s.keyfile_path = ADDON.getSetting("keyfile_path") or ""
    s.prompt_at_start = ADDON.getSettingBool("prompt_at_start")
    try:
        s.mount_retries = int(ADDON.getSetting("mount_retries") or 1)
    except ValueError:
        s.mount_retries = 1
    s.default_read_only = ADDON.getSettingBool("default_read_only")
    s.save(mgr.cfg.settings_path)
    return s


def ask_text(heading, default="", hidden=False):
    kb = xbmc.Keyboard(default, heading, hidden)
    kb.doModal()
    if kb.isConfirmed():
        t = kb.getText()
        return t if t != "" else None
    return None


def ask_password(heading):
    return ask_text(heading, hidden=True)


def notify(msg, icon=None, time_ms=4000):
    try:
        xbmcgui.Dialog().notification(ADDON_NAME, msg,
                                      icon or ADDON.getAddonInfo("icon"),
                                      time_ms)
    except Exception:
        pass


def ok_dialog(msg):
    xbmcgui.Dialog().ok(ADDON_NAME, msg)


def yesno(msg):
    return xbmcgui.Dialog().yesno(ADDON_NAME, msg)


def select(heading, items):
    return xbmcgui.Dialog().select(heading, items)


def progress_dialog():
    return xbmcgui.DialogProgress()
