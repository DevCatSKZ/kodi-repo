"""VeraCrypt Manager - Kodi program entry point (menu UI)."""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lib import kodifrontend as K  # noqa: E402

from vcaddon import devices  # noqa: E402
from vcaddon.errors import AuthFailed, VCError  # noqa: E402
from vcaddon.profiles import Profile  # noqa: E402
from vcaddon.secrets import Secret  # noqa: E402
from vcaddon.veracrypt_cli import MountSecrets  # noqa: E402
from vcaddon import vault as vault_mod  # noqa: E402


def _secrets_interactive(profile):
    sec = MountSecrets()
    pw = K.ask_password(K.L(32110))
    if pw is None:
        return None
    sec.password = Secret.from_text(pw)
    if profile.has_pim:
        pim = K.ask_password(K.L(32111))
        sec.pim = Secret.from_text(pim or "")
    if profile.protect_hidden:
        hpw = K.ask_password(K.L(32112))
        if hpw is None:
            return None
        sec.hidden_password = Secret.from_text(hpw)
        hpim = K.ask_password(K.L(32113))
        sec.hidden_pim = Secret.from_text(hpim or "")
    return sec


def _unlock_vault(mgr):
    """Try keyfile slots then master passphrase. Returns Vault or None."""
    v = mgr.vault()
    if not v.exists() or not v.slot_ids():
        return None
    for sid in v.slot_ids():
        pass  # keyfile auto-try happens via settings in automount
    # try local keyfile first (if user configured it)
    local = os.path.join(mgr.cfg.data_dir, "local-vault.key")
    if os.path.isfile(local):
        try:
            if v.unlock_with_keyfile(vault_mod.read_keyfile(local)):
                return v
        except VCError:
            pass
    pw = K.ask_password(K.L(32114))
    if pw is None:
        return None
    try:
        if v.unlock_with_passphrase(pw):
            return v
    finally:
        pw = None
    K.ok_dialog(K.L(32137))
    return None


def _store_secrets(mgr, profile, sec=None):
    v = mgr.vault()
    if not v.unlocked:
        if not v.exists() or not v.slot_ids():
            K.ok_dialog(K.L(32135))
            p1 = K.ask_password(K.L(32115))
            if not p1:
                return False
            p2 = K.ask_password(K.L(32116))
            if p1 != p2:
                K.ok_dialog(K.L(32136))
                return False
            v.add_passphrase_slot("master", p1)
            p1 = p2 = None
            if not v.unlock_with_passphrase(K.ask_password(K.L(32114)) or ""):
                K.ok_dialog(K.L(32137))
                return False
        else:
            v = _unlock_vault(mgr)
            if v is None:
                return False
    if sec is None:
        sec = _secrets_interactive(profile)
        if sec is None:
            return False
    try:
        v.set_secret(profile.id, {
            "password": sec.password.text(),
            "pim": sec.pim.text(),
            "hidden_password": sec.hidden_password.text(),
            "hidden_pim": sec.hidden_pim.text(),
            "token_pin": sec.token_pin.text(),
            "hidden_keyfiles": list(sec.hidden_keyfiles)})
        profile.store_secrets = True
        mgr.profiles.update(profile)
        return True
    finally:
        v.lock()


def _profile_from_device(dev):
    sid = dev.stable_id()
    if not sid:
        K.ok_dialog("no stable identity for %s" % dev.path)
        return None
    p = Profile(source_type="device", identity=sid,
                label=dev.label or dev.path)
    return p


def _mount_profile(mgr, p):
    # options
    ro_default = K.ADDON.getSettingBool("default_read_only")
    p.read_only = ro_default
    if K.yesno(K.L(32117)):
        if K.yesno(K.L(32149)):
            p.read_only = False
            if K.yesno(K.L(32118)):
                p.protect_hidden = True
    if K.yesno(K.L(32140)):
        p.has_pim = True

    secrets = None
    v = None
    if p.store_secrets:
        v = _unlock_vault(mgr)
        if v is not None:
            secrets = mgr.secrets_from_vault(v, p)
    if secrets is None:
        secrets = _secrets_interactive(p)
    try:
        if secrets is None:
            return
        if K.yesno(K.L(32120)):
            if _store_secrets(mgr, p, secrets):
                if K.yesno(K.L(32121)):
                    p.auto_mount = True
                    mgr.profiles.update(p)
                    K.ADDON.setSetting("automount", "true")
        rec = mgr.mount(p, secrets)
        K.notify(K.L(32124) % rec.mount_point)
    except AuthFailed:
        K.ok_dialog(K.L(32122))
    except VCError as exc:
        K.ok_dialog("%s: %s" % (K.L(32123), exc))
    finally:
        if secrets:
            secrets.wipe()
        if v is not None:
            v.lock()


def menu_mount(mgr):
    profiles = mgr.profiles.all()
    devs = devices.candidates()
    labels, objs = [], []
    for p in profiles:
        labels.append("[PROFILE] %s" % (p.label or p.id))
        objs.append(("profile", p))
    for d in devs:
        tag = K.L(32146) if d.looks_encrypted else (
            K.L(32147) if d.fstype else "?")
        labels.append("%s  %s  [%s]" % (d.path, d.size_h(), tag))
        objs.append(("device", d))
    labels.append(K.L(32132) + "...")
    objs.append(("container", None))
    idx = K.select(K.L(32119), labels)
    if idx < 0:
        return
    kind, obj = objs[idx]
    if kind == "profile":
        _mount_profile(mgr, obj)
    elif kind == "device":
        p = _profile_from_device(obj)
        if p:
            _mount_profile(mgr, p)
    else:
        path = K.xbmcgui.Dialog().browse(
            1, K.L(32139), "files", mask=".hc|.tc|.vc|")
        if path:
            p = Profile(source_type="container", identity=path,
                        label=os.path.basename(path))
            try:
                p.validate()
            except VCError as exc:
                K.ok_dialog(str(exc))
                return
            _mount_profile(mgr, p)


def menu_unmount(mgr):
    rows = mgr.status()
    if not rows:
        K.ok_dialog(K.L(32134))
        return
    labels = ["%s -> %s%s" % (r.get("volume", "?"),
                              r.get("mount_point", "?"),
                              " (ro)" if r.get("read_only") else "")
              for r in rows]
    idx = K.select(K.L(32102), labels)
    if idx < 0:
        return
    try:
        mgr.unmount(rows[idx]["mount_point"])
        K.notify(K.L(32125))
    except VCError as exc:
        K.ok_dialog("%s: %s" % (K.L(32148), exc))


def menu_status(mgr):
    rows = mgr.status()
    if not rows:
        K.ok_dialog(K.L(32134))
        return
    text = "\n".join(
        "%s -> %s%s%s" % (r.get("volume", "?"), r.get("mount_point", "?"),
                          " [ro]" if r.get("read_only") else " [rw]",
                          " (managed)" if r.get("managed") else "")
        for r in rows)
    K.xbmcgui.Dialog().textviewer(K.L(32104), text)


def menu_scan(mgr):
    devs = devices.enumerate_devices()
    lines = [K.L(32144), ""]
    for d in devs:
        if d.is_system:
            continue
        lines.append("%s  %s  fs=%s%s" % (
            d.path, d.size_h(), d.fstype or "-",
            "  SYSTEM" if d.is_system else ""))
    K.xbmcgui.Dialog().textviewer(K.L(32105), "\n".join(lines))


def menu_profiles(mgr):
    while True:
        items = [K.L(32127), K.L(32128), K.L(32129), K.L(32130)]
        for p in mgr.profiles.all():
            items.append("%s  [%s%s]" % (
                p.label or p.id,
                "auto " if p.auto_mount else "",
                "secrets" if p.store_secrets else "prompt"))
        idx = K.select(K.L(32106), items)
        if idx < 0:
            return
        if idx == 0:
            menu_mount(mgr)          # adding happens through mount flow
        elif idx == 1:
            p = _pick_profile(mgr, K.L(32128))
            if p:
                mgr.profiles.remove(p.id)
        elif idx == 2:
            p = _pick_profile(mgr, K.L(32129))
            if p:
                _store_secrets(mgr, p)
        elif idx == 3:
            p = _pick_profile(mgr, K.L(32130))
            if p:
                v = _unlock_vault(mgr)
                if v:
                    v.remove_secret(p.id)
                    v.lock()
                p.store_secrets = False
                p.auto_mount = False
                mgr.profiles.update(p)
        else:
            return


def _pick_profile(mgr, heading):
    ps = mgr.profiles.all()
    if not ps:
        K.ok_dialog(K.L(32126))
        return None
    idx = K.select(heading, [p.label or p.id for p in ps])
    return ps[idx] if idx >= 0 else None


def menu_vault(mgr):
    items = ["status", "init master passphrase", "add keyfile slot",
             "add LOCAL keyfile (weaker)", "slots"]
    idx = K.select(K.L(32107), items)
    v = mgr.vault()
    if idx == 0:
        K.ok_dialog("exists=%s slots=%s" % (v.exists(),
                                          ", ".join(v.slot_ids()) or "-"))
    elif idx == 1:
        p1 = K.ask_password(K.L(32115))
        p2 = K.ask_password(K.L(32116)) if p1 else None
        if p1 and p1 == p2:
            v.add_passphrase_slot("master", p1)
            K.notify("vault ready")
        elif p1:
            K.ok_dialog(K.L(32136))
    elif idx == 2:
        path = K.xbmcgui.Dialog().browse(1, "keyfile", "files")
        v2 = _unlock_vault(mgr)
        if path and v2:
            try:
                v2.add_keyfile_slot("keyfile", vault_mod.read_keyfile(path))
            finally:
                v2.lock()
    elif idx == 3:
        if not K.yesno(K.L(32138)):
            return
        v2 = _unlock_vault(mgr)
        if v2:
            key = vault_mod.generate_keyfile(
                os.path.join(mgr.cfg.data_dir, "local-vault.key"))
            v2.add_keyfile_slot("local-keyfile", key)
            v2.lock()
            K.ADDON.setSetting("vault_unlock", "local-keyfile")
            K.notify("local keyfile slot added")
    elif idx == 4:
        K.ok_dialog(", ".join(v.slot_ids()) or "-")


def menu_preflight(mgr):
    rep = mgr.preflight()
    K.xbmcgui.Dialog().textviewer(K.L(32109), rep.render())


def main():
    mgr = K.get_manager()
    K.sync_settings(mgr)
    while True:
        idx = K.select(K.L(32100), [
            K.L(32101), K.L(32102), K.L(32103), K.L(32104),
            K.L(32105), K.L(32106), K.L(32107), K.L(32109),
        ])
        if idx < 0:
            return
        if idx == 0:
            menu_mount(mgr)
        elif idx == 1:
            menu_unmount(mgr)
        elif idx == 2:
            failures = mgr.unmount_all()
            if failures:
                K.ok_dialog("\n".join(failures))
            else:
                K.notify(K.L(32125))
        elif idx == 3:
            menu_status(mgr)
        elif idx == 4:
            menu_scan(mgr)
        elif idx == 5:
            menu_profiles(mgr)
        elif idx == 6:
            menu_vault(mgr)
        elif idx == 7:
            menu_preflight(mgr)


if __name__ == "__main__":
    main()
