"""Encrypted credential vault.

Layout (JSON file, mode 0600)::

    {
      "version": 1,
      "slots": [
        {"id": "master", "kind": "passphrase",
         "kdf": {"name": "scrypt", "salt": b64, "n": 32768, "r": 8, "p": 1},
         "nonce": b64, "wrapped": b64},          # AES-GCM(DEK) under KEK
        {"id": "usb-key", "kind": "keyfile",
         "kdf": {"name": "keyfile-sha256", "salt": b64},
         "nonce": b64, "wrapped": b64}
      ],
      "cipher": {"name": "aes-256-gcm", "nonce": b64},
      "data": b64                                  # AES-GCM(JSON) under DEK
    }

A random 256-bit DEK encrypts the payload; every slot wraps the DEK
under a key derived from that slot's secret. So a vault can be opened
either by master passphrase or by an external keyfile (unattended boot
with a USB-kept key) or a local keyfile (convenience, weaker).

Payload JSON::

    {"profiles": {"<profile_id>": {"password": b64, "pim": b64,
                   "hidden_password": b64, "hidden_pim": b64,
                   "token_pin": b64, "hidden_keyfiles": [...]}}}
"""

import base64
import hashlib
import hmac
import json
import os
import secrets as _secrets
import stat

from .crypto_fallback import get_aesgcm
from .errors import VaultError, VaultLocked

VAULT_VERSION = 1
SCRYPT_N = 1 << 15          # ~32 MiB; fine on a 1-2 GiB Pi
SCRYPT_R, SCRYPT_P = 8, 1
PBKDF2_ITER = 600_000
MAX_SECRET_LEN = 4096

_AEAD = None


def _aead(key):
    global _AEAD
    if _AEAD is None:
        _AEAD = get_aesgcm()
    return _AEAD(key)


def _b64e(b):
    return base64.b64encode(b).decode("ascii")


def _b64d(s):
    return base64.b64decode(s.encode("ascii"))


def _derive_passphrase(passphrase, kdf):
    pw = passphrase.encode("utf-8")
    salt = _b64d(kdf["salt"])
    if kdf["name"] == "scrypt":
        try:
            return hashlib.scrypt(pw, salt=salt, n=kdf["n"], r=kdf["r"],
                                  p=kdf["p"], dklen=32,
                                  maxmem=256 * 1024 * 1024)
        except (ValueError, NotImplementedError, AttributeError):
            # fall through to pbkdf2 if scrypt unusable
            return hashlib.pbkdf2_hmac(
                "sha256", pw, b"scrypt-fallback:" + salt,
                PBKDF2_ITER, dklen=32)
    if kdf["name"] == "pbkdf2-sha256":
        return hashlib.pbkdf2_hmac("sha256", pw, salt,
                                   kdf["iterations"], dklen=32)
    raise VaultError("unsupported kdf %r" % kdf["name"])


def _new_passphrase_kdf():
    try:
        hashlib.scrypt(b"x", salt=b"y" * 16, n=SCRYPT_N, r=SCRYPT_R,
                       p=SCRYPT_P, dklen=32, maxmem=256 * 1024 * 1024)
        return {"name": "scrypt", "salt": _b64e(_secrets.token_bytes(16)),
                "n": SCRYPT_N, "r": SCRYPT_R, "p": SCRYPT_P}
    except (ValueError, NotImplementedError, AttributeError):
        return {"name": "pbkdf2-sha256",
                "salt": _b64e(_secrets.token_bytes(16)),
                "iterations": PBKDF2_ITER}


def _derive_keyfile(key_bytes, kdf):
    return hashlib.sha256(
        b"vcaddon-keyfile-v1:" + _b64d(kdf["salt"]) + key_bytes).digest()


def _new_keyfile_kdf():
    return {"name": "keyfile-sha256",
            "salt": _b64e(_secrets.token_bytes(16))}


def _wrap(kek, dek):
    nonce = _secrets.token_bytes(12)
    return _b64e(nonce), _b64e(_aead(kek).encrypt(nonce, dek, b"vc-slot"))


def _unwrap(kek, nonce_b64, wrapped_b64):
    nonce = _b64d(nonce_b64)
    try:
        return _aead(kek).decrypt(nonce, _b64d(wrapped_b64), b"vc-slot")
    except Exception:
        return None


def _write_0600(path, text):
    tmp = path + ".tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        os.write(fd, text.encode("utf-8"))
        os.fsync(fd)
    finally:
        os.close(fd)
    os.replace(tmp, path)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def check_perms(path):
    """Return warning text if the vault file is group/world readable."""
    try:
        mode = stat.S_IMODE(os.stat(path).st_mode)
    except OSError:
        return None
    if mode & 0o077:
        return "vault file %s has loose permissions %04o" % (path, mode)
    return None


class Vault:
    def __init__(self, path):
        self.path = path
        self._doc = None          # on-disk structure
        self._dek = None          # bytearray while unlocked
        self._payload = None      # decrypted dict while unlocked

    # -- file ---------------------------------------------------------------
    def exists(self):
        return os.path.exists(self.path)

    def load(self):
        if not self.exists():
            self._doc = {"version": VAULT_VERSION, "slots": [],
                         "cipher": {"name": "aes-256-gcm", "nonce": ""},
                         "data": ""}
            return
        try:
            with open(self.path, "r", encoding="utf-8") as fh:
                doc = json.load(fh)
        except ValueError as exc:
            raise VaultError("vault file %s is corrupt: %s"
                             % (self.path, exc))
        if not isinstance(doc, dict):
            raise VaultError("vault file %s is not a JSON object"
                             % self.path)
        if doc.get("version", 0) > VAULT_VERSION:
            raise VaultError("vault version %d newer than supported %d"
                             % (doc["version"], VAULT_VERSION))
        doc.setdefault("slots", [])
        self._doc = doc

    def save(self):
        if self._dek is None or self._payload is None:
            raise VaultLocked("vault not unlocked; nothing to save")
        nonce = _secrets.token_bytes(12)
        blob = json.dumps(self._payload, separators=(",", ":")).encode()
        enc = _aead(bytes(self._dek)).encrypt(nonce, blob, b"vc-data")
        self._doc["cipher"] = {"name": "aes-256-gcm", "nonce": _b64e(nonce)}
        self._doc["data"] = _b64e(enc)
        blob = None
        _write_0600(self.path, json.dumps(self._doc, indent=2))

    # -- slots ---------------------------------------------------------------
    def slot_ids(self):
        if self._doc is None:
            self.load()
        return [s["id"] for s in self._doc["slots"]]

    def add_passphrase_slot(self, slot_id, passphrase):
        self._need_dek_or_fresh()
        kek = _derive_passphrase(passphrase, (kdf := _new_passphrase_kdf()))
        nonce, wrapped = _wrap(kek, bytes(self._dek))
        self._upsert_slot({"id": slot_id, "kind": "passphrase",
                           "kdf": kdf, "nonce": nonce, "wrapped": wrapped})
        kek = None

    def add_keyfile_slot(self, slot_id, key_bytes):
        self._need_dek_or_fresh()
        kdf = _new_keyfile_kdf()
        kek = _derive_keyfile(key_bytes, kdf)
        nonce, wrapped = _wrap(kek, bytes(self._dek))
        self._upsert_slot({"id": slot_id, "kind": "keyfile",
                           "kdf": kdf, "nonce": nonce, "wrapped": wrapped})
        kek = None

    def remove_slot(self, slot_id):
        self._doc["slots"] = [s for s in self._doc["slots"]
                              if s["id"] != slot_id]
        self._flush_doc()

    def _upsert_slot(self, slot):
        self._doc["slots"] = [s for s in self._doc["slots"]
                              if s["id"] != slot["id"]] + [slot]
        self._flush_doc()

    def _flush_doc(self):
        if self.exists() or self._dek is not None:
            if self._dek is not None and self._payload is not None:
                self.save()
            else:
                _write_0600(self.path, json.dumps(self._doc, indent=2))

    def _need_dek_or_fresh(self):
        if self._doc is None:
            self.load()
        if self._dek is None:
            if self._doc["slots"]:
                raise VaultLocked("unlock vault before adding slots")
            self._dek = bytearray(_secrets.token_bytes(32))
            self._payload = {"profiles": {}}

    # -- unlock ---------------------------------------------------------------
    @property
    def unlocked(self):
        return self._dek is not None

    def unlock_with_passphrase(self, passphrase):
        return self._unlock(lambda s: _derive_passphrase(passphrase,
                                                         s["kdf"]))

    def unlock_with_keyfile(self, key_bytes):
        return self._unlock(lambda s: _derive_keyfile(key_bytes, s["kdf"]))

    def _unlock(self, derive):
        if self._doc is None:
            self.load()
        for slot in self._doc["slots"]:
            try:
                kek = derive(slot)
            except VaultError:
                continue
            dek = _unwrap(kek, slot["nonce"], slot["wrapped"])
            if dek is None:
                continue
            # decrypt payload once to prove integrity
            try:
                c = self._doc["cipher"]
                blob = _aead(dek).decrypt(_b64d(c["nonce"]),
                                          _b64d(self._doc["data"]),
                                          b"vc-data") \
                    if self._doc.get("data") else b'{"profiles": {}}'
                self._payload = json.loads(blob.decode("utf-8"))
            except Exception:
                continue
            self._dek = bytearray(dek)
            self._payload.setdefault("profiles", {})
            return True
        return False

    def require_unlocked(self):
        if not self.unlocked:
            raise VaultLocked("vault is locked")

    def lock(self):
        if self._dek is not None:
            for i in range(len(self._dek)):
                self._dek[i] = 0
        self._dek = None
        if self._payload is not None:
            for prof in self._payload.get("profiles", {}).values():
                for k, v in prof.items():
                    if isinstance(v, str):
                        prof[k] = "\x00" * len(v)
        self._payload = None

    # -- secrets ---------------------------------------------------------------
    def set_secret(self, profile_id, data):
        """data: dict with password/pim/hidden_password/hidden_pim/
        token_pin (str) and hidden_keyfiles (list)."""
        self.require_unlocked()
        enc = {}
        for k in ("password", "pim", "hidden_password", "hidden_pim",
                  "token_pin"):
            v = data.get(k) or ""
            if len(v) > MAX_SECRET_LEN:
                raise VaultError("secret too long")
            enc[k] = _b64e(v.encode("utf-8"))
        enc["hidden_keyfiles"] = list(data.get("hidden_keyfiles") or [])
        self._payload["profiles"][profile_id] = enc
        self.save()

    def get_secret(self, profile_id):
        self.require_unlocked()
        enc = self._payload["profiles"].get(profile_id)
        if enc is None:
            return None
        out = {"hidden_keyfiles": list(enc.get("hidden_keyfiles") or [])}
        for k in ("password", "pim", "hidden_password", "hidden_pim",
                  "token_pin"):
            v = enc.get(k) or ""
            out[k] = _b64d(v).decode("utf-8") if v else ""
        return out

    def has_secret(self, profile_id):
        self.require_unlocked()
        return profile_id in self._payload["profiles"]

    def remove_secret(self, profile_id):
        self.require_unlocked()
        if profile_id in self._payload["profiles"]:
            del self._payload["profiles"][profile_id]
            self.save()

    def profile_ids_with_secrets(self):
        self.require_unlocked()
        return sorted(self._payload["profiles"].keys())


def generate_keyfile(path, size=64):
    """Create a random keyfile (mode 0600) and return its bytes."""
    data = _secrets.token_bytes(size)
    _write_0600(path, base64.b64encode(data).decode() + "\n")
    return data


def read_keyfile(path, max_size=1 << 20):
    with open(path, "rb") as fh:
        data = fh.read(max_size + 1)
    if not data or len(data) > max_size:
        raise VaultError("keyfile %s empty or too large" % path)
    # tolerate base64-encoded keyfiles produced by generate_keyfile
    try:
        dec = base64.b64decode(data.strip(), validate=True)
        if dec:
            return dec
    except Exception:
        pass
    return data
