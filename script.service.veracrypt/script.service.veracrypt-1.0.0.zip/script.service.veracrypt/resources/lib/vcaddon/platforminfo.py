"""Platform detection and well-known paths.

Supported: 'libreelec' and 'batocera' (plus 'linux' for development).
"""

import os
import platform

PLATFORM_LIBREELEC = "libreelec"
PLATFORM_BATOCERA = "batocera"
PLATFORM_LINUX = "linux"

_BATOCERA_DATA = "/userdata/system/veracrypt"
_LE_DATA = "/storage/.kodi/userdata/addon_data/script.service.veracrypt"
_BATOCERA_PORTS = "/userdata/roms/ports"
_BATOCERA_SERVICES = "/userdata/system/services"
_LE_MEDIA = "/media"


def os_id():
    """Best-effort distro id from /etc/os-release."""
    try:
        with open("/etc/os-release", "r", encoding="utf-8", errors="replace") as fh:
            for line in fh:
                if line.startswith("ID="):
                    return line.strip().split("=", 1)[1].strip('"').lower()
    except OSError:
        pass
    return ""


def detect_platform(override=None):
    """Return one of PLATFORM_* constants."""
    if override:
        return override
    oid = os_id()
    if "libreelec" in oid or "openelec" in oid:
        return PLATFORM_LIBREELEC
    if "batocera" in oid:
        return PLATFORM_BATOCERA
    # heuristic fallbacks
    if os.path.isdir("/userdata/system") and os.path.exists("/usr/bin/batocera-settings"):
        return PLATFORM_BATOCERA
    if os.path.isdir("/storage/.kodi"):
        return PLATFORM_LIBREELEC
    return PLATFORM_LINUX


def machine():
    """Normalized CPU/machine name for selecting packaged binaries."""
    m = platform.machine().lower()
    if m in ("aarch64", "arm64"):
        return "aarch64"
    if m.startswith("armv7") or m.startswith("armv6") or m == "arm":
        return "arm"
    return m


def data_dir(plat=None):
    plat = plat or detect_platform()
    if plat == PLATFORM_BATOCERA:
        return _BATOCERA_DATA
    if plat == PLATFORM_LIBREELEC:
        return _LE_DATA
    return os.path.join(os.path.expanduser("~"), ".veracrypt-addon")


def media_base(plat=None):
    plat = plat or detect_platform()
    if plat == PLATFORM_BATOCERA:
        return "/media"
    return _LE_MEDIA


def batocera_ports_dir():
    return _BATOCERA_PORTS


def batocera_services_dir():
    return _BATOCERA_SERVICES
