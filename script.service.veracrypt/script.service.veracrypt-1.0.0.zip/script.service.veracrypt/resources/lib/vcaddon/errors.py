"""Error taxonomy for vcaddon."""


class VCError(Exception):
    """Base class for all vcaddon errors."""


class PreflightError(VCError):
    """A required system capability is missing."""

    def __init__(self, message, report=None):
        super().__init__(message)
        self.report = report


class MountFailed(VCError):
    """veracrypt failed to mount a volume."""

    def __init__(self, message, returncode=None, output=""):
        super().__init__(message)
        self.returncode = returncode
        self.output = output


class AuthFailed(MountFailed):
    """The volume could not be opened - most likely wrong credentials."""


class UnmountFailed(VCError):
    pass


class VaultError(VCError):
    pass


class VaultLocked(VaultError):
    pass


class VaultAuthFailed(VaultError):
    """Wrong master password / key or corrupted vault."""


class ProfileError(VCError):
    pass


class ConfigError(ProfileError):
    """Invalid profile or settings content."""


class PathPolicy(ConfigError):
    """A path escapes the managed root or violates path policy."""


class DeviceNotFound(VCError):
    pass
