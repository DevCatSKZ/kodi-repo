"""Pure-Python AES-256-GCM.

Used only when neither ``cryptography`` nor ``Crypto`` (PyCryptodome)
is importable - e.g. on a minimal Kodi/LibreELEC Python. Only the
encrypt direction of AES is implemented (GCM uses CTR mode + GHASH).

Correctness is verified by tests/aes_gcm vectors in tests/.
"""

# -- GF(2^8) helpers ------------------------------------------------------

def _gmul8(a, b):
    p = 0
    for _ in range(8):
        if b & 1:
            p ^= a
        hi = a & 0x80
        a = (a << 1) & 0xFF
        if hi:
            a ^= 0x1B
        b >>= 1
    return p


def _rotl8(v, n):
    return ((v << n) | (v >> (8 - n))) & 0xFF


def _build_tables():
    inv = [0] * 256
    for a in range(1, 256):
        for b in range(1, 256):
            if _gmul8(a, b) == 1:
                inv[a] = b
                break
    sbox = bytearray(256)
    for x in range(256):
        i = inv[x]
        sbox[x] = (i ^ _rotl8(i, 1) ^ _rotl8(i, 2)
                   ^ _rotl8(i, 3) ^ _rotl8(i, 4) ^ 0x63)
    return bytes(sbox)


_SBOX = _build_tables()
_RCON = (0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80,
         0x1B, 0x36, 0x6C, 0xD8, 0xAB, 0x4D)


def _expand_key(key):
    """AES-256 key expansion -> 15 round keys of 16 bytes."""
    if len(key) != 32:
        raise ValueError("AES-256 requires a 32-byte key")
    w = list(key)                       # bytes, column-major words
    i = 32
    rcon_iter = 0
    while i < 240:                      # Nb*(Nr+1)*4 = 4*15*4
        t = w[i - 4:i]
        if i % 32 == 0:
            t = [_SBOX[t[1]] ^ _RCON[rcon_iter], _SBOX[t[2]],
                 _SBOX[t[3]], _SBOX[t[0]]]
            rcon_iter += 1
        elif i % 32 == 16:
            t = [_SBOX[t[0]], _SBOX[t[1]], _SBOX[t[2]], _SBOX[t[3]]]
        base = i - 32
        for j in range(4):
            w.append(w[base + j] ^ t[j])
        i += 4
    return [bytes(w[r * 16:(r + 1) * 16]) for r in range(15)]


def _encrypt_block(round_keys, block):
    """Encrypt one 16-byte block. State is column-major: s[r][c]=b[4c+r]"""
    s = list(block)

    def add_rk(rk):
        for i in range(16):
            s[i] ^= rk[i]

    def sub_bytes():
        for i in range(16):
            s[i] = _SBOX[s[i]]

    def shift_rows():
        # row r: positions r, r+4, r+8, r+12 rotated left by r
        for r in (1, 2, 3):
            row = [s[r + 4 * c] for c in range(4)]
            for c in range(4):
                s[r + 4 * c] = row[(c + r) % 4]

    def mix_columns():
        for c in range(4):
            i = 4 * c
            a0, a1, a2, a3 = s[i], s[i + 1], s[i + 2], s[i + 3]
            s[i] = _gmul8(a0, 2) ^ _gmul8(a1, 3) ^ a2 ^ a3
            s[i + 1] = a0 ^ _gmul8(a1, 2) ^ _gmul8(a2, 3) ^ a3
            s[i + 2] = a0 ^ a1 ^ _gmul8(a2, 2) ^ _gmul8(a3, 3)
            s[i + 3] = _gmul8(a0, 3) ^ a1 ^ a2 ^ _gmul8(a3, 2)

    add_rk(round_keys[0])
    for rnd in range(1, 14):
        sub_bytes()
        shift_rows()
        mix_columns()
        add_rk(round_keys[rnd])
    sub_bytes()
    shift_rows()
    add_rk(round_keys[14])
    return bytes(s)


# -- GCM -------------------------------------------------------------------

_GCM_R = 0xE1 << 120


def _ghash_mul(x, y):
    """Multiply in GF(2^128) with the GCM polynomial."""
    z = 0
    v = x
    for i in range(128):
        if (y >> (127 - i)) & 1:
            z ^= v
        if v & 1:
            v = (v >> 1) ^ _GCM_R
        else:
            v >>= 1
    return z


def _ghash(h, aad, ct):
    def pad(b):
        if len(b) % 16:
            return b + b"\x00" * (16 - len(b) % 16)
        return b

    y = 0
    data = pad(aad) + pad(ct) + \
        (len(aad) * 8).to_bytes(8, "big") + (len(ct) * 8).to_bytes(8, "big")
    for off in range(0, len(data), 16):
        y = _ghash_mul(y ^ int.from_bytes(data[off:off + 16], "big"), h)
    return y.to_bytes(16, "big")


def _inc32(block):
    n = int.from_bytes(block, "big")
    n = (n & ~0xFFFFFFFF) | ((n + 1) & 0xFFFFFFFF)
    return n.to_bytes(16, "big")


class AESGCM:
    """Drop-in compatible with cryptography.hazmat AESGCM API."""

    def __init__(self, key):
        self._rk = _expand_key(bytes(key))

    def _j0(self, nonce):
        if len(nonce) == 12:
            return nonce + b"\x00\x00\x00\x01"
        # fallback: GHASH-derived J0 for arbitrary-length nonce
        h = int.from_bytes(_encrypt_block(self._rk, b"\x00" * 16), "big")
        pad = b"" if len(nonce) % 16 == 0 \
            else b"\x00" * (16 - len(nonce) % 16)
        data = nonce + pad + b"\x00" * 8 + (len(nonce) * 8).to_bytes(8, "big")
        y = 0
        for off in range(0, len(data), 16):
            y = _ghash_mul(y ^ int.from_bytes(data[off:off + 16], "big"), h)
        return y.to_bytes(16, "big")

    def _ctr(self, j0, data):
        out = bytearray()
        ctr = _inc32(j0)
        for off in range(0, len(data), 16):
            ks = _encrypt_block(self._rk, ctr)
            chunk = data[off:off + 16]
            out += bytes(c ^ k for c, k in zip(chunk, ks))
            ctr = _inc32(ctr)
        return bytes(out)

    def encrypt(self, nonce, data, aad):
        j0 = self._j0(bytes(nonce))
        ct = self._ctr(j0, bytes(data))
        h = int.from_bytes(_encrypt_block(self._rk, b"\x00" * 16), "big")
        s = _ghash(h, bytes(aad or b""), ct)
        tag = bytes(x ^ y for x, y in
                    zip(s, _encrypt_block(self._rk, j0)))
        return ct + tag

    def decrypt(self, nonce, data, aad):
        data = bytes(data)
        ct, tag = data[:-16], data[-16:]
        j0 = self._j0(bytes(nonce))
        h = int.from_bytes(_encrypt_block(self._rk, b"\x00" * 16), "big")
        s = _ghash(h, bytes(aad or b""), ct)
        want = bytes(x ^ y for x, y in
                     zip(s, _encrypt_block(self._rk, j0)))
        import hmac as _hmac
        if not _hmac.compare_digest(tag, want):
            raise ValueError("GCM tag mismatch")
        return self._ctr(j0, ct)


def get_aesgcm():
    """Return the best available AESGCM class (stdlib-free preference:
    cryptography > PyCryptodome > this module)."""
    try:
        from cryptography.hazmat.primitives.ciphers.aead import \
            AESGCM as LibAESGCM
        return LibAESGCM
    except ImportError:
        pass
    try:
        from Crypto.Cipher import AES as _PycAES  # noqa

        class _Adapter:
            def __init__(self, key):
                self._key = bytes(key)

            def encrypt(self, nonce, data, aad):
                c = _PycAES.new(self._key, _PycAES.MODE_GCM,
                                nonce=bytes(nonce))
                if aad:
                    c.update(bytes(aad))
                ct, tag = c.encrypt_and_digest(bytes(data))
                return ct + tag

            def decrypt(self, nonce, data, aad):
                data = bytes(data)
                c = _PycAES.new(self._key, _PycAES.MODE_GCM,
                                nonce=bytes(nonce))
                if aad:
                    c.update(bytes(aad))
                pt = c.decrypt(data[:-16])
                c.verify(data[-16:])
                return pt

        return _Adapter
    except ImportError:
        pass
    return AESGCM
