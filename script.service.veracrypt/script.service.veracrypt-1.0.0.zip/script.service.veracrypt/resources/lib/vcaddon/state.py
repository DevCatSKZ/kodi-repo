"""Runtime state: which mounts this addon owns.

Kept in a small JSON file in the runtime dir so a crashed/restarted
service still knows which mapper mounts it must clean up - and so
shutdown never touches volumes the user mounted by hand.
"""

import json
import os
import time
from dataclasses import dataclass, field


@dataclass
class MountRecord:
    profile_id: str = ""
    volume_path: str = ""
    mount_point: str = ""
    slot: int = 0
    read_only: bool = True
    ts: float = 0.0

    def to_dict(self):
        return {"profile_id": self.profile_id, "volume_path": self.volume_path,
                "mount_point": self.mount_point, "slot": self.slot,
                "read_only": self.read_only, "ts": self.ts}

    @classmethod
    def from_dict(cls, d):
        return cls(**{k: v for k, v in d.items() if k in cls.FIELDS()})

    @staticmethod
    def FIELDS():
        return ("profile_id", "volume_path", "mount_point", "slot",
                "read_only", "ts")


class State:
    def __init__(self, path):
        self.path = path
        self.records = {}
        self.load()

    def load(self):
        self.records = {}
        try:
            with open(self.path, "r", encoding="utf-8") as fh:
                doc = json.load(fh)
            for r in doc.get("mounts", []):
                rec = MountRecord.from_dict(r)
                self.records[rec.mount_point or rec.volume_path] = rec
        except (OSError, ValueError):
            pass

    def save(self):
        doc = {"mounts": [r.to_dict() for r in self.records.values()]}
        try:
            tmp = self.path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(doc, fh, indent=2)
            os.replace(tmp, self.path)
        except OSError:
            pass

    def add(self, rec):
        if not rec.ts:
            rec.ts = time.time()
        self.records[rec.mount_point or rec.volume_path] = rec
        self.save()

    def remove(self, key):
        self.records.pop(key, None)
        self.save()

    def find(self, ref):
        for k, r in self.records.items():
            if ref in (k, r.profile_id, r.volume_path, r.mount_point):
                return r
        return None

    def all(self):
        return list(self.records.values())
