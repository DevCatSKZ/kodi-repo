"""Minimal logging helper.

Writes to stderr and optionally to a log file. A UI bridge (Kodi xbmc.log,
EmulationStation console) can be attached by assigning ``bridge``.

Security rule: NEVER log secrets. Callers must only pass sanitised data.
"""

import sys
import time

_bridge = None
_log_file = None
_verbose = False


def set_bridge(fn):
    """Attach a log sink, e.g. ``lambda level, msg: xbmc.log(msg, lvl)``."""
    global _bridge
    _bridge = fn


def set_file(path):
    """Append logs to a file (create parents). Pass None to disable."""
    global _log_file
    _log_file = path


def set_verbose(flag):
    global _verbose
    _verbose = bool(flag)


def _emit(level, msg):
    line = "vcaddon [%s] %s" % (level, msg)
    if _bridge is not None:
        try:
            _bridge(level, msg)
        except Exception:
            pass
    try:
        sys.stderr.write(line + "\n")
    except Exception:
        pass
    if _log_file:
        try:
            with open(_log_file, "a", encoding="utf-8") as fh:
                fh.write("%s %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), line))
        except Exception:
            pass


def info(msg):
    _emit("INFO", msg)


def warn(msg):
    _emit("WARN", msg)


def error(msg):
    _emit("ERROR", msg)


def debug(msg):
    if _verbose:
        _emit("DEBUG", msg)


def redact(text, secrets):
    """Return ``text`` with every secret value replaced by ``***``.

    ``secrets`` is an iterable of str/bytes; empty values are ignored.
    Use before logging any output that might contain user input.
    """
    if not isinstance(text, str):
        try:
            text = text.decode("utf-8", "replace")
        except Exception:
            text = str(text)
    for s in secrets or ():
        if isinstance(s, bytes):
            try:
                s = s.decode("utf-8")
            except Exception:
                continue
        if s:
            text = text.replace(s, "***")
    return text
