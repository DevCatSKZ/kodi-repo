"""Best-effort secret material handling.

Python cannot guarantee memory wiping (immutable strings, GC copies),
so this module only reduces lifetime: secrets are kept as ``bytearray``
and overwritten on ``wipe()``/destruction. Never place secrets in
command-line arguments, environment variables, settings files or logs.
"""


def wipe(buf):
    """Overwrite a bytearray/memoryview in place. Returns None."""
    if buf is None:
        return
    try:
        mv = memoryview(buf)
        mv[:] = b"\x00" * len(mv)
    except Exception:
        pass


class Secret:
    """Holds UTF-8 bytes of a secret, wipes them on close/destroy."""

    __slots__ = ("_buf",)

    def __init__(self, value=b""):
        if isinstance(value, Secret):
            value = value.bytes()
        if isinstance(value, str):
            value = value.encode("utf-8")
        self._buf = bytearray(value)

    @classmethod
    def from_text(cls, text):
        return cls(text or "")

    def bytes(self):
        return bytes(self._buf)

    def text(self):
        return self._buf.decode("utf-8", "replace")

    def lines_bytes(self):
        """Secret encoded as one input line (UTF-8 + \n)."""
        return bytes(self._buf) + b"\n"

    def is_empty(self):
        return len(self._buf) == 0

    def wipe(self):
        wipe(self._buf)
        self._buf = bytearray()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.wipe()
        return False

    def __del__(self):  # best effort only
        try:
            self.wipe()
        except Exception:
            pass

    def __repr__(self):
        return "<Secret len=%d>" % len(self._buf)

    def __eq__(self, other):
        if isinstance(other, Secret):
            return self.bytes() == other.bytes()
        return NotImplemented

    def __hash__(self):
        return hash(self.bytes())
