"""VeraCrypt argument-list construction.

Rule #1: argv NEVER carries secrets. The process list is world-readable.
Volume passwords go through stdin (--stdin) or a PTY; custom PIM,
token PINs and hidden-volume protection credentials are answered on the
PTY prompt channel only.
"""

from dataclasses import dataclass, field

# Options that take a secret value. They must never appear in argv.
SECRET_OPTIONS = frozenset({
    "-p", "--password",
    "--pim",
    "--protection-password", "--protection-pim",
    "--new-password", "--new-pim",
    "--token-pin",
})

# Options we allow callers to pass through explicitly (non-secret).
_ALLOWED_EXTRA = frozenset({
    "--verbose", "-v", "-f", "--force",
    "--allow-insecure-mount", "--use-dummy-sudo-password",
    "--emergency-unmount", "--no-size-check",
    "--legacy-password-maxlength", "--display-password",
})


@dataclass
class MountSpec:
    volume_path: str = ""
    mount_point: str = ""
    read_only: bool = True
    filesystem: str = ""          # "", "none", "ntfs3", "exfat", ...
    fs_options: str = ""          # passed via --fs-options
    slot: int = 0                 # 0 = let veracrypt choose
    keyfiles: tuple = ()
    protect_hidden: bool = False  # protect hidden volume inside outer
    custom_pim: bool = False      # user supplies a PIM -> PTY prompt
    token_lib: str = ""           # security token library path
    kernel_crypto: bool = True    # False -> "nokernelcrypto" (no dm-crypt)
    force: bool = False
    verbose: bool = False
    extra: tuple = ()

    def needs_interactive(self):
        """True when secrets beyond the volume password are required."""
        return bool(self.custom_pim or self.protect_hidden
                    or self.token_lib)


def _assert_safe(argv):
    """Guard: refuse to build an argv containing secret options.

    ``--pim=0`` is the only exception: it carries no secret, it is the
    documented marker for "use the default PIM" and is required in
    non-interactive mode.
    """
    for arg in argv:
        if arg == "--pim=0":
            continue
        opt = arg.split("=", 1)[0]
        if opt in SECRET_OPTIONS:
            raise AssertionError(
                "secret option %r must never be placed in argv" % opt)


def _common(spec, argv):
    if spec.filesystem:
        argv.append("--filesystem=" + spec.filesystem)
    if spec.fs_options:
        argv.append("--fs-options=" + spec.fs_options)
    mopts = []
    if spec.read_only:
        mopts.append("ro")
    if not spec.kernel_crypto:
        mopts.append("nokernelcrypto")
    if mopts:
        argv.append("-m")
        argv.append(",".join(mopts))
    if spec.slot:
        argv.append("--slot=%d" % spec.slot)
    if spec.keyfiles:
        argv.append("-k")
        argv.append(",".join(spec.keyfiles))
    else:
        argv += ["-k", ""]
    if spec.token_lib:
        argv.append("--token-lib=" + spec.token_lib)
    if spec.force:
        argv.append("-f")
    if spec.verbose:
        argv.append("-v")
    for arg in spec.extra:
        opt = arg.split("=", 1)[0]
        if opt not in _ALLOWED_EXTRA:
            raise ValueError("extra option %r not allowed" % opt)
        argv.append(arg)


def build_mount_argv(binary, spec, interactive=None):
    """Return argv for `veracrypt` mounting spec's volume.

    interactive=True  -> text UI driven via PTY (secrets answered on
                         prompt; used when PIM/protection secrets needed)
    interactive=False -> non-interactive + --stdin (password on stdin)
    """
    if interactive is None:
        interactive = spec.needs_interactive()

    argv = [binary, "-t"]
    if interactive:
        # no --non-interactive: prompts are answered through the PTY.
        # --protect-hidden given explicitly so the prompt sequence is
        # deterministic (yes -> hidden creds prompts, no -> none).
        argv.append("--protect-hidden=yes" if spec.protect_hidden
                    else "--protect-hidden=no")
    else:
        if spec.needs_interactive():
            raise ValueError(
                "non-interactive mode cannot carry PIM/protection secrets")
        argv += ["--non-interactive", "--stdin",
                 "--pim=0", "--protect-hidden=no"]

    _common(spec, argv)
    argv.append(spec.volume_path)
    if spec.mount_point:
        argv.append(spec.mount_point)
    _assert_safe(argv)
    return argv


def build_unmount_argv(binary, target, force=False):
    argv = [binary, "-t", "-u"]
    if force:
        argv.append("-f")
    argv.append(target)
    _assert_safe(argv)
    return argv


def build_unmount_all_argv(binary):
    argv = [binary, "-t", "-u"]
    _assert_safe(argv)
    return argv


def build_list_argv(binary, verbose=True):
    argv = [binary, "-t", "-l"]
    if verbose:
        argv.insert(2, "-v")
    _assert_safe(argv)
    return argv


def build_version_argv(binary):
    return [binary, "-t", "--version"]


def build_test_argv(binary):
    return [binary, "-t", "--test"]
