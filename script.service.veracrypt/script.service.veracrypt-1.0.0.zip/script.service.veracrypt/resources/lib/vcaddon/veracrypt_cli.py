"""Execution wrapper around the veracrypt console binary.

Two secret-delivery strategies:

1. ``--stdin``      : the volume password is written to the process's
                      stdin. Used whenever no further secret is needed.
2. PTY interactive  : veracrypt's text UI prompts are answered through a
                      pseudo-terminal. Required for custom PIM, hidden
                      volume protection credentials and token PINs -
                      those have no secret-safe non-interactive option.

Nothing secret is ever placed in argv, environment or a file.
"""

import os
import re
import select
import shutil
import signal
import subprocess
import time
from dataclasses import dataclass, field

from . import cmdline, log
from .errors import AuthFailed, MountFailed, UnmountFailed, VCError
from .secrets import Secret, wipe

DEFAULT_TIMEOUT = 300          # KDF on a Pi 3 can take tens of seconds
PROMPT_TIMEOUT = 120

# -- prompt pattern -> which answer to send -------------------------------
# Order matters: the most specific patterns come first.
_PATTERNS = (
    (re.compile(rb"hidden.*(keyfile)", re.I), "hidden_keyfile"),
    (re.compile(rb"hidden.*pim|pim.*hidden", re.I), "hidden_pim"),
    (re.compile(rb"hidden.*password|password.*hidden", re.I), "hidden_password"),
    (re.compile(rb"keyfile.*hidden", re.I), "hidden_keyfile"),
    (re.compile(rb"re-enter|new password", re.I), "unexpected_verify"),
    (re.compile(rb"token.*(password|pin)|pin.*token", re.I), "token_pin"),
    (re.compile(rb"administrator password|user password", re.I), "sudo"),
    (re.compile(rb"keyfile.*finish|keyfile.*none|keyfile", re.I), "keyfile"),
    (re.compile(rb"pim", re.I), "pim"),
    (re.compile(rb"password", re.I), "password"),
    (re.compile(rb"protect.*\(y|protect.*\?", re.I), "protect_yesno"),
    (re.compile(rb"\(y=[^\n]*n=[^\n]*\)", re.I), "yesno_default"),
    (re.compile(rb"select", re.I), "select"),
)

_ERROR_MARKERS = (
    b"incorrect password", b"incorrect pim", b"operation failed",
    b"error:", b"password or pim incorrect",
    b"no such file", b"permission denied", b"command failed",
)


@dataclass
class MountSecrets:
    """Secret material for a mount. Wipe after use."""

    password: Secret = field(default_factory=Secret)
    pim: Secret = field(default_factory=Secret)           # numeric text
    hidden_password: Secret = field(default_factory=Secret)
    hidden_pim: Secret = field(default_factory=Secret)
    hidden_keyfiles: tuple = ()
    token_pin: Secret = field(default_factory=Secret)

    def all(self):
        return [self.password, self.pim, self.hidden_password,
                self.hidden_pim, self.token_pin]

    def wipe(self):
        for s in self.all():
            s.wipe()


@dataclass
class MountedVolume:
    slot: int = 0
    volume: str = ""
    virtual_device: str = ""
    mount_point: str = ""
    size: str = ""
    vtype: str = ""
    read_only: bool = False
    hidden_protected: bool = False


@dataclass
class CmdResult:
    returncode: int
    output: str          # sanitized transcript (secrets redacted)
    timed_out: bool = False


def _sanitize(data, secrets):
    if isinstance(data, bytes):
        text = data.decode("utf-8", "replace")
    else:
        text = data
    for s in secrets or ():
        try:
            t = s.text() if isinstance(s, Secret) else s
        except Exception:
            continue
        if t:
            text = text.replace(t, "***")
    return text


def _auth_error(output):
    low = output.lower()
    return ("incorrect password" in low or "incorrect pim" in low
            or "password or pim incorrect" in low)


class PtySession:
    """Drive veracrypt's interactive text UI through a pseudo-tty."""

    def __init__(self, argv, answers, timeout=DEFAULT_TIMEOUT,
                 env=None):
        """
        answers: dict pattern-key -> callable()|str|Secret|None
                 called lazily, each used at most once unless it is a
                 plain str (interpreted as repeatable answer).
        """
        self.argv = argv
        self.answers = dict(answers)
        self.timeout = timeout
        self.env = env
        self._used = set()

    def _answer_for(self, line_tail):
        for pat, key in _PATTERNS:
            if pat.search(line_tail):
                return key
        return None

    def _resolve(self, key):
        ans = self.answers.get(key)
        if ans is None:
            if key == "keyfile":
                return ""          # default: finish keyfile list
            if key == "pim":
                return ""          # default: default PIM
            if key == "yesno_default":
                return ""          # accept default (usually No)
            if key == "hidden_keyfile":
                return ""
            if key == "hidden_pim":
                return ""
            raise VCError("no answer configured for prompt %r" % key)
        if callable(ans):
            ans = ans()
        if isinstance(ans, Secret):
            ans = ans.text()
        if ans is None:
            raise VCError("prompt %r produced no answer" % key)
        return str(ans)

    def run(self):  # POSIX only
        import pty

        pid, master = pty.fork()
        if pid == 0:  # child
            try:
                env = dict(os.environ)
                env.update(self.env or {})
                os.execvpe(self.argv[0], self.argv, env)
            except Exception:
                os._exit(127)

        out = bytearray()
        tail = bytearray()
        deadline = time.monotonic() + self.timeout
        prompt_deadline = None
        last_secret_key = None
        timed_out = False

        try:
            while True:
                now = time.monotonic()
                if now > deadline:
                    timed_out = True
                    break
                if prompt_deadline and now > prompt_deadline:
                    raise MountFailed(
                        "prompt timeout waiting for veracrypt input")
                rc, status = 0, 0
                try:
                    done, status = os.waitpid(pid, os.WNOHANG)
                except ChildProcessError:
                    done, status = pid, 0
                if done == pid:
                    rc = os.waitstatus_to_exitcode(status) \
                        if hasattr(os, "waitstatus_to_exitcode") \
                        else os.WEXITSTATUS(status)
                    # drain remaining output
                    try:
                        while True:
                            r, _, _ = select.select([master], [], [], 0.1)
                            if not r:
                                break
                            chunk = os.read(master, 65536)
                            if not chunk:
                                break
                            out += chunk
                    except OSError:
                        pass
                    result = CmdResult(rc, bytes(out), timed_out)
                    return result
                r, _, _ = select.select([master], [], [], 0.25)
                if not r:
                    continue
                try:
                    chunk = os.read(master, 65536)
                except OSError:
                    continue
                if not chunk:
                    continue
                out += chunk
                tail = (tail + chunk)[-4096:]
                # a prompt ends with ':' or '] ' and no trailing newline
                stripped = bytes(tail).rstrip(b"\x1b[?25l\x1b[?25h")
                if stripped.endswith(b"\n"):
                    continue
                key = self._answer_for(bytes(tail))
                if key is None:
                    continue
                if key == "unexpected_verify" or key == "select":
                    raise MountFailed(
                        "unexpected veracrypt prompt (%r)" % key)
                if key in self._used and key in (
                        "password", "pim", "hidden_password", "hidden_pim",
                        "token_pin", "sudo"):
                    # same secret asked twice -> credentials rejected
                    raise AuthFailed(
                        "veracrypt rejected the supplied credentials")
                self._used.add(key)
                answer = self._resolve(key)
                prompt_deadline = time.monotonic() + PROMPT_TIMEOUT
                last_secret_key = key
                os.write(master, answer.encode("utf-8") + b"\n")
        finally:
            if timed_out or True:
                try:
                    os.kill(pid, signal.SIGKILL)
                except (OSError, ProcessLookupError):
                    pass
                try:
                    os.waitpid(pid, 0)
                except (OSError, ChildProcessError):
                    pass
            try:
                os.close(master)
            except OSError:
                pass
        if timed_out:
            result = CmdResult(-1, bytes(out), True)
            return result


def _classify(result):
    out = result.output
    if result.timed_out:
        raise MountFailed("veracrypt timed out", result.returncode, out)
    if result.returncode == 0:
        return
    if _auth_error(out):
        raise AuthFailed("authentication failed", result.returncode, out)
    raise MountFailed("veracrypt failed (rc=%d)" % result.returncode,
                      result.returncode, out)


class VeraCrypt:
    """Thin, safe wrapper. One instance = one binary."""

    def __init__(self, binary=None, timeout=DEFAULT_TIMEOUT,
                 sudo_helper=None, env=None):
        self.binary = binary or shutil.which("veracrypt")
        if not self.binary:
            raise VCError("veracrypt binary not found")
        self.timeout = timeout
        self.sudo_helper = sudo_helper  # optional privileged helper argv
        # extra environment for the veracrypt process tree (e.g.
        # LD_LIBRARY_PATH for a private runtime, DM_UDEV_DISABLE_* on
        # systems without udev dm-cookie handling). Never carry secrets.
        self.env = dict(env or {})

    def _argv(self, argv):
        if self.sudo_helper:
            return list(self.sudo_helper) + argv
        return argv

    def _proc_env(self):
        env = dict(os.environ)
        env.update(self.env)
        return env

    # -- info -------------------------------------------------------------
    def version(self):
        proc = subprocess.run(
            self._argv(cmdline.build_version_argv(self.binary)),
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=15,
            env=self._proc_env())
        out = proc.stdout.decode("utf-8", "replace").strip()
        return out.splitlines()[-1] if out else "unknown"

    def list_volumes(self):
        argv = self._argv(cmdline.build_list_argv(self.binary))
        proc = subprocess.run(argv, stdout=subprocess.PIPE,
                              stderr=subprocess.STDOUT, timeout=30,
                              env=self._proc_env())
        out = proc.stdout.decode("utf-8", "replace")
        return _parse_list(out)

    def is_mounted(self, volume_path):
        for v in self.list_volumes():
            if v.volume == volume_path:
                return v
        return None

    # -- mount ------------------------------------------------------------
    def mount(self, spec, secrets):
        """Mount spec.volume_path. ``secrets`` wiped by caller only."""
        interactive = spec.needs_interactive()
        argv = self._argv(cmdline.build_mount_argv(
            self.binary, spec, interactive=interactive))
        log.debug("exec: %s" % " ".join(argv))

        if interactive:
            answers = {
                "password": lambda: secrets.password.text(),
                "pim": lambda: secrets.pim.text(),
                "hidden_password": lambda: secrets.hidden_password.text(),
                "hidden_pim": lambda: secrets.hidden_pim.text(),
                "token_pin": lambda: secrets.token_pin.text(),
            }
            if spec.keyfiles:
                answers["keyfile"] = ""      # finish list
            if spec.protect_hidden:
                answers["protect_yesno"] = "y"
                answers["hidden_keyfile"] = ""
            else:
                answers["protect_yesno"] = "n"
            sess = PtySession(argv, answers, timeout=self.timeout,
                              env=self.env)
            res = sess.run()
        else:
            payload = secrets.password.lines_bytes()
            try:
                proc = subprocess.run(
                    argv, input=payload, stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT, timeout=self.timeout,
                    env=self._proc_env())
                out = _sanitize(proc.stdout, secrets.all())
                res = CmdResult(proc.returncode, out)
            except subprocess.TimeoutExpired as exc:
                out = _sanitize(exc.stdout or b"", secrets.all())
                res = CmdResult(-1, out, timed_out=True)
            payload = None
        _classify(res)
        return res.output

    # -- unmount ----------------------------------------------------------
    def unmount(self, target, force=False):
        argv = self._argv(cmdline.build_unmount_argv(
            self.binary, target, force=force))
        proc = subprocess.run(argv, stdout=subprocess.PIPE,
                              stderr=subprocess.STDOUT, timeout=60,
                              env=self._proc_env())
        out = proc.stdout.decode("utf-8", "replace")
        if proc.returncode != 0:
            raise UnmountFailed(
                "unmount of %s failed: %s" % (target, out.strip()))
        return out

    def unmount_all(self):
        argv = self._argv(cmdline.build_unmount_all_argv(self.binary))
        proc = subprocess.run(argv, stdout=subprocess.PIPE,
                              stderr=subprocess.STDOUT, timeout=60,
                              env=self._proc_env())
        return proc.returncode, proc.stdout.decode("utf-8", "replace")


def _parse_list(text):
    """Parse `veracrypt -t -v -l` output.

    Verbose format (one stanza per volume):
        1: /path/to/vol /dev/mapper/veracrypt1 /media/x
          Slot: 1
          Volume: ...
          Virtual Device: ...
          Mount Directory: ...
          Size: ...
          Type: ...
          Read-Only: Yes|No
          Hidden Volume Protected: Yes|No
    Non-verbose: "slot: volume vdev mountpoint".
    """
    vols = []
    cur = None
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        m = re.match(r"^(\d+):\s+(\S+)\s+(\S+)\s+(\S.*)$", line)
        if m:
            cur = MountedVolume(slot=int(m.group(1)), volume=m.group(2),
                                virtual_device=m.group(3),
                                mount_point=m.group(4).strip())
            vols.append(cur)
            continue
        kv = re.match(r"^(Slot|Volume|Virtual Device|Mount Directory|"
                      r"Size|Type|Read-Only|Hidden Volume Protected|"
                      r"Encryption Algorithm|Mode of Operation|PKCS-5 PRF|"
                      r"Volume Format Version|Embedded Backup Header|"
                      r"Device Read-Only|Total Data Read|"
                      r"Total Data Written|Read-Only Device|"
                      r"Protection Key Size|Mount Flags):\s*(.*)$", line)
        if kv:
            key, val = kv.group(1), kv.group(2).strip()
            if key == "Slot":
                cur = MountedVolume()
                try:
                    cur.slot = int(val)
                except ValueError:
                    pass
                vols.append(cur)
                continue
            if cur is None:
                continue
            if key == "Volume":
                cur.volume = val
            elif key == "Virtual Device":
                cur.virtual_device = val
            elif key == "Mount Directory":
                cur.mount_point = val
            elif key == "Size":
                cur.size = val
            elif key == "Type":
                cur.vtype = val
            elif key == "Read-Only":
                cur.read_only = val.lower() == "yes"
            elif key == "Hidden Volume Protected":
                cur.hidden_protected = val.lower() == "yes"
    return vols
