"""vcaddon - platform-agnostic VeraCrypt mount control core.

Shared by the LibreELEC Kodi add-on and the Batocera manager/service.
Never imports Kodi/Batocera specific modules.
"""

__version__ = "0.1.0"

ADDON_ID = "script.service.veracrypt"
VAULT_MAGIC = b"VCVLT1"
