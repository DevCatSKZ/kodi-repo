"""Boot-time auto-mount policy.

Modes (settings.vault_unlock):
  prompt            -> callback asks the master passphrase once, then all
                       auto_mount profiles are mounted
  local-keyfile     -> unattended; keyfile stored in the data dir
                       (convenience only - weak if the Pi is stolen)
  external-keyfile  -> unattended; keyfile on separate media referenced
                       by settings.keyfile_path
  none / automount off -> do nothing

The unlock_callback is supplied by the frontend (TUI/Kodi). It must
return a passphrase string or None to abort.
"""

import os

from . import log, vault as vault_mod
from .errors import AuthFailed, VCError


class BootResult:
    def __init__(self):
        self.vault_unlocked = False
        self.unlock_method = ""
        self.mounted = []        # list[(profile, MountRecord)]
        self.failed = []         # list[(profile, error-str)]
        self.skipped = []        # list[(profile, reason)]
        self.message = ""

    def ok(self):
        return not self.failed


def _try_keyfile_unlock(vault, path):
    try:
        key = vault_mod.read_keyfile(path)
    except (OSError, VCError) as exc:
        log.warn("keyfile unlock failed (%s)" % exc)
        return False
    try:
        return vault.unlock_with_keyfile(key)
    finally:
        key = None


def unlock_vault(cfg, settings, unlock_callback=None):
    """Open the vault per settings. Returns (vault, method) or (None, reason)."""
    v = vault_mod.Vault(cfg.vault_path)
    v.load()
    if not v.exists():
        return None, "no vault"
    if not v.slot_ids():
        return None, "vault has no unlock slots"

    mode = settings.vault_unlock
    if mode == "local-keyfile":
        path = os.path.join(cfg.data_dir, settings.local_keyfile_name)
        if os.path.isfile(path) and _try_keyfile_unlock(v, path):
            return v, "local-keyfile"
        log.warn("local keyfile unlock failed; falling back to prompt")
        mode = "prompt"
    elif mode == "external-keyfile":
        path = settings.keyfile_path
        if path and os.path.isfile(path):
            if _try_keyfile_unlock(v, path):
                return v, "external-keyfile"
            return None, "external keyfile rejected"
        return None, "external keyfile not present: %s" % (path or "?")

    if mode == "prompt" and unlock_callback:
        pw = unlock_callback()
        if pw is None:
            return None, "unlock aborted"
        try:
            if v.unlock_with_passphrase(pw):
                return v, "prompt"
        finally:
            pw = None
        return None, "wrong master passphrase"
    return None, "unlock mode %r needs no vault or cannot run" % mode


def run_boot(manager, settings, unlock_callback=None, on_progress=None):
    """Execute auto-mount policy. Never raises; collects per-profile errors."""
    res = BootResult()
    if not settings.automount:
        res.message = "automount disabled"
        return res

    profiles = manager.profiles.auto_mount_profiles()
    if not profiles:
        res.message = "no auto-mount profiles"
        return res

    vault, how = unlock_vault(manager.cfg, settings, unlock_callback)
    if vault is None:
        res.message = "vault locked: %s" % how
        for p in profiles:
            res.skipped.append((p, "vault locked"))
        return res
    res.vault_unlocked = True
    res.unlock_method = how

    try:
        for p in profiles:
            if on_progress:
                on_progress(p)
            if not vault.has_secret(p.id):
                res.skipped.append((p, "no stored credentials"))
                continue
            secrets = manager.secrets_from_vault(vault, p)
            if secrets is None:
                res.skipped.append((p, "no stored credentials"))
                continue
            try:
                attempts = max(1, settings.mount_retries)
                last = None
                for _ in range(attempts):
                    try:
                        rec = manager.mount(p, secrets)
                        res.mounted.append((p, rec))
                        last = None
                        break
                    except AuthFailed as exc:
                        last = exc
                        break            # never retry auth failures
                    except Exception as exc:
                        last = exc       # transient -> may retry
                if last is not None:
                    res.failed.append((p, str(last)))
            finally:
                secrets.wipe()
    finally:
        vault.lock()
    res.message = "mounted=%d failed=%d skipped=%d" % (
        len(res.mounted), len(res.failed), len(res.skipped))
    return res
