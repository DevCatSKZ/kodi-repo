"""vcaddon CLI - used by the Batocera port, SSH sessions and debugging.

    python -m vcaddon.cli --data-dir DIR <command> ...

Every secret is read via getpass (never argv). The exit code is 0 on
success, 2 on auth failure, 1 on other errors.
"""

import argparse
import getpass
import json
import os
import sys

from . import automount, cmdline, devices, log, preflight, vault as vault_mod
from .errors import AuthFailed, VCError
from .manager import Config, Manager
from .profiles import Profile
from .secrets import Secret
from .settings import Settings
from .veracrypt_cli import MountSecrets


def _runtime_env(args):
    """Build the extra env for the veracrypt process tree.

    --runtime-dir DIR (or VCADDON_RUNTIME_DIR) describes a private
    deployment (<dir>/bin, <dir>/lib) like the one used on LibreELEC
    where system dirs are read-only. DM_UDEV_DISABLE_* is set because
    such systems lack udev handling of dm cookies (dmsetup would hang).
    """
    rd = getattr(args, "runtime_dir", None) or os.environ.get(
        "VCADDON_RUNTIME_DIR", "")
    env = {}
    if rd:
        b = os.path.join(rd, "bin")
        l = os.path.join(rd, "lib")
        if os.path.isdir(b):
            env["PATH"] = b + os.pathsep + os.environ.get("PATH", "")
        if os.path.isdir(l):
            prev = os.environ.get("LD_LIBRARY_PATH", "")
            env["LD_LIBRARY_PATH"] = (l + os.pathsep + prev
                                      if prev else l)
        env["DM_UDEV_DISABLE_SYNC_FLAG"] = "1"
        env["DM_UDEV_DISABLE_OTHER_RULES_FLAG"] = "1"
        env["DM_UDEV_DISABLE_SUBSYSTEM_RULES_FLAG"] = "1"
    if os.environ.get("VCADDON_DM_NO_UDEV"):
        env.setdefault("DM_UDEV_DISABLE_SYNC_FLAG", "1")
        env.setdefault("DM_UDEV_DISABLE_OTHER_RULES_FLAG", "1")
        env.setdefault("DM_UDEV_DISABLE_SUBSYSTEM_RULES_FLAG", "1")
    return env


def _kernel_crypto(args):
    v = getattr(args, "kernel_crypto", "auto") or "auto"
    return {"on": True, "off": False}.get(v, "auto")


def _config(args):
    data_dir = args.data_dir or os.environ.get(
        "VCADDON_DATA", os.path.expanduser("~/.vcaddon"))
    mount_root = args.mount_root or os.environ.get("VCADDON_MOUNT_ROOT")
    binary = args.binary
    rd = getattr(args, "runtime_dir", None) or os.environ.get(
        "VCADDON_RUNTIME_DIR", "")
    if not binary and rd:
        cand = os.path.join(rd, "bin", "veracrypt")
        if os.path.isfile(cand):
            binary = cand
    return Config(data_dir=data_dir, mount_root=mount_root,
                  veracrypt_binary=binary,
                  sudo_helper=_split(args.sudo_helper),
                  env=_runtime_env(args),
                  kernel_crypto=_kernel_crypto(args))


def _split(s):
    return s.split() if s else None


def _manager(args):
    return Manager(_config(args))


def _settings(args):
    return Settings.load(_config(args).settings_path)


def _ask_secret(prompt, required=True):
    try:
        v = getpass.getpass(prompt)
    except (EOFError, KeyboardInterrupt):
        return None
    if required and not v:
        return None
    return v


def _collect_secrets(profile, prompt=True, vault=None):
    sec = MountSecrets()
    stored = None
    if vault is not None:
        stored = vault.get_secret(profile.id)
    if stored:
        sec.password = Secret.from_text(stored.get("password") or "")
        sec.pim = Secret.from_text(stored.get("pim") or "")
        sec.hidden_password = Secret.from_text(
            stored.get("hidden_password") or "")
        sec.hidden_pim = Secret.from_text(stored.get("hidden_pim") or "")
        sec.token_pin = Secret.from_text(stored.get("token_pin") or "")
        sec.hidden_keyfiles = tuple(stored.get("hidden_keyfiles") or ())
        return sec
    if not prompt:
        return None
    pw = _ask_secret("VeraCrypt password for %s: " %
                     (profile.label or profile.identity))
    if pw is None:
        return None
    sec.password = Secret.from_text(pw)
    pw = None
    if profile.has_pim:
        pim = _ask_secret("PIM (leave empty for default): ",
                          required=False)
        sec.pim = Secret.from_text(pim or "")
    if profile.protect_hidden:
        hpw = _ask_secret("Hidden volume password: ")
        if hpw is None:
            return None
        sec.hidden_password = Secret.from_text(hpw)
        hpw = _ask_secret("Hidden volume PIM (empty=default): ",
                          required=False)
        sec.hidden_pim = Secret.from_text(hpw or "")
        sec.hidden_keyfiles = ()
    return sec


# -- commands ----------------------------------------------------------------

def cmd_preflight(args):
    cfg = _config(args)
    rep = preflight.run(veracrypt_binary=cfg.veracrypt_binary,
                        data_dir=cfg.data_dir, env=cfg.env)
    print(rep.render())
    return 0 if rep.ok else 1


def cmd_scan(args):
    mgr = _manager(args)
    devs = devices.enumerate_devices()
    print("%-14s %-7s %-9s %-18s %-10s %s" %
          ("PATH", "TYPE", "SIZE", "FS/LABEL", "TRANSP", "HINT"))
    for d in devs:
        if d.is_system:
            continue
        hint = "vc-candidate" if d.looks_encrypted else (
            "mounted" if d.mountpoints else "")
        print("%-14s %-7s %-9s %-18s %-10s %s" % (
            d.path, d.dev_type, d.size_h(),
            (d.fstype or "-") + ("/" + d.label if d.label else ""),
            d.transport or "-", hint))
    return 0


def cmd_profiles(args):
    mgr = _manager(args)
    if args.profiles_cmd == "list":
        for p in mgr.profiles.all():
            print(p.summary())
        return 0
    if args.profiles_cmd == "show":
        p = mgr.profiles.find(args.ref)
        if not p:
            print("profile not found", file=sys.stderr)
            return 1
        print(json.dumps(p.to_dict(), indent=2))
        return 0
    if args.profiles_cmd == "add":
        return _profile_add(mgr, args)
    if args.profiles_cmd == "remove":
        p = mgr.profiles.find(args.ref)
        if not p:
            print("profile not found", file=sys.stderr)
            return 1
        mgr.profiles.remove(p.id)
        print("removed %s" % p.id)
        return 0
    if args.profiles_cmd == "set":
        p = mgr.profiles.find(args.ref)
        if not p:
            print("profile not found", file=sys.stderr)
            return 1
        for k, v in (kv.split("=", 1) for kv in args.assignments):
            if not hasattr(p, k):
                print("unknown field %r" % k, file=sys.stderr)
                return 1
            cur = getattr(p, k)
            if isinstance(cur, bool):
                v = v.lower() in ("1", "true", "yes", "on")
            elif isinstance(cur, int):
                v = int(v)
            elif isinstance(cur, list):
                v = [x for x in v.split(",") if x]
            setattr(p, k, v)
        p.validate()
        mgr.profiles.update(p)
        print("updated")
        return 0
    return 1


def _profile_add(mgr, args):
    ident = args.identity
    source = "container" if os.path.isfile(ident) else "device"
    if source == "device":
        dev = devices.find_device(ident)
        if dev is None:
            print("device %s not found" % ident, file=sys.stderr)
            return 1
        sid = dev.stable_id()
        if not sid:
            print("device %s has no stable identity (no uuid/serial);"
                  " refusing - auto-mount would be unsafe" % dev.path,
                  file=sys.stderr)
            return 1
        ident = sid
    p = Profile(label=args.label or os.path.basename(ident),
                source_type=source, identity=ident,
                mount_point=args.mount_point or "",
                read_only=not args.rw,
                filesystem=args.filesystem or "",
                fs_options=args.fs_options or "",
                keyfiles=args.keyfile or [],
                has_pim=args.pim,
                protect_hidden=args.protect_hidden,
                store_secrets=args.store_secrets,
                auto_mount=args.auto_mount,
                token_lib=args.token_lib or "")
    try:
        p.validate()
    except VCError as exc:
        print("invalid profile: %s" % exc, file=sys.stderr)
        return 1
    mgr.profiles.add(p)
    print("added profile %s (%s)" % (p.id, p.summary()))
    if p.store_secrets:
        return _store_secret_interactive(mgr, p, args)
    return 0


def _store_secret_interactive(mgr, p, args):
    v = mgr.vault()
    if not v.unlocked:
        if not v.slot_ids():
            mp = _ask_secret("Choose master passphrase for the vault: ")
            mp2 = _ask_secret("Repeat master passphrase: ")
            if not mp or mp != mp2:
                print("passphrases empty or do not match",
                      file=sys.stderr)
                return 1
            v.add_passphrase_slot("master", mp)
            mp = mp2 = None
            v.unlock_with_passphrase(_ask_secret(
                "Master passphrase (to verify): ") or "")
        else:
            pw = _ask_secret("Master passphrase: ")
            if pw is None or not v.unlock_with_passphrase(pw):
                print("could not unlock vault", file=sys.stderr)
                return 1
    sec = _collect_secrets(p, prompt=True)
    if sec is None:
        print("aborted")
        return 1
    try:
        v.set_secret(p.id, {
            "password": sec.password.text(),
            "pim": sec.pim.text(),
            "hidden_password": sec.hidden_password.text(),
            "hidden_pim": sec.hidden_pim.text(),
            "token_pin": sec.token_pin.text(),
            "hidden_keyfiles": list(sec.hidden_keyfiles)})
        print("credentials stored in vault for %s" % p.id)
    finally:
        sec.wipe()
        v.lock()
    return 0


def cmd_mount(args):
    mgr = _manager(args)
    p = mgr.profiles.find(args.ref)
    if p is None:
        print("profile not found - create it with 'profiles add'",
              file=sys.stderr)
        return 1
    vault = None
    if p.store_secrets:
        v = mgr.vault()
        if v.slot_ids():
            pw = _ask_secret("Master passphrase: ")
            if pw is not None and v.unlock_with_passphrase(pw):
                vault = v
            pw = None
            if vault is None:
                lf = os.path.join(mgr.cfg.data_dir,
                                  _settings(args).local_keyfile_name)
                if os.path.isfile(lf):
                    try:
                        if v.unlock_with_keyfile(
                                vault_mod.read_keyfile(lf)):
                            vault = v
                    except VCError:
                        pass
            if vault is None:
                print("vault locked; entering password manually")
    sec = _collect_secrets(p, prompt=True, vault=vault)
    try:
        if sec is None:
            print("aborted")
            return 1
        rec = mgr.mount(p, sec)
        print("mounted %s at %s (ro=%s)" %
              (rec.volume_path, rec.mount_point, rec.read_only))
        return 0
    except AuthFailed as exc:
        print("authentication failed", file=sys.stderr)
        return 2
    except VCError as exc:
        print("mount failed: %s" % exc, file=sys.stderr)
        return 1
    finally:
        if sec:
            sec.wipe()
        if vault:
            vault.lock()


def cmd_unmount(args):
    mgr = _manager(args)
    try:
        mgr.unmount(args.ref)
        print("unmounted")
        return 0
    except VCError as exc:
        print("unmount failed: %s" % exc, file=sys.stderr)
        return 1


def cmd_unmount_all(args):
    mgr = _manager(args)
    failures = mgr.unmount_all()
    for f in failures:
        print("FAILED: %s" % f, file=sys.stderr)
    print("done (%d failures)" % len(failures))
    return 0 if not failures else 1


def cmd_status(args):
    mgr = _manager(args)
    rows = mgr.status()
    if not rows:
        print("nothing mounted")
        return 0
    for r in rows:
        flags = []
        if r.get("managed"):
            flags.append("managed")
        if r.get("stale"):
            flags.append("STALE")
        if r.get("read_only"):
            flags.append("ro")
        if r.get("hidden_protected"):
            flags.append("hidden-protected")
        print("slot %-3s %-30s -> %-40s %s %s" % (
            r.get("slot", "?"), r.get("volume", "?"),
            r.get("mount_point", "?"), ",".join(flags),
            r.get("profile_id", "")))
    return 0


def cmd_vault(args):
    mgr = _manager(args)
    v = mgr.vault()
    c = args.vault_cmd
    if c == "status":
        print("exists=%s slots=%s perms=%s" % (
            v.exists(), ",".join(v.slot_ids()) or "-",
            vault_mod.check_perms(mgr.cfg.vault_path) or "ok"))
        return 0
    if c == "slots":
        for s in v.slot_ids():
            print(s)
        return 0
    if c == "init":
        if v.exists() and v.slot_ids():
            print("vault already initialized", file=sys.stderr)
            return 1
        mp = _ask_secret("Choose master passphrase: ")
        mp2 = _ask_secret("Repeat: ")
        if not mp or mp != mp2:
            print("empty or mismatch", file=sys.stderr)
            return 1
        v.add_passphrase_slot("master", mp)
        mp = mp2 = None
        print("vault initialized at %s" % v.path)
        return 0
    if c == "remove-secret":
        pw = _ask_secret("Master passphrase: ")
        if pw is None or not v.unlock_with_passphrase(pw):
            print("unlock failed", file=sys.stderr)
            return 1
        v.remove_secret(args.ref)
        v.lock()
        print("secret removed")
        return 0
    if c == "set-secret":
        p = mgr.profiles.find(args.ref)
        if not p:
            print("profile not found", file=sys.stderr)
            return 1
        return _store_secret_interactive(mgr, p, args)
    if c == "add-keyfile":
        pw = _ask_secret("Master passphrase: ")
        if pw is None or not v.unlock_with_passphrase(pw):
            print("unlock failed", file=sys.stderr)
            return 1
        try:
            key = vault_mod.read_keyfile(args.path)
            v.add_keyfile_slot(args.slot_id or "keyfile", key)
            print("keyfile slot added")
            return 0
        except VCError as exc:
            print("failed: %s" % exc, file=sys.stderr)
            return 1
        finally:
            v.lock()
    if c == "add-local-key":
        pw = _ask_secret("Master passphrase: ")
        if pw is None or not v.unlock_with_passphrase(pw):
            print("unlock failed", file=sys.stderr)
            return 1
        print("WARNING: a keyfile stored on this device allows unattended")
        print("decryption to anyone who has the device. Prefer a keyfile")
        print("on separate USB media (external-keyfile) instead.")
        if input("Type YES to continue: ") != "YES":
            return 1
        path = os.path.join(mgr.cfg.data_dir,
                            _settings(args).local_keyfile_name)
        key = vault_mod.generate_keyfile(path)
        v.add_keyfile_slot("local-keyfile", key)
        s = _settings(args)
        s.vault_unlock = "local-keyfile"
        s.warned_local_key = True
        s.save(mgr.cfg.settings_path)
        v.lock()
        print("local keyfile slot added; vault_unlock=local-keyfile")
        return 0
    if c == "remove-slot":
        pw = _ask_secret("Master passphrase: ")
        if pw is None or not v.unlock_with_passphrase(pw):
            print("unlock failed", file=sys.stderr)
            return 1
        v.remove_slot(args.slot_id)
        v.lock()
        print("slot removed")
        return 0
    return 1


def cmd_settings(args):
    cfg = _config(args)
    s = Settings.load(cfg.settings_path)
    if args.settings_cmd == "show":
        print(json.dumps(s.to_dict(), indent=2))
        return 0
    if args.settings_cmd == "set":
        for k, v in (kv.split("=", 1) for kv in args.assignments):
            if not hasattr(s, k):
                print("unknown setting %r" % k, file=sys.stderr)
                return 1
            cur = getattr(s, k)
            if isinstance(cur, bool):
                v = v.lower() in ("1", "true", "yes", "on")
            elif isinstance(cur, int):
                v = int(v)
            setattr(s, k, v)
        s.save(cfg.settings_path)
        print("saved")
        return 0
    return 1


def cmd_automount(args):
    mgr = _manager(args)
    s = _settings(args)

    def prompt():
        return _ask_secret("Master passphrase (auto-mount): ")

    res = automount.run_boot(mgr, s, unlock_callback=prompt)
    for p, rec in res.mounted:
        print("mounted %s -> %s" % (p.id, rec.mount_point))
    for p, err in res.failed:
        print("FAILED %s: %s" % (p.id, err), file=sys.stderr)
    for p, why in res.skipped:
        print("skipped %s: %s" % (p.id, why))
    print(res.message)
    return 0 if res.ok() else 1


def cmd_shutdown(args):
    mgr = _manager(args)
    failures = mgr.shutdown()
    return 0 if not failures else 1


def build_parser():
    ap = argparse.ArgumentParser(prog="vcaddon")
    ap.add_argument("--data-dir")
    ap.add_argument("--mount-root")
    ap.add_argument("--binary", help="path to veracrypt")
    ap.add_argument("--sudo-helper", help="e.g. 'sudo -n' or a helper path")
    ap.add_argument("--runtime-dir",
                    help="private veracrypt runtime dir (<dir>/bin, "
                    "<dir>/lib); sets PATH/LD_LIBRARY_PATH and disables "
                    "dm udev sync for embedded systems")
    ap.add_argument("--kernel-crypto", choices=("auto", "on", "off"),
                    default="auto",
                    help="'off' forces -m nokernelcrypto when the kernel "
                    "lacks the dm-crypt target")
    ap.add_argument("-v", "--verbose", action="store_true")
    sub = ap.add_subparsers(dest="cmd", required=True)

    sub.add_parser("preflight").set_defaults(fn=cmd_preflight)
    sub.add_parser("scan").set_defaults(fn=cmd_scan)
    sub.add_parser("status").set_defaults(fn=cmd_status)
    sub.add_parser("unmount-all").set_defaults(fn=cmd_unmount_all)
    sub.add_parser("automount").set_defaults(fn=cmd_automount)
    sub.add_parser("shutdown").set_defaults(fn=cmd_shutdown)

    p = sub.add_parser("mount")
    p.add_argument("ref")
    p.set_defaults(fn=cmd_mount)

    p = sub.add_parser("unmount")
    p.add_argument("ref")
    p.set_defaults(fn=cmd_unmount)

    p = sub.add_parser("profiles")
    ps = p.add_subparsers(dest="profiles_cmd", required=True)
    ps.add_parser("list")
    x = ps.add_parser("show"); x.add_argument("ref")
    x = ps.add_parser("remove"); x.add_argument("ref")
    x = ps.add_parser("set"); x.add_argument("ref")
    x.add_argument("assignments", nargs="+")
    x = ps.add_parser("add")
    x.add_argument("identity", help="device (/dev/.., by-id name, uuid) "
                   "or container file path")
    x.add_argument("--label")
    x.add_argument("--mount-point")
    x.add_argument("--rw", action="store_true",
                   help="mount read-write (default: read-only)")
    x.add_argument("--filesystem")
    x.add_argument("--fs-options")
    x.add_argument("--keyfile", action="append")
    x.add_argument("--pim", action="store_true",
                   help="volume uses a custom PIM (prompted at mount)")
    x.add_argument("--protect-hidden", action="store_true")
    x.add_argument("--store-secrets", action="store_true")
    x.add_argument("--auto-mount", action="store_true")
    x.add_argument("--token-lib")
    p.set_defaults(fn=cmd_profiles)

    p = sub.add_parser("vault")
    vs = p.add_subparsers(dest="vault_cmd", required=True)
    vs.add_parser("status"); vs.add_parser("slots"); vs.add_parser("init")
    x = vs.add_parser("set-secret"); x.add_argument("ref")
    x = vs.add_parser("remove-secret"); x.add_argument("ref")
    x = vs.add_parser("add-keyfile"); x.add_argument("path")
    x.add_argument("--slot-id")
    vs.add_parser("add-local-key")
    x = vs.add_parser("remove-slot"); x.add_argument("slot_id")
    p.set_defaults(fn=cmd_vault)

    p = sub.add_parser("settings")
    ss = p.add_subparsers(dest="settings_cmd", required=True)
    ss.add_parser("show")
    x = ss.add_parser("set"); x.add_argument("assignments", nargs="+")
    p.set_defaults(fn=cmd_settings)
    return ap


def main(argv=None):
    args = build_parser().parse_args(argv)
    log.set_verbose(args.verbose)
    try:
        return args.fn(args)
    except VCError as exc:
        print("error: %s" % exc, file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    sys.exit(main())
