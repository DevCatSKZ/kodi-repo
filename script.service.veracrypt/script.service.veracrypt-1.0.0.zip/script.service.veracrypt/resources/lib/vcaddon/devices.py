"""Block device discovery and VeraCrypt-volume candidacy.

A VeraCrypt volume has NO signature - it looks like random data until a
correct password is supplied. So we can only *rank* candidates:

  * partitions/disks with NO detected filesystem  -> possible VC volume
  * devices with a detected filesystem            -> probably not VC
    (still selectable - an advanced user knows best)

System disks are always excluded: anything mounted at /, /flash,
/storage, /boot, /userdata, swap, or the disks backing them.
"""

import os
import re
import subprocess
from dataclasses import dataclass, field

from . import log

SYSTEM_LABELS = {
    "system", "libreelec", "storage", "boot", "share", "userdata",
    "recovery", "efi", "settings",
}
SYSTEM_MOUNTPOINTS = {
    "/", "/boot", "/flash", "/storage", "/userdata", "/var", "/sys",
    "/proc", "/dev", "/run", "/tmp", "/etc", "/usr", "/overlay",
}


@dataclass
class BlockDevice:
    name: str            # sda1, mmcblk0p2, ...
    path: str            # /dev/sda1
    dev_type: str        # disk|part|rom|loop|dm
    size: int = 0
    fstype: str = ""
    label: str = ""
    uuid: str = ""
    part_uuid: str = ""
    model: str = ""
    serial: str = ""
    wwn: str = ""
    transport: str = ""      # usb|mmc|sata|nvme
    hotplug: bool = False
    parent: str = ""         # parent disk for partitions
    mountpoints: tuple = ()
    by_id: tuple = ()        # /dev/disk/by-id symlinks
    is_system: bool = False
    note: str = ""

    @property
    def has_fs_signature(self):
        return bool(self.fstype)

    @property
    def looks_encrypted(self):
        """Heuristic only - VC volumes have no signature."""
        return not self.fstype and self.dev_type in ("part", "disk")

    def size_h(self):
        size = float(self.size)
        for unit in ("B", "KiB", "MiB", "GiB", "TiB", "PiB"):
            if size < 1024 or unit == "PiB":
                return "%d %s" % (size, unit) if unit == "B" \
                    else "%.1f %s" % (size, unit)
            size /= 1024.0
        return str(size)

    def stable_id(self):
        """Best available stable identity string for profiles."""
        if self.by_id:
            return "by-id:" + sorted(self.by_id)[0]
        if self.part_uuid:
            return "partuuid:" + self.part_uuid.lower()
        if self.uuid:
            return "uuid:" + self.uuid.lower()
        if self.serial:
            return "serial:%s:%s" % (self.model.strip(), self.serial)
        if self.wwn:
            return "wwn:" + self.wwn
        return ""   # no stable identity -> no safe auto-mount

    def title(self):
        bits = [self.path]
        if self.label:
            bits.append("(%s)" % self.label)
        bits.append(self.size_h())
        if self.model:
            bits.append(self.model.strip())
        fs = self.fstype or ("no FS" if self.looks_encrypted else "?")
        bits.append("[%s]" % fs)
        if self.is_system:
            bits.append("SYSTEM")
        return " ".join(bits)


def _lsblk_json():
    try:
        proc = subprocess.run(
            ["lsblk", "-J", "-b", "-O"],
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, timeout=10)
        if proc.returncode == 0 and proc.stdout.strip().startswith(b"{"):
            import json
            return json.loads(proc.stdout.decode("utf-8", "replace"))
    except (OSError, subprocess.TimeoutExpired, ValueError):
        pass
    return None


def _sysfs_list():
    """Fallback enumeration walking /sys/block directly."""
    devs = []
    base = "/sys/block"
    if not os.path.isdir(base):
        return devs

    def read(path, default=""):
        try:
            with open(path, "r", errors="replace") as fh:
                return fh.read().strip()
        except OSError:
            return default

    def read_int(path):
        try:
            return int(read(path) or 0)
        except ValueError:
            return 0

    def emit(disk, part=None):
        name = part or disk
        sdir = os.path.join(base, disk) if part is None \
            else os.path.join(base, disk, part)
        if not os.path.isdir(sdir):
            return
        size = read_int(os.path.join(sdir, "size")) * 512
        uevent = read(os.path.join(sdir, "uevent"))
        transport = ""
        if "ID_BUS=usb" in uevent or "/usb" in os.path.realpath(
                os.path.join(sdir, "device")):
            transport = "usb"
        dev = BlockDevice(
            name=name,
            path="/dev/" + name,
            dev_type="part" if part else "disk",
            size=size,
            model=read(os.path.join(base, disk, "device/model")),
            serial=read(os.path.join(base, disk, "device/serial")),
            hotplug=read(os.path.join(base, disk, "removable")) == "1",
            transport=transport,
            parent="" if part is None else disk,
        )
        devs.append(dev)
        return dev

    for disk in sorted(os.listdir(base)):
        if re.match(r"^(loop|ram|zram|dm-|sr\d)", disk):
            continue
        emit(disk)
        pdir = os.path.join(base, disk)
        for ent in sorted(os.listdir(pdir)):
            if os.path.isfile(os.path.join(pdir, ent, "partition")) \
                    and ent.startswith(disk):
                emit(disk, ent)
    return devs


def _from_lsblk(data):
    devs = []

    def conv(node, parent=""):
        mps = node.get("mountpoints") or []
        if isinstance(mps, str):
            mps = [mps]
        mps = [m for m in mps if m]
        mnt = node.get("mountpoint")
        if mnt and mnt not in mps:
            mps.append(mnt)
        dev = BlockDevice(
            name=node.get("name", "") or os.path.basename(
                node.get("path") or ""),
            path=node.get("path") or "/dev/" + (node.get("name") or ""),
            dev_type=node.get("type", ""),
            size=int(node.get("size") or 0),
            fstype=node.get("fstype") or "",
            label=node.get("label") or "",
            uuid=node.get("uuid") or "",
            part_uuid=node.get("partuuid") or node.get("partn") or "",
            model=node.get("model") or "",
            serial=node.get("serial") or "",
            wwn=node.get("wwn") or "",
            transport=node.get("tran") or "",
            hotplug=bool(node.get("hotplug")),
            parent=parent,
            mountpoints=tuple(mps),
        )
        devs.append(dev)
        for ch in node.get("children") or []:
            conv(ch, dev.name)

    for top in data.get("blockdevices", []):
        conv(top)
    return devs


def _blkid_fill(devs):
    """Add fstype/label/uuid via blkid for sysfs-listed devices."""
    try:
        proc = subprocess.run(["blkid", "-o", "export"],
                              stdout=subprocess.PIPE,
                              stderr=subprocess.DEVNULL, timeout=10)
    except (OSError, subprocess.TimeoutExpired):
        return
    cur = {}
    per_dev = {}
    for line in proc.stdout.decode("utf-8", "replace").splitlines():
        line = line.strip()
        if not line:
            if cur:
                per_dev[cur.get("DEVNAME", "")] = cur
            cur = {}
            continue
        if "=" in line:
            k, v = line.split("=", 1)
            cur[k] = v
    if cur:
        per_dev[cur.get("DEVNAME", "")] = cur
    for d in devs:
        info = per_dev.get(d.path)
        if info:
            d.fstype = info.get("TYPE", d.fstype)
            d.label = d.label or info.get("LABEL", "")
            d.uuid = d.uuid or info.get("UUID", "")
            d.part_uuid = d.part_uuid or info.get("PARTUUID", "")


def _by_id_fill(devs):
    by_path = {d.path: d for d in devs}
    base = "/dev/disk/by-id"
    try:
        entries = os.listdir(base)
    except OSError:
        return
    for ent in entries:
        full = os.path.join(base, ent)
        try:
            target = os.path.realpath(full)
        except OSError:
            continue
        dev = by_path.get(target)
        if dev is not None:
            dev.by_id = dev.by_id + (ent,)


def _mountpoints_fill(devs):
    """Read /proc/mounts (proc self-mounts) for mountpoints."""
    mps = {}
    try:
        with open("/proc/mounts", "r", errors="replace") as fh:
            for line in fh:
                parts = line.split()
                if len(parts) >= 2 and parts[0].startswith("/dev/"):
                    mps.setdefault(parts[0], []).append(parts[1])
    except OSError:
        pass
    for d in devs:
        have = set(d.mountpoints)
        for mp in mps.get(d.path, ()):
            have.add(mp)
        d.mountpoints = tuple(sorted(have))


def _mark_system(devs):
    by_name = {d.name: d for d in devs}

    def mark(d):
        d.is_system = True
        d.note = "system"

    for d in devs:
        if d.label.upper() in {s.upper() for s in SYSTEM_LABELS}:
            mark(d)
        for mp in d.mountpoints:
            if mp.rstrip("/") in SYSTEM_MOUNTPOINTS or mp == "/":
                mark(d)
    # propagate: system disk -> all partitions marked; partition -> parent
    for d in devs:
        if d.is_system:
            for c in devs:
                if c.parent == d.name or c.name == d.parent:
                    c.is_system = True
    # root disk via /proc/cmdline root= (e.g. root=/dev/mmcblk0p2 or UUID=)
    try:
        cmdline = open("/proc/cmdline", "r", errors="replace").read()
    except OSError:
        cmdline = ""
    m = re.search(r"root=(?:/dev/|PARTUUID=|UUID=)(\S+)", cmdline)
    if m:
        ref = m.group(1).split()[0]
        for d in devs:
            if d.path == "/dev/" + ref or d.uuid == ref or \
                    d.part_uuid.lower() == ref.lower():
                mark(d)
                for c in devs:
                    if c.parent == d.name or c.name == d.parent:
                        c.is_system = True


def enumerate_devices(include_system=False):
    """Return list[BlockDevice] for all visible block devices."""
    data = _lsblk_json()
    if data:
        devs = _from_lsblk(data)
        devs = [d for d in devs if not d.name.startswith(
            ("loop", "ram", "zram", "dm-"))]
        # lsblk -O usually covers blkid data; fill gaps anyway
        _blkid_fill(devs)
    else:
        devs = _sysfs_list()
        _blkid_fill(devs)
    _mountpoints_fill(devs)
    _by_id_fill(devs)
    _mark_system(devs)
    if not include_system:
        devs = [d for d in devs if not d.is_system]
    return devs


def candidates(devs=None):
    """Devices most likely to be VeraCrypt volumes, best first."""
    devs = devs if devs is not None else enumerate_devices()

    def score(d):
        if d.is_system:
            return -100
        s = 0
        if d.looks_encrypted:
            s += 10
        if d.transport == "usb" or d.hotplug:
            s += 5
        if d.dev_type == "part":
            s += 2
        if d.mountpoints:
            s -= 8
        return s

    out = [d for d in devs
           if d.dev_type in ("part", "disk") and not d.is_system]
    out.sort(key=score, reverse=True)
    return out


def find_device(ref):
    """Locate a device by path, name, by-id name, uuid or partuuid."""
    ref = str(ref)
    for d in enumerate_devices(include_system=True):
        if ref in (d.path, d.name) or ref in d.by_id:
            return d
        if ref.lower() in (d.uuid.lower(), d.part_uuid.lower()):
            return d
    # direct by-id path resolution
    if ref.startswith("/dev/disk/") or ref.startswith("by-id:"):
        p = ref if ref.startswith("/") else "/dev/disk/by-id/" + ref.split(":", 1)[1]
        try:
            real = os.path.realpath(p)
            for d in enumerate_devices(include_system=True):
                if d.path == real:
                    return d
        except OSError:
            pass
    return None


def resolve_profile_device(identity):
    """Resolve a stored stable identity to a present device (or None)."""
    if not identity:
        return None
    if identity.startswith("by-id:"):
        return find_device("by-id:" + identity.split(":", 1)[1])
    if identity.startswith("partuuid:"):
        return find_device(identity.split(":", 1)[1])
    if identity.startswith("uuid:"):
        return find_device(identity.split(":", 1)[1])
    if identity.startswith("serial:"):
        model, _, serial = identity[7:].partition(":")
        for d in enumerate_devices():
            if (d.serial or "") == serial and (d.model or "").strip() == model:
                return d
    if identity.startswith("wwn:"):
        for d in enumerate_devices():
            if d.wwn == identity[4:]:
                return d
    return None


def log_devices(devs):
    for d in devs:
        log.debug("dev %s fs=%s mp=%s sys=%s id=%s" % (
            d.path, d.fstype or "-", d.mountpoints, d.is_system,
            d.stable_id()))
