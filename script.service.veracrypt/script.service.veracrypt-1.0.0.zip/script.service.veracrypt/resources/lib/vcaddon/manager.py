"""Mount orchestration shared by CLI, TUI, Kodi addon and Batocera service.

Responsibilities:
  * resolve a profile's stable identity to a present device / container
  * enforce the mount-point policy (only under the configured root)
  * build MountSpec and drive VeraCrypt
  * track ownership in State so shutdown cleans up only our mounts
"""

import os
import re
import subprocess

from . import cmdline, devices, log, preflight
from .errors import (AuthFailed, ConfigError, MountFailed, PathPolicy,
                     VCError)
from .profiles import ProfileStore
from .secrets import Secret
from .state import MountRecord, State
from .vault import Vault
from .veracrypt_cli import MountSecrets, VeraCrypt

SAFE_NAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$")


class Config:
    """Runtime configuration. Frontends fill these values."""

    def __init__(self, data_dir, runtime_dir=None, mount_root=None,
                 veracrypt_binary=None, sudo_helper=None, env=None,
                 kernel_crypto="auto"):
        self.data_dir = data_dir
        self.runtime_dir = runtime_dir or os.path.join(data_dir, "run")
        self.mount_root = mount_root or os.path.join(data_dir, "mnt")
        self.veracrypt_binary = veracrypt_binary
        self.sudo_helper = sudo_helper
        # extra env for the veracrypt process tree (private runtime
        # libs, DM_UDEV_DISABLE_* on udev-less systems); never secrets
        self.env = dict(env or {})
        # True/False or "auto" (detect dm-crypt once, fall back to
        # nokernelcrypto when the kernel lacks the target)
        self.kernel_crypto = kernel_crypto

    @property
    def vault_path(self):
        return os.path.join(self.data_dir, "vault.json")

    @property
    def profiles_path(self):
        return os.path.join(self.data_dir, "profiles.json")

    @property
    def state_path(self):
        return os.path.join(self.runtime_dir, "state.json")

    @property
    def settings_path(self):
        return os.path.join(self.data_dir, "settings.json")

    def ensure_dirs(self):
        for d in (self.data_dir, self.runtime_dir, self.mount_root):
            os.makedirs(d, exist_ok=True)
            try:
                os.chmod(d, 0o700)
            except OSError:
                pass


class Manager:
    def __init__(self, config):
        self.cfg = config
        config.ensure_dirs()
        self.profiles = ProfileStore(config.profiles_path)
        self.state = State(config.state_path)
        self._vc = None
        self._kernel_crypto = None

    # -- plumbing ---------------------------------------------------------------
    def vc(self):
        if self._vc is None:
            self._vc = VeraCrypt(binary=self.cfg.veracrypt_binary,
                                 sudo_helper=self.cfg.sudo_helper,
                                 env=self.cfg.env)
        return self._vc

    def use_kernel_crypto(self):
        kc = self.cfg.kernel_crypto
        if kc == "auto":
            if self._kernel_crypto is None:
                self._kernel_crypto = preflight.dm_crypt_available(
                    env=self.cfg.env)
            return self._kernel_crypto
        return bool(kc)

    def vault(self):
        v = Vault(self.cfg.vault_path)
        v.load()
        return v

    def preflight(self):
        return preflight.run(veracrypt_binary=self.cfg.veracrypt_binary,
                             data_dir=self.cfg.data_dir,
                             env=self.cfg.env)

    # -- path policy --------------------------------------------------------------
    def resolve_mount_point(self, profile):
        """Profile mount_point may be absolute (must stay under
        mount_root) or empty (-> mount_root/<profile-id>)."""
        root = os.path.realpath(self.cfg.mount_root)
        mp = profile.mount_point or os.path.join(root, profile.id)
        if not os.path.isabs(mp):
            if not SAFE_NAME.match(mp):
                raise PathPolicy("invalid mount point name %r" % mp)
            mp = os.path.join(root, mp)
        real = os.path.realpath(mp)
        if real != root and not real.startswith(root + os.sep):
            raise PathPolicy(
                "mount point %r escapes managed root %r" % (mp, root))
        return real

    def _resolve_volume_path(self, profile):
        if profile.source_type == "container":
            p = profile.identity
            if not os.path.isfile(p):
                raise MountFailed("container file not found: %s" % p)
            return p, p
        dev = devices.resolve_profile_device(profile.identity)
        if dev is None:
            raise MountFailed(
                "device for %s not present" % profile.identity)
        if dev.is_system:
            raise MountFailed("refusing to mount a system device")
        return dev.path, profile.identity

    # -- secrets ----------------------------------------------------------------
    def secrets_from_vault(self, vault, profile):
        data = vault.get_secret(profile.id)
        if data is None:
            return None
        sec = MountSecrets()
        sec.password = Secret.from_text(data.get("password") or "")
        sec.pim = Secret.from_text(data.get("pim") or "")
        sec.hidden_password = Secret.from_text(
            data.get("hidden_password") or "")
        sec.hidden_pim = Secret.from_text(data.get("hidden_pim") or "")
        sec.token_pin = Secret.from_text(data.get("token_pin") or "")
        sec.hidden_keyfiles = tuple(data.get("hidden_keyfiles") or ())
        return sec

    # -- mount / unmount ---------------------------------------------------------
    def mount(self, profile, secrets):
        """secrets: MountSecrets (caller wipes). Returns MountRecord."""
        profile.validate()
        volume_path, _identity = self._resolve_volume_path(profile)
        mp = self.resolve_mount_point(profile)
        os.makedirs(mp, exist_ok=True)

        spec = cmdline.MountSpec(
            volume_path=volume_path, mount_point=mp,
            read_only=profile.read_only,
            filesystem=profile.filesystem,
            fs_options=profile.fs_options,
            slot=profile.slot,
            keyfiles=tuple(profile.keyfiles),
            protect_hidden=profile.protect_hidden,
            custom_pim=profile.has_pim,
            token_lib=profile.token_lib,
            kernel_crypto=self.use_kernel_crypto())
        log.info("mounting profile %s -> %s (ro=%s)" %
                 (profile.id, mp, profile.read_only))
        try:
            self.vc().mount(spec, secrets)
        except AuthFailed:
            raise
        except VCError:
            raise
        except Exception as exc:
            raise MountFailed("mount failed: %s" % exc)
        rec = MountRecord(profile_id=profile.id, volume_path=volume_path,
                          mount_point=mp, slot=profile.slot,
                          read_only=profile.read_only)
        self.state.add(rec)
        return rec

    def unmount(self, ref):
        """ref: profile id, mount point or volume path we own."""
        rec = self.state.find(ref)
        target = rec.mount_point if rec else ref
        self.vc().unmount(target)
        if rec:
            self.state.remove(rec.mount_point or rec.volume_path)
            self._cleanup_dir(rec.mount_point)
        return True

    def _cleanup_dir(self, mp):
        root = os.path.realpath(self.cfg.mount_root)
        real = os.path.realpath(mp)
        if real.startswith(root + os.sep):
            try:
                os.rmdir(real)
            except OSError:
                pass

    def unmount_all(self):
        """Unmount everything we own; returns list of failures."""
        failures = []
        for rec in list(self.state.all()):
            try:
                self.vc().unmount(rec.mount_point)
                self.state.remove(rec.mount_point)
                self._cleanup_dir(rec.mount_point)
            except Exception as exc:
                failures.append("%s: %s" % (rec.mount_point, exc))
        # reconcile: anything veracrypt still lists under our root
        try:
            root = os.path.realpath(self.cfg.mount_root)
            for v in self.vc().list_volumes():
                mp = os.path.realpath(v.mount_point) if v.mount_point else ""
                if mp.startswith(root + os.sep):
                    try:
                        self.vc().unmount(v.mount_point)
                    except Exception as exc:
                        failures.append("%s: %s" % (v.mount_point, exc))
        except Exception:
            pass
        return failures

    def status(self):
        ours = {r.mount_point: r for r in self.state.all()}
        try:
            live = self.vc().list_volumes()
        except Exception:
            live = []
        rows = []
        for v in live:
            rows.append({
                "slot": v.slot, "volume": v.volume,
                "mount_point": v.mount_point, "read_only": v.read_only,
                "hidden_protected": v.hidden_protected,
                "managed": v.mount_point in ours,
                "profile_id": ours.get(v.mount_point, MountRecord()).profile_id
                if v.mount_point in ours else "",
            })
        # stale records (we think mounted, veracrypt does not)
        live_mps = {v.mount_point for v in live}
        for mp, rec in ours.items():
            if mp not in live_mps:
                rows.append({"slot": rec.slot, "volume": rec.volume_path,
                             "mount_point": mp, "read_only": rec.read_only,
                             "managed": True, "stale": True,
                             "profile_id": rec.profile_id})
        return rows

    # -- shutdown -------------------------------------------------------------
    def shutdown(self):
        log.info("shutdown: unmounting managed volumes")
        failures = self.unmount_all()
        for f in failures:
            log.warn("unmount failed: %s" % f)
        return failures
