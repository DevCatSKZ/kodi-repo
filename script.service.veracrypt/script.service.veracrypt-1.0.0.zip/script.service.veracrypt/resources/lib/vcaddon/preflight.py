"""Preflight capability checks.

VeraCrypt on Linux needs (kernel side):
  * FUSE             - the VeraCrypt process serves the decrypted data
                       through a fuse-served backing file (/dev/fuse)
  * loop devices     - that backing file is attached via losetup
  * device mapper    - a linear dm target exposes /dev/mapper/veracrypt<N>
and (userspace side) the veracrypt binary plus losetup/mount/blkid and
libdevmapper/dmsetup.

Stock LibreELEC kernels often lack CONFIG_BLK_DEV_DM -> this check must
fail loudly instead of letting veracrypt produce cryptic errors.
"""

import os
import re
import shutil
import subprocess
from dataclasses import dataclass, field

from . import log


@dataclass
class Check:
    name: str
    ok: bool
    detail: str = ""
    required: bool = True


@dataclass
class Report:
    checks: list = field(default_factory=list)

    @property
    def ok(self):
        return all(c.ok for c in self.checks if c.required)

    def missing_required(self):
        return [c for c in self.checks if c.required and not c.ok]

    def render(self):
        lines = []
        for c in self.checks:
            mark = "OK " if c.ok else ("!! " if c.required else "?? ")
            detail = (" - " + c.detail) if c.detail else ""
            req = "" if c.required else " (optional)"
            lines.append("%s%-28s%s%s" % (mark, c.name, detail, req))
        lines.append("")
        lines.append("PREFLIGHT: %s" % ("PASS" if self.ok else "FAIL"))
        return "\n".join(lines)


def _exists(path):
    try:
        return os.path.exists(path)
    except OSError:
        return False


def _run(argv, timeout=10, env=None):
    try:
        penv = None
        if env:
            penv = dict(os.environ)
            penv.update(env)
        proc = subprocess.run(
            argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            timeout=timeout, env=penv,
        )
        return proc.returncode, (proc.stdout or b"").decode("utf-8", "replace")
    except (OSError, subprocess.TimeoutExpired) as exc:
        return -1, str(exc)


def check_veracrypt(binary=None, env=None):
    binary = binary or shutil.which("veracrypt")
    if not binary:
        return Check("veracrypt binary", False, "not found in PATH", True), None
    rc, out = _run([binary, "-t", "--version"], env=env)
    ver = out.strip().splitlines()[-1] if out.strip() else "?"
    ok = rc == 0
    return Check("veracrypt binary", ok, "%s (%s)" % (binary, ver), True), binary


def check_device_mapper():
    """device-mapper control node or proof the module loads."""
    if _exists("/dev/mapper/control"):
        return Check("kernel device-mapper", True, "/dev/mapper/control", True)
    # try loading the module
    if shutil.which("modprobe"):
        rc, out = _run(["modprobe", "dm_mod"]) or (-1, "")
        _run(["modprobe", "dm-mod"])
        if _exists("/dev/mapper/control"):
            return Check("kernel device-mapper", True, "loaded dm-mod", True)
    if shutil.which("dmsetup"):
        rc, out = _run(["dmsetup", "version"])
        if rc == 0:
            return Check("kernel device-mapper", True, out.strip().splitlines()[0], True)
    return Check(
        "kernel device-mapper", False,
        "missing: kernel needs CONFIG_BLK_DEV_DM (dm-mod) "
        "- stock LibreELEC images may not include it", True)


def check_loop():
    if _exists("/dev/loop-control") or _exists("/dev/loop0"):
        return Check("loop devices", True, "/dev/loop-control", True)
    if shutil.which("modprobe"):
        _run(["modprobe", "loop"])
        if _exists("/dev/loop-control") or _exists("/dev/loop0"):
            return Check("loop devices", True, "loaded loop", True)
    return Check("loop devices", False,
                 "missing: kernel needs CONFIG_BLK_DEV_LOOP", True)


def check_fuse():
    if _exists("/dev/fuse"):
        return Check("FUSE", True, "/dev/fuse", True)
    if shutil.which("modprobe"):
        _run(["modprobe", "fuse"])
        if _exists("/dev/fuse"):
            return Check("FUSE", True, "loaded fuse", True)
    return Check("FUSE", False,
                 "missing: kernel needs CONFIG_FUSE_FS", True)


def check_tools():
    missing = [t for t in ("losetup", "mount", "umount", "blkid")
               if not shutil.which(t)]
    ok = not missing
    detail = "all present" if ok else "missing: " + ", ".join(missing)
    if not shutil.which("lsblk"):
        detail += (";" if not ok else "") + " lsblk missing -> sysfs fallback"
    return Check("mount tools", ok, detail, True)


def dm_crypt_available(env=None):
    """True if the kernel offers the dm 'crypt' target (dm-crypt).

    VeraCrypt prefers dm-crypt for performance; without it volumes must
    be mounted with ``-m nokernelcrypto`` (FUSE crypto path).
    """
    if _exists("/sys/module/dm_crypt"):
        return True
    if shutil.which("modprobe"):
        _run(["modprobe", "dm_crypt"], env=env)
        _run(["modprobe", "dm-crypt"], env=env)
        if _exists("/sys/module/dm_crypt"):
            return True
    if shutil.which("dmsetup"):
        rc, out = _run(["dmsetup", "targets"], env=env)
        if rc == 0 and re.search(r"^crypt\s", out, re.M):
            return True
    return False


def check_dm_crypt(env=None):
    ok = dm_crypt_available(env=env)
    detail = ("dm-crypt target present" if ok else
              "dm-crypt missing - volumes will be mounted with "
              "'-m nokernelcrypto' (FUSE crypto path; expected on "
              "stock LibreELEC)")
    return Check("dm-crypt target", ok, detail, False)


def check_devmapper_userspace():
    if shutil.which("dmsetup"):
        return Check("dmsetup/libdevmapper", True, shutil.which("dmsetup"), False)
    # libdevmapper may still exist without the CLI
    for d in ("/usr/lib", "/usr/lib64", "/lib", "/lib64"):
        try:
            if any(f.startswith("libdevmapper") for f in os.listdir(d)):
                return Check("dmsetup/libdevmapper", True,
                             os.path.join(d, "libdevmapper"), False)
        except OSError:
            continue
    return Check("dmsetup/libdevmapper", False,
                 "not found - veracrypt may still work if it talks to "
                 "the dm ioctl directly; verify with a mount test", False)


def check_writable_dir(path):
    try:
        os.makedirs(path, exist_ok=True)
        probe = os.path.join(path, ".write-test")
        with open(probe, "w") as fh:
            fh.write("x")
        os.unlink(probe)
        return Check("data dir", True, path, True)
    except OSError as exc:
        return Check("data dir", False, "%s: %s" % (path, exc), True)


def run(veracrypt_binary=None, data_dir=None, extra_checks=(), env=None):
    rep = Report()
    c, binary = check_veracrypt(veracrypt_binary, env=env)
    rep.checks.append(c)
    rep.checks.append(check_device_mapper())
    rep.checks.append(check_loop())
    rep.checks.append(check_fuse())
    rep.checks.append(check_tools())
    rep.checks.append(check_devmapper_userspace())
    rep.checks.append(check_dm_crypt(env=env))
    if data_dir:
        rep.checks.append(check_writable_dir(data_dir))
    for fn in extra_checks:
        try:
            rep.checks.append(fn())
        except Exception as exc:  # keep preflight total
            rep.checks.append(Check("extra check", False, str(exc), False))
    if not rep.ok:
        for c in rep.missing_required():
            log.warn("preflight missing: %s - %s" % (c.name, c.detail))
    return rep
