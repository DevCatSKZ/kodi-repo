"""Mount profiles: non-secret configuration per managed volume.

Secrets live exclusively in the vault. A profile stores *which* volume,
*how* to mount it and whether its credentials are kept in the vault.
"""

import json
import os
import re
import uuid as _uuid

from .errors import ConfigError, PathPolicy

_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$")


def _new_id():
    return _uuid.uuid4().hex[:12]


class Profile:
    FIELDS = ("id", "label", "source_type", "identity", "mount_point",
              "read_only", "filesystem", "fs_options", "keyfiles",
              "has_pim", "protect_hidden", "store_secrets", "auto_mount",
              "enabled", "slot", "token_lib", "notes")

    def __init__(self, **kw):
        self.id = kw.get("id") or _new_id()
        self.label = kw.get("label", "")
        # "device" (whole disk/partition via stable identity) or
        # "container" (a .hc/.vc file on an already-mounted filesystem)
        self.source_type = kw.get("source_type", "device")
        # device: stable id from devices.BlockDevice.stable_id()
        # container: absolute file path
        self.identity = kw.get("identity", "")
        self.mount_point = kw.get("mount_point", "")
        self.read_only = bool(kw.get("read_only", True))
        self.filesystem = kw.get("filesystem", "")
        self.fs_options = kw.get("fs_options", "")
        self.keyfiles = list(kw.get("keyfiles") or [])
        self.has_pim = bool(kw.get("has_pim", False))
        self.protect_hidden = bool(kw.get("protect_hidden", False))
        self.store_secrets = bool(kw.get("store_secrets", False))
        self.auto_mount = bool(kw.get("auto_mount", False))
        self.enabled = bool(kw.get("enabled", True))
        self.slot = int(kw.get("slot") or 0)
        self.token_lib = kw.get("token_lib", "")
        self.notes = kw.get("notes", "")

    # -- serialization -------------------------------------------------------
    def to_dict(self):
        return {k: getattr(self, k) for k in self.FIELDS}

    @classmethod
    def from_dict(cls, d):
        if not isinstance(d, dict):
            raise ConfigError("profile entry is not an object")
        known = {k: v for k, v in d.items() if k in cls.FIELDS}
        return cls(**known)

    # -- validation -----------------------------------------------------------
    def validate(self):
        errs = []
        if not _ID_RE.match(self.id or ""):
            errs.append("invalid profile id %r" % self.id)
        if self.source_type not in ("device", "container"):
            errs.append("source_type must be 'device' or 'container'")
        if not self.identity:
            errs.append("missing identity (device id or container path)")
        if self.source_type == "container":
            p = self.identity
            segs = p.replace("\\", "/").split("/")
            if not os.path.isabs(p) or ".." in segs:
                errs.append("container path must be absolute, no '..'")
        if self.source_type == "device":
            if not self.identity.startswith(
                    ("by-id:", "partuuid:", "uuid:", "serial:", "wwn:")):
                errs.append("device identity must be a stable id "
                            "(by-id:/partuuid:/uuid:/serial:/wwn:) - "
                            "raw /dev paths are not persistent")
        if self.auto_mount and not self.store_secrets:
            errs.append("auto_mount requires store_secrets")
        if self.protect_hidden and self.read_only is False:
            # writable + protection is legal; writable without
            # protection is what endangers a hidden volume
            pass
        if self.mount_point:
            for bad in ("\n", "\x00"):
                if bad in self.mount_point:
                    errs.append("mount_point contains illegal chars")
        if errs:
            raise ConfigError("; ".join(errs))
        return True

    def summary(self):
        return "%s [%s] %s ro=%s auto=%s secrets=%s" % (
            self.label or self.id, self.source_type, self.identity,
            self.read_only, self.auto_mount, self.store_secrets)


class ProfileStore:
    def __init__(self, path):
        self.path = path
        self._profiles = {}
        self.load()

    def load(self):
        self._profiles = {}
        if not os.path.exists(self.path):
            return
        with open(self.path, "r", encoding="utf-8") as fh:
            doc = json.load(fh)
        for d in doc.get("profiles", []):
            p = Profile.from_dict(d)
            self._profiles[p.id] = p

    def save(self):
        doc = {"version": 1,
               "profiles": [p.to_dict() for p in
                            sorted(self._profiles.values(),
                                   key=lambda p: p.label or p.id)]}
        tmp = self.path + ".tmp"
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        try:
            os.write(fd, json.dumps(doc, indent=2).encode("utf-8"))
            os.fsync(fd)
        finally:
            os.close(fd)
        os.replace(tmp, self.path)
        try:
            os.chmod(self.path, 0o600)
        except OSError:
            pass

    def all(self):
        return list(self._profiles.values())

    def get(self, pid):
        return self._profiles.get(pid)

    def find(self, ref):
        """By id, label or identity."""
        for p in self._profiles.values():
            if ref in (p.id, p.label, p.identity):
                return p
        return None

    def add(self, profile):
        profile.validate()
        if profile.id in self._profiles:
            raise ConfigError("profile id %s exists" % profile.id)
        self._profiles[profile.id] = profile
        self.save()
        return profile

    def update(self, profile):
        profile.validate()
        self._profiles[profile.id] = profile
        self.save()
        return profile

    def remove(self, pid):
        p = self._profiles.pop(pid, None)
        if p:
            self.save()
        return p

    def auto_mount_profiles(self):
        return [p for p in self.all()
                if p.enabled and p.auto_mount and p.store_secrets]
