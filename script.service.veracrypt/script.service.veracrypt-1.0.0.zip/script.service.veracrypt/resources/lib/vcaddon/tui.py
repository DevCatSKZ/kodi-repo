"""Simple text UI (numbered menus) for terminals without Kodi.

Used by the Batocera "Ports" launcher and SSH sessions. No curses
dependency - pure stdin/stdout so it also works over serial consoles.
"""

import os
import sys

from . import cli, devices
from .manager import Config, Manager
from .secrets import Secret


def _pause():
    try:
        input("\n[Enter] ")
    except EOFError:
        pass


def _menu(title, entries):
    """entries: list of (label, callable|None). Returns when back chosen."""
    while True:
        print("\n=== %s ===" % title)
        for i, (label, _) in enumerate(entries, 1):
            print(" %d) %s" % (i, label))
        print(" 0) Back")
        try:
            sel = input("> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return
        if sel in ("0", "", "q"):
            return
        try:
            idx = int(sel) - 1
        except ValueError:
            continue
        if 0 <= idx < len(entries):
            fn = entries[idx][1]
            if fn:
                try:
                    fn()
                except Exception as exc:
                    print("error: %s" % exc)
                _pause()


def run(data_dir=None, mount_root=None, binary=None):
    cfg = Config(data_dir or os.environ.get(
        "VCADDON_DATA", os.path.expanduser("~/.vcaddon")),
        mount_root=mount_root or os.environ.get("VCADDON_MOUNT_ROOT"),
        veracrypt_binary=binary)
    mgr = Manager(cfg)

    def sh(argv):
        return cli.main(argv + (["--data-dir", cfg.data_dir]
                                if cfg.data_dir else []) or argv)

    def _scan(): sh(["scan", "--data-dir", cfg.data_dir])
    def _status(): sh(["status", "--data-dir", cfg.data_dir])
    def _preflight(): sh(["preflight", "--data-dir", cfg.data_dir])
    def _profiles(): sh(["profiles", "list", "--data-dir", cfg.data_dir])
    def _unmount_all(): sh(["unmount-all", "--data-dir", cfg.data_dir])
    def _automount(): sh(["automount", "--data-dir", cfg.data_dir])

    def _mount():
        sh(["profiles", "list", "--data-dir", cfg.data_dir])
        ref = input("profile id/label: ").strip()
        if ref:
            sh(["mount", ref, "--data-dir", cfg.data_dir])

    def _unmount():
        sh(["status", "--data-dir", cfg.data_dir])
        ref = input("mount point/profile to unmount: ").strip()
        if ref:
            sh(["unmount", ref, "--data-dir", cfg.data_dir])

    def _add_device():
        _scan()
        ident = input("device path/uuid for profile: ").strip()
        if not ident:
            return
        argv = ["profiles", "add", ident, "--data-dir", cfg.data_dir]
        if input("read-write? [y/N] ").strip().lower() == "y":
            print("NOTE: writing to an outer volume can DESTROY a")
            print("hidden volume inside unless hidden-volume")
            print("protection is enabled.")
            if input("enable hidden protection? [y/N] "
                     ).strip().lower() == "y":
                argv.append("--protect-hidden")
            argv.append("--rw")
        if input("custom PIM? [y/N] ").strip().lower() == "y":
            argv.append("--pim")
        if input("store credentials in vault? [y/N] "
                 ).strip().lower() == "y":
            argv.append("--store-secrets")
            if input("auto-mount at boot? [y/N] ").strip().lower() == "y":
                argv.append("--auto-mount")
        label = input("label (optional): ").strip()
        if label:
            argv += ["--label", label]
        sh(argv)

    def _add_container():
        path = input("container file path: ").strip()
        if path:
            _add_device_with(path)

    def _add_device_with(path):
        argv = ["profiles", "add", path, "--data-dir", cfg.data_dir]
        if input("read-write? [y/N] ").strip().lower() == "y":
            argv.append("--rw")
        if input("store credentials? [y/N] ").strip().lower() == "y":
            argv.append("--store-secrets")
            if input("auto-mount at boot? [y/N] ").strip().lower() == "y":
                argv.append("--auto-mount")
        sh(argv)

    def _vault_menu():
        _menu("Vault", [
            ("status", lambda: sh(["vault", "status",
                                   "--data-dir", cfg.data_dir])),
            ("init (master passphrase)",
             lambda: sh(["vault", "init", "--data-dir", cfg.data_dir])),
            ("add keyfile slot (external media)",
             lambda: _vault_keyfile()),
            ("add LOCAL keyfile slot (convenience, weaker)",
             lambda: sh(["vault", "add-local-key",
                         "--data-dir", cfg.data_dir])),
            ("store credentials for a profile",
             lambda: _vault_store()),
            ("remove stored credentials",
             lambda: _vault_remove()),
        ])

    def _vault_keyfile():
        path = input("keyfile path (on USB media): ").strip()
        if path:
            sh(["vault", "add-keyfile", path,
                "--data-dir", cfg.data_dir])

    def _vault_store():
        sh(["profiles", "list", "--data-dir", cfg.data_dir])
        ref = input("profile id: ").strip()
        if ref:
            sh(["vault", "set-secret", ref,
                "--data-dir", cfg.data_dir])

    def _vault_remove():
        ref = input("profile id: ").strip()
        if ref:
            sh(["vault", "remove-secret", ref,
                "--data-dir", cfg.data_dir])

    def _settings_menu():
        def setv(k, vals):
            v = input("%s %s: " % (k, vals)).strip()
            if v:
                sh(["settings", "set", "%s=%s" % (k, v),
                    "--data-dir", cfg.data_dir])
        _menu("Settings", [
            ("show", lambda: sh(["settings", "show",
                                 "--data-dir", cfg.data_dir])),
            ("automount on/off", lambda: setv("automount", "[true/false]")),
            ("vault unlock mode",
             lambda: setv("vault_unlock",
                          "[prompt/local-keyfile/external-keyfile/none]")),
            ("external keyfile path",
             lambda: setv("keyfile_path", "<path>")),
        ])

    _menu("VeraCrypt Manager", [
        ("Preflight check", _preflight),
        ("Scan devices", _scan),
        ("Profiles", _profiles),
        ("Add profile: device", _add_device),
        ("Add profile: container file", _add_container),
        ("Mount", _mount),
        ("Unmount", _unmount),
        ("Unmount all", _unmount_all),
        ("Status", _status),
        ("Auto-mount now", _automount),
        ("Vault", _vault_menu),
        ("Settings", _settings_menu),
    ])


if __name__ == "__main__":
    run()
