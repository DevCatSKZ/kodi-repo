"""Addon-wide settings (non-secret, JSON)."""

import json
import os

UNLOCK_MODES = ("prompt", "local-keyfile", "external-keyfile", "none")


class Settings:
    FIELDS = ("automount", "vault_unlock", "keyfile_path",
              "local_keyfile_name", "prompt_at_start", "mount_retries",
              "default_read_only", "warned_local_key")

    def __init__(self, **kw):
        # "prompt" = ask master passphrase once, then auto-mount
        # "local-keyfile" = unattended via keyfile stored next to vault
        #                   (convenience; weak vs. theft of the device)
        # "external-keyfile" = unattended via keyfile on separate media
        # "none" = never unlock automatically
        self.automount = bool(kw.get("automount", False))
        self.vault_unlock = kw.get("vault_unlock", "prompt")
        self.keyfile_path = kw.get("keyfile_path", "")
        self.local_keyfile_name = kw.get("local_keyfile_name",
                                         "local-vault.key")
        self.prompt_at_start = bool(kw.get("prompt_at_start", True))
        self.mount_retries = int(kw.get("mount_retries", 1))
        self.default_read_only = bool(kw.get("default_read_only", True))
        self.warned_local_key = bool(kw.get("warned_local_key", False))

    def to_dict(self):
        return {k: getattr(self, k) for k in self.FIELDS}

    @classmethod
    def from_dict(cls, d):
        return cls(**{k: v for k, v in (d or {}).items() if k in cls.FIELDS})

    @classmethod
    def load(cls, path):
        try:
            with open(path, "r", encoding="utf-8") as fh:
                return cls.from_dict(json.load(fh))
        except (OSError, ValueError):
            return cls()

    def save(self, path):
        tmp = path + ".tmp"
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        try:
            os.write(fd, json.dumps(self.to_dict(), indent=2).encode())
        finally:
            os.close(fd)
        os.replace(tmp, path)
