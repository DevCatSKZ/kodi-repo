# -*- coding: utf-8 -*-
"""Gemeinsames für Dienst (service.py) und Menü (default.py): Pfade, Texte, Einstellungen, Status."""

import json
import os
import platform
import signal
import stat
import struct
import time

import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon('service.skzconnect')
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_PATH = ADDON.getAddonInfo('path')
DATA_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
ICON = os.path.join(ADDON_PATH, 'resources', 'icon.png')
SETTINGS_JSON = os.path.join(DATA_DIR, 'settings.json')
STATUS_JSON = os.path.join(DATA_DIR, 'status.json')
LOG_FILE = os.path.join(DATA_DIR, 'skzconnect.log')
PID_FILE = os.path.join(DATA_DIR, 'skzconnect.pid')

# Werte von "bluetooth" in status.json (gleich bei Linux-Dienst, Windows- und Android-App). "no_le": Adapter ohne
# Bluetooth LE – Switch-2-Controller gehen nicht, klassische Controller schon.
BLUETOOTH_STATES = ('on', 'off', 'missing', 'no_le')

# Prozessorfamilie (Kernel, platform.machine()) → .NET-Laufzeitkennungen des mitgelieferten Programms.
_X64 = ('x86_64', 'amd64')
_ARM = ('aarch64', 'arm64', 'armv7l', 'armv8l', 'armv7', 'armv8')


def text(string_id, *args):
    """Übersetzter Text aus strings.po; {0}, {1} … werden ersetzt."""
    value = ADDON.getLocalizedString(string_id)
    return value.format(*args) if args else value


def log(message, level=xbmc.LOGINFO):
    xbmc.log('[SKZ Connect] ' + message, level)


def machine():
    return platform.machine().lower()


def is_windows():
    """Kodi läuft unter Windows: Dort verbindet die SKZ-Connect-App die Controller selbst und schreibt
    status.json in diesen Datenordner – das Add-on startet keinen Dienst, sondern zeigt den Stand nur an."""
    return os.name == 'nt'


def has_daemon():
    """Der SKZ-Connect-Dienst (BlueZ/uinput) gibt es nur unter echtem Linux. Auf anderen Systemen läuft das Add-on
    im Begleitmodus: Es zeigt eine status.json an, die eine SKZ-Connect-App schreibt. Achtung: platform.system()
    meldet auf Android 'Linux' – darum wird Kodi gezielt gefragt."""
    if xbmc.getCondVisibility('System.Platform.Android'):
        return False
    return platform.system() == 'Linux'


def kodi_platform():
    """System, auf dem Kodi läuft: 'windows' | 'android' | 'linux' | 'osx' | 'ios' | 'tvos' | 'other'."""
    if xbmc.getCondVisibility('System.Platform.Android'):
        return 'android'
    if os.name == 'nt':
        return 'windows'
    for name, condition in (('tvos', 'System.Platform.TVOS'), ('ios', 'System.Platform.IOS'),
                            ('osx', 'System.Platform.OSX')):
        if xbmc.getCondVisibility(condition):
            return name
    return 'linux' if platform.system() == 'Linux' else 'other'


def status_platform(status):
    """Wer die status.json schreibt: Feld "platform" ('windows' | 'android' | 'linux'); ältere Schreiber ohne das
    Feld → Kodis eigene Plattform."""
    value = (status or {}).get('platform')
    return value if value in ('windows', 'android', 'linux') else kodi_platform()


def system_name():
    """Anzeigename eines Systems ohne SKZ Connect (für „nur Anzeige“)."""
    return {'osx': 'macOS', 'ios': 'iOS', 'tvos': 'tvOS'}.get(kodi_platform()) or platform.system() or '?'


def bluetooth_hint(status):
    """Hinweis (Titel, Text) zum Bluetooth-Zustand oder None. Der Text passt zum System, das die status.json
    schreibt: LibreELEC/Linux, Windows oder Android. Die Controllerliste wird trotzdem immer angezeigt."""
    state = status.get('bluetooth')
    if state == 'no_le':
        return text(30634), text(30635)
    if state not in ('off', 'missing'):
        return None
    system = status_platform(status)
    if system == 'windows':
        detail = text(30662 if state == 'off' else 30664)
    elif system == 'android':
        detail = text(30663)
    else:
        detail = text(30609 if state == 'off' else 30611)
    return text(30608 if state == 'off' else 30610), detail


def companion_hint():
    """(Titel, Text), wenn im Begleitmodus kein Status da ist – je nach System, auf dem Kodi läuft."""
    system = kodi_platform()
    if system == 'windows':
        return text(30660), text(30661)
    if system == 'android':
        return text(30660), text(30668)
    return text(30666), text(30667, system_name())  # macOS & Co.: SKZ Connect gibt es dort nicht – nur Anzeige


def runtime_ids():
    """.NET-Laufzeitkennungen in Prüf-Reihenfolge. Entscheidend ist die Bitbreite des Userlands – die von Kodis
    Python-Prozess (struct.calcsize('P')) –, nicht die des Kernels: Ein 64-Bit-Kernel mit 32-Bit-System (z. B.
    Raspberry Pi OS 32 Bit auf Pi 4/5) braucht linux-arm. Die andere ARM-Variante bleibt als Rückfall."""
    m = machine()
    if m in _X64:
        return ['linux-x64']
    if m in _ARM:
        return ['linux-arm64', 'linux-arm'] if struct.calcsize('P') == 8 else ['linux-arm', 'linux-arm64']
    return []


def binary_candidates():
    """Mitgelieferte SKZ-Connect-Programme für diesen Prozessor in Prüf-Reihenfolge (leer = keins). Setzt das
    Ausführungsrecht, das beim Entpacken des Add-on-Archivs verloren geht."""
    if not has_daemon():
        return []  # anderes System (Windows, Android, macOS) – kein mitgeliefertes Programm dafür
    paths = [os.path.join(ADDON_PATH, 'bin', rid, 'skzconnect') for rid in runtime_ids()]
    paths.append(os.path.join(ADDON_PATH, 'bin', 'skzconnect'))
    result = []
    for candidate in paths:
        if not os.path.isfile(candidate):
            continue
        try:
            mode = os.stat(candidate).st_mode
            if not mode & stat.S_IXUSR:
                os.chmod(candidate, mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
        except OSError as e:
            log('Ausführungsrecht für {0}: {1}'.format(candidate, e), xbmc.LOGWARNING)
        result.append(candidate)
    return result


# ---------- Programm aus einer früheren Kodi-Sitzung ----------

def write_pid(pid):
    try:
        with open(PID_FILE, 'w') as f:
            f.write(str(pid))
    except OSError as e:
        log('skzconnect.pid: {0}'.format(e), xbmc.LOGWARNING)


def clear_pid():
    try:
        os.remove(PID_FILE)
    except OSError:
        pass


def _is_skzconnect(pid):
    """Gehört die PID wirklich zu SKZ Connect mit diesem Datenordner? (PIDs werden wiederverwendet.)"""
    try:
        with open('/proc/{0}/cmdline'.format(pid), 'rb') as f:
            args = f.read().decode('utf-8', 'replace').split('\0')
    except OSError:
        return False
    return os.path.basename(args[0]) == 'skzconnect' and DATA_DIR in args


def stop_leftover():
    """Läuft noch ein SKZ-Connect-Programm aus einer früheren Kodi-Sitzung (Kodi abgestürzt), es vor dem Start
    beenden – sonst halten zwei Programme dieselben Controller und den DSU-Port, und beide schreiben status.json."""
    try:
        with open(PID_FILE, 'r') as f:
            pid = int(f.read().strip())
    except (OSError, ValueError):
        return
    if pid > 1 and _is_skzconnect(pid):
        log('altes SKZ-Connect-Programm (PID {0}) läuft noch – wird beendet'.format(pid), xbmc.LOGWARNING)
        try:
            os.kill(pid, signal.SIGTERM)  # trennt die Controller sauber und entfernt die virtuellen Controller
            for _ in range(40):
                time.sleep(0.2)
                if not _is_skzconnect(pid):
                    break
            else:
                os.kill(pid, signal.SIGKILL)
        except OSError as e:
            log('altes SKZ-Connect-Programm: {0}'.format(e), xbmc.LOGWARNING)
    clear_pid()


def environment():
    """Umgebung für das .NET-Programm: Entpackordner im Add-on-Datenordner, keine Diagnose-Sockets in /tmp."""
    env = dict(os.environ)
    env['DOTNET_BUNDLE_EXTRACT_BASE_DIR'] = os.path.join(DATA_DIR, 'cache')
    env['DOTNET_EnableDiagnostics'] = '0'
    env['DOTNET_gcServer'] = '0'
    env['DOTNET_GCConserveMemory'] = '5'
    return env


def ensure_data_dir():
    if not os.path.isdir(DATA_DIR):
        os.makedirs(DATA_DIR)


def install_buttonmaps():
    """Kodi-Belegung für den virtuellen Controller in den Benutzerordner von peripheral.joystick kopieren – nur wenn
    dort noch keine liegt (eine in Kodi angepasste Belegung wird nie überschrieben)."""
    source_root = os.path.join(ADDON_PATH, 'resources', 'buttonmaps')
    target_root = xbmcvfs.translatePath(
        'special://profile/addon_data/peripheral.joystick/resources/buttonmaps/xml/')
    for provider in os.listdir(source_root):
        target_dir = os.path.join(target_root, provider)
        for name in os.listdir(os.path.join(source_root, provider)):
            target = os.path.join(target_dir, name)
            if os.path.exists(target):
                continue
            if not os.path.isdir(target_dir):
                os.makedirs(target_dir)
            with open(os.path.join(source_root, provider, name), 'rb') as src, open(target, 'wb') as dst:
                dst.write(src.read())
            log('Kodi-Belegung installiert: ' + target)


# ---------- Einstellungen: Kodi-Add-on → settings.json (gleiche Datei wie unter Windows/Android) ----------

_LAYOUTS = ['Xbox', 'Switch2']
_GYRO_MODES = ['Off', 'Always', 'WhileAiming']
_INACTIVITY = [0, 5, 10, 15, 30, 60]


def _setting_int(settings, key, default):
    try:
        return settings.getInt(key)
    except Exception:  # noqa: BLE001 – ältere/fehlende Einstellung
        return default


def _setting_bool(settings, key, default):
    try:
        return settings.getBool(key)
    except Exception:  # noqa: BLE001
        return default


def write_settings_json():
    """Überträgt die Add-on-Einstellungen in settings.json. Andere Einträge (z. B. aus Windows übernommene
    Tastenbelegungen) bleiben erhalten. Der Dienst lädt die Datei bei Änderungen selbst neu."""
    ensure_data_dir()
    data = {}
    try:
        with open(SETTINGS_JSON, 'r', encoding='utf-8-sig') as f:
            data = json.load(f)
    except (OSError, ValueError):
        data = {}
    s = xbmcaddon.Addon(ADDON_ID).getSettings()
    data['Layout'] = _LAYOUTS[min(max(_setting_int(s, 'layout', 0), 0), 1)]
    data['StickDeadzone'] = round(_setting_int(s, 'stick_deadzone', 6) / 100.0, 3)
    data['CombineJoyCons'] = _setting_bool(s, 'combine_joycons', True)
    data['GyroStick'] = _GYRO_MODES[min(max(_setting_int(s, 'gyro_stick', 0), 0), 2)]
    data['GyroStickFullSpeed'] = float(max(_setting_int(s, 'gyro_speed', 150), 30))
    data['GyroStickInvertY'] = _setting_bool(s, 'gyro_invert_y', False)
    data['RumbleEnabled'] = _setting_bool(s, 'rumble', True)
    data['RumbleStrength'] = round(_setting_int(s, 'rumble_strength', 80) / 100.0, 2)
    data['AutoPair'] = _setting_bool(s, 'auto_pair', True)
    data['GameLeds'] = _setting_bool(s, 'player_leds', True)
    data['ConnectFeedback'] = _setting_bool(s, 'connect_feedback', True)
    data['AutoPairGamepads'] = _setting_bool(s, 'auto_pair_gamepads', True)
    data['BackgroundScan'] = _setting_bool(s, 'background_scan', True)
    data['BatteryWarning'] = _setting_bool(s, 'battery_warning', True)
    data['DsuServer'] = _setting_bool(s, 'dsu_server', True)
    data['DsuNetwork'] = _setting_bool(s, 'dsu_network', False)
    data['InactivityMinutes'] =_INACTIVITY[min(max(_setting_int(s, 'inactivity', 0), 0), len(_INACTIVITY) - 1)]
    temp = SETTINGS_JSON + '.kodi.tmp'
    with open(temp, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    os.replace(temp, SETTINGS_JSON)


# Kodi-Aktionen für Controller-Tasten (Reihenfolge = Optionen 0…10 in settings.xml)
BUTTON_ACTIONS = [
    None, 'TakeScreenshot', 'ActivateWindow(Home)', 'Action(ContextMenu)', 'Action(Info)', 'PlayerControl(Play)',
    'PlayerControl(Stop)', 'Mute', 'ActivateWindow(ShutdownMenu)', 'RunScript(service.skzconnect)', 'Action(FullScreen)',
]
BUTTON_SETTINGS = {'Capture': ('capture_action', 1), 'C': ('c_action', 9), 'GL': ('gl_action', 0), 'GR': ('gr_action', 0)}


def button_action(button):
    """Kodi-Befehl für eine Controller-Taste (oder None)."""
    key, default = BUTTON_SETTINGS.get(button, (None, 0))
    if key is None:
        return None
    index = _setting_int(xbmcaddon.Addon(ADDON_ID).getSettings(), key, default)
    return BUTTON_ACTIONS[index] if 0 <= index < len(BUTTON_ACTIONS) else None


def adapter_setting():
    try:
        return xbmcaddon.Addon(ADDON_ID).getSettings().getString('adapter').strip()
    except Exception:  # noqa: BLE001
        return ''


def notifications_enabled():
    return _setting_bool(xbmcaddon.Addon(ADDON_ID).getSettings(), 'notifications', True)


# ---------- Status ----------

def _status_candidates():
    """Alle Orte, an denen eine status.json liegen kann. Unter Android darf die SKZ-Connect-App nicht in
    Kodis Datenordner schreiben – sie legt die Datei im gemeinsamen Dokumente-Ordner ab (bis Android 10
    alternativ in ihrem externen App-Ordner)."""
    yield STATUS_JSON
    if xbmc.getCondVisibility('System.Platform.Android'):
        yield '/sdcard/Documents/SKZ-Connect/status.json'
        yield '/sdcard/Android/data/com.devcatskz.skzconnect/files/status.json'


def read_status():
    """Frischeste lesbare status.json; None, wenn nichts läuft (Datei fehlt, veraltet oder „stopped“).
    {"state": "starting"} heißt: das Programm wird gerade (neu) gestartet."""
    status = None
    age = None
    for path in _status_candidates():
        try:
            with open(path, 'r', encoding='utf-8') as f:
                candidate = json.load(f)
            candidate_age = time.time() - os.path.getmtime(path)
        except (OSError, ValueError):
            continue
        if age is None or candidate_age < age:
            status, age = candidate, candidate_age
    if status is None:
        return None
    state = status.get('state')
    if state == 'running' and age <= 15 or state == 'starting' and age <= 60:
        return status
    return None


def mark_starting():
    """Vor dem Start des Programms: das Menü zeigt „startet …“ statt „läuft nicht“."""
    ensure_data_dir()
    temp = STATUS_JSON + '.kodi.tmp'
    with open(temp, 'w', encoding='utf-8') as f:
        json.dump({'state': 'starting'}, f)
    os.replace(temp, STATUS_JSON)


def send_command(command):
    """Befehl an den laufenden Dienst (über Kodis Benachrichtigungen, der Dienst leitet ihn an SKZ Connect weiter)."""
    xbmc.executebuiltin('NotifyAll({0},{1})'.format(ADDON_ID, command))


def read_log_tail(lines=300):
    try:
        with open(LOG_FILE, 'r', encoding='utf-8', errors='replace') as f:
            return ''.join(f.readlines()[-lines:])
    except OSError:
        return ''


# ---------- Icons je Controller-Art ----------

ICONS_DIR = os.path.join(ADDON_PATH, 'resources', 'icons')
def fingerprint(status):
    """Nur das, was Menü und Widget sichtbar anzeigen (ohne die ständig schwankende Berichtsrate) – ändert sich der
    Wert, lohnt sich ein Neuladen der Anzeige; alle 5 s neu geschriebene status.json allein nicht."""
    if status is None:
        return None
    return (
        status.get('state'), status.get('bluetooth'), bool(status.get('scanning')), bool(status.get('connecting')),
        tuple(sorted(f.get('address', '') for f in status.get('elsewhere', []))),
        tuple((p.get('player'), p.get('name'), p.get('battery'), bool(p.get('charging')),
               tuple((d.get('address'), d.get('kind'), d.get('battery')) for d in p.get('devices', [])))
              for p in status.get('players', [])),
        tuple((g.get('address'), g.get('name'), bool(g.get('connected')), g.get('battery'))
              for g in status.get('gamepads', [])),
        tuple((k.get('address'), k.get('kind'), bool(k.get('connected'))) for k in status.get('known', [])),
    )


# Kurze Namen für Widget-Kacheln – der volle Anzeigename („Nintendo Switch 2 Joy-Con (L)“)
# wird auf dem Home-Bildschirm abgeschnitten.
_KIND_SHORT = {
    'JoyCon2Left': 'Joy-Con 2 (L)', 'JoyCon2Right': 'Joy-Con 2 (R)',
    'JoyCon1Left': 'Joy-Con (L)', 'JoyCon1Right': 'Joy-Con (R)',
    'JoyConPair': 'Joy-Con (L+R)',
    'Pro2': 'Pro Controller 2', 'Pro1': 'Pro Controller', 'WiiUPro': 'Wii U Pro',
    'GameCube2': 'GameCube',
    'NesController': 'NES', 'SnesController': 'SNES',
    'N64Controller': 'N64', 'MegaDrive': 'Mega Drive',
    'WiiRemote': 'Wii Remote',
    'DualShock4': 'DualShock 4', 'DualSense': 'DualSense',
    'XboxController': 'Xbox',
}


def short_name(kind, name=''):
    return _KIND_SHORT.get(kind) or (name or 'Controller')


_KIND_ICONS = {
    'JoyCon2Left': 'jc2_links_hochkant.png', 'JoyCon2Right': 'jc2_rechts_hochkant.png',
    'JoyCon1Left': 'jc1_links_hochkant.png', 'JoyCon1Right': 'jc1_rechts_hochkant.png',
    'JoyConPair': 'jc2_paar.png',
    'Pro2': 'pro2.png', 'Pro1': 'pro1.png', 'WiiUPro': 'wiiupro.png',
    'GameCube2': 'gamecube.png',
    'DualShock4': 'dualshock4.png', 'DualSense': 'dualsense.png',
    'XboxController': 'xbox.png',
    'NesController': 'nes.png', 'SnesController': 'snes.png', 'N64Controller': 'n64.png',
    'MegaDrive': 'megadrive.png', 'WiiRemote': 'wii.png', 'Unknown': 'pro1.png',
}


def kind_icon(kind, name=''):
    """Icon-Datei zur Controller-Art; Fremd-Gamepads (Xbox, PlayStation …) anhand des Namens."""
    if kind in _KIND_ICONS:
        return os.path.join(ICONS_DIR, _KIND_ICONS[kind])
    lower = (name or '').lower()
    if 'joy-con' in lower:
        return os.path.join(ICONS_DIR, 'joycon_l.png' if '(l' in lower else 'joycon_r.png')
    for key, icon in (('xbox', 'xbox.png'), ('dualsense', 'dualsense.png'), ('playstation', 'dualshock4.png'),
                      ('dualshock', 'dualshock4.png'), ('gamecube', 'gamecube.png')):
        if key in lower:
            return os.path.join(ICONS_DIR, icon)
    return os.path.join(ICONS_DIR, 'gamepad.png')


def offline_icon(path):
    """Ausgegraute Variante eines Icons (für Controller, die bekannt, aber gerade nicht verbunden sind)."""
    off = path.replace('.png', '_off.png')
    return off if os.path.isfile(off) else path


def player_icon(player):
    """Icon für einen Spieler-Eintrag aus status.json (Joy-Con-Paar hat ein eigenes)."""
    devices = player.get('devices', [])
    if len(devices) > 1:
        gen = 'jc1' if all(d.get('kind', '').startswith('JoyCon1') for d in devices) else 'jc2'
        return os.path.join(ICONS_DIR, gen + ('_grip.png' if all(d.get('inGrip') for d in devices) else '_paar.png'))
    for d in devices:
        if d.get('kind') in _KIND_ICONS:
            return os.path.join(ICONS_DIR, _KIND_ICONS[d['kind']])
    return kind_icon('', player.get('name'))


def help_text():
    """Anleitung in Kodis Sprache (help_<ISO 639-1>.txt), sonst Englisch. Im Begleitmodus (Windows, Android, macOS)
    die kurze Anleitung help_companion_<Sprache>.txt – die LibreELEC-Schritte gibt es dort nicht."""
    lang = (xbmc.getLanguage(xbmc.ISO_639_1) or 'en')[:2].lower()
    prefix = 'help' if has_daemon() else 'help_companion'
    for name in ('{0}_{1}.txt'.format(prefix, lang), '{0}_en.txt'.format(prefix)):
        try:
            with open(os.path.join(ADDON_PATH, 'resources', name), 'r', encoding='utf-8') as f:
                return f.read()
        except OSError:
            continue
    return ''
