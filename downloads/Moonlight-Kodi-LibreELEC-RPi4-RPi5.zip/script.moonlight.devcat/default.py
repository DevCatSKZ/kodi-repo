#!/usr/bin/env python3
"""Moonlight client menu — pair hosts, pick an app, stream via Kodi suspend."""
import filecmp
import glob
import json
import os
import platform
import re
import shutil
import socket
import subprocess
import sys
import threading
import time
import urllib.request
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon("script.moonlight.devcat")
ADDON_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
HOSTS_FILE = os.path.join(PROFILE, "hosts.json")
# hosts paired with the add-on before its ID changed (script.moonlight)
OLD_HOSTS_FILE = xbmcvfs.translatePath(
    "special://profile/addon_data/script.moonlight/hosts.json")
LAUNCHER = os.path.join(ADDON_DIR, "resources", "bin", "stream.sh")
FETCHER = os.path.join(ADDON_DIR, "resources", "bin", "fetch_runtime.py")
UNIT = "moonlight-stream"
PAIR_TIMEOUT = 180

sys.path.insert(0, os.path.join(ADDON_DIR, "resources", "lib"))
import consolemode  # noqa: E402

L = ADDON.getLocalizedString


def runtime_dir():
    return ADDON.getSetting("runtime_dir") or "/storage/moonlight-runtime"


def moonlight():
    return os.path.join(runtime_dir(), "bin", "moonlight")


def installed():
    return os.path.isfile(moonlight())


def bundle_dir():
    """Bundled moonlight-embedded build for this machine, if any."""
    arch = {"aarch64": "aarch64", "arm64": "aarch64"}.get(
        platform.machine().lower())
    path = os.path.join(ADDON_DIR, "resources", "runtime", arch or "-")
    return path if arch and os.path.isdir(path) else None


def runtime_outdated():
    """An add-on update brought a newer moonlight build than the one in
    the runtime (the runtime only changes when it is reinstalled)."""
    bundle = bundle_dir()
    if not bundle or not installed():
        return False
    try:
        return not filecmp.cmp(os.path.join(bundle, "bin", "moonlight"),
                               moonlight(), shallow=False)
    except OSError:
        return False


def env():
    e = dict(os.environ)
    e["LD_LIBRARY_PATH"] = os.path.join(runtime_dir(), "lib")
    e["HOME"] = "/storage"
    return e


def load_hosts():
    """Paired hosts: [{"address", "name", "mac", "last_app"}]. Up to
    0.2.4 the file held plain addresses."""
    for path in (HOSTS_FILE, OLD_HOSTS_FILE):
        try:
            with open(path) as f:
                hosts = json.load(f)
        except (OSError, ValueError):
            continue
        hosts = [h if isinstance(h, dict) else {"address": h}
                 for h in hosts if h]
        if path != HOSTS_FILE:
            save_hosts(hosts)
        return hosts
    return []


def update_host(address, **fields):
    """Add the host or merge fields into its entry."""
    hosts = load_hosts()
    for h in hosts:
        if h.get("address") == address:
            h.update({k: v for k, v in fields.items() if v})
            break
    else:
        hosts.append(dict({"address": address},
                          **{k: v for k, v in fields.items() if v}))
    save_hosts(hosts)


def host_label(host):
    name = host.get("name")
    address = host.get("address", "")
    return "%s (%s)" % (name, address) if name and name != address else address


def server_info(address, timeout=3):
    """Host name and MAC from the GameStream /serverinfo page (plain
    HTTP, answered without pairing by Sunshine and GFE)."""
    try:
        with urllib.request.urlopen("http://%s:47989/serverinfo" % address,
                                    timeout=timeout) as r:
            page = r.read().decode("utf-8", "replace")
    except (OSError, ValueError):
        return {}
    info = {}
    for tag in ("hostname", "mac"):
        m = re.search(r"<%s>([^<]*)</%s>" % (tag, tag), page)
        if m and m.group(1).strip() not in ("", "00:00:00:00:00:00"):
            info[tag] = m.group(1).strip()
    return info


def name_hosts(hosts):
    """Fill in missing names once (the host must be on)."""
    for h in hosts:
        if not h.get("name"):
            info = server_info(h["address"], timeout=2)
            if info.get("hostname"):
                update_host(h["address"], name=info["hostname"],
                            mac=info.get("mac"))
                h["name"] = info["hostname"]


def relocate_host(host):
    """The host isn't at its stored address: look its name up (DHCP may
    have handed out another IP) and keep the new address if the machine
    there has the same name. Pairing stays valid — it isn't tied to
    the IP. Returns the address to use."""
    name = host.get("name")
    if not name:
        return host["address"]
    for candidate in (name, name + ".local"):
        try:
            address = socket.gethostbyname(candidate)
        except OSError:
            continue
        if address != host["address"] and \
                server_info(address).get("hostname") == name:
            hosts = load_hosts()
            for h in hosts:
                if h.get("address") == host["address"]:
                    h["address"] = address
            save_hosts(hosts)
            host["address"] = address
            break
    return host["address"]


def save_hosts(hosts):
    os.makedirs(PROFILE, exist_ok=True)
    with open(HOSTS_FILE, "w") as f:
        json.dump(hosts, f)


def run_ml(*args, timeout=60):
    """Run moonlight, return (rc, output)."""
    try:
        p = subprocess.run([moonlight()] + list(args), env=env(),
                           capture_output=True, text=True, timeout=timeout,
                           stdin=subprocess.DEVNULL)
        return p.returncode, (p.stdout or "") + (p.stderr or "")
    except subprocess.TimeoutExpired:
        return -1, "timeout"
    except OSError as exc:
        return -1, str(exc)


def unit_state():
    r = subprocess.run(["systemctl", "is-active", UNIT + ".service"],
                       capture_output=True, text=True)
    return r.stdout.strip() or "unknown"


def install_runtime(dlg):
    bundle = bundle_dir()
    if not bundle:
        dlg.ok("Moonlight", L(32045))
        return
    rt = runtime_dir()
    if not dlg.yesno(L(32011), L(32041) % rt):
        return
    new = rt + ".new"
    shutil.rmtree(new, ignore_errors=True)
    os.makedirs(os.path.dirname(rt) or "/", exist_ok=True)
    logpath = rt + "-fetch.log"
    prog = xbmcgui.DialogProgress()
    prog.create(L(32011), L(32042))
    try:
        with open(logpath, "w") as lf:
            proc = subprocess.Popen(["python3", FETCHER, new,
                                     "--bundle", bundle],
                                    stdout=lf, stderr=subprocess.STDOUT)
        pct = 0
        while proc.poll() is None:
            if prog.iscanceled():
                proc.kill()
                break
            pct = min(pct + 1, 95)
            prog.update(pct, L(32042))
            xbmc.sleep(1000)
        rc = proc.wait()
    except OSError as exc:
        prog.close()
        dlg.ok(L(32011), "%s\n%s" % (L(32044), exc))
        return
    prog.close()
    if rc != 0 or not os.path.isfile(os.path.join(new, "bin", "moonlight")):
        shutil.rmtree(new, ignore_errors=True)
        dlg.ok(L(32011), "%s\n%s" % (L(32044), logpath))
        return
    old = rt + ".old"
    shutil.rmtree(old, ignore_errors=True)
    if os.path.isdir(rt):
        os.rename(rt, old)
    os.rename(new, rt)
    shutil.rmtree(old, ignore_errors=True)
    dlg.ok(L(32011), L(32043))


def pair_host(dlg, host=None):
    if host is None:
        host = dlg.input(L(32020), type=xbmcgui.INPUT_ALPHANUM).strip()
    if not host:
        return
    if not dlg.yesno(L(32010), L(32021) % host):
        return
    # PTY: moonlight prints the PIN and then blocks until it is typed in
    # on the host — through a pipe stdio would hold the line back
    import pty
    master, slave = pty.openpty()
    try:
        proc = subprocess.Popen([moonlight(), "pair", host], env=env(),
                                stdin=subprocess.DEVNULL, stdout=slave,
                                stderr=slave, close_fds=True)
    except OSError as exc:
        os.close(master)
        os.close(slave)
        dlg.ok(L(32010), "%s\n%s" % (L(32025), exc))
        return
    os.close(slave)
    out = []

    def reader():
        while True:
            try:
                chunk = os.read(master, 1024)
            except OSError:
                return
            if not chunk:
                return
            out.append(chunk.decode("utf-8", "replace"))

    t = threading.Thread(target=reader, daemon=True)
    t.start()
    progress = xbmcgui.DialogProgress()
    progress.create(L(32010), L(32022) % host)
    start = time.time()
    while proc.poll() is None:
        xbmc.sleep(300)
        m = re.search(r"PIN[^0-9]*(\d{4})", "".join(out))
        elapsed = time.time() - start
        if m:
            progress.update(int(100 * elapsed / PAIR_TIMEOUT),
                            L(32023) % m.group(1))
        if progress.iscanceled() or elapsed > PAIR_TIMEOUT:
            proc.kill()
            proc.wait()
            break
    t.join(2)
    os.close(master)
    progress.close()
    text = "".join(out)
    if re.search(r"succes+fully paired|already paired", text, re.I):
        info = server_info(host)
        update_host(host, name=info.get("hostname"), mac=info.get("mac"))
        dlg.ok(L(32010), L(32024) % host_label(
            {"address": host, "name": info.get("hostname")}))
    else:
        dlg.ok(L(32010), "%s\n%s" % (L(32025), text.strip()[-300:] or "-"))


def pick_app(dlg, host):
    """App list of the host, the last streamed app first."""
    rc, out = run_ml("list", host["address"], timeout=30)
    apps = re.findall(r"(?m)^\s*\d+\.\s+(.+?)\s*$", out)
    if not apps:
        old = host["address"]
        if relocate_host(host) != old:
            rc, out = run_ml("list", host["address"], timeout=30)
            apps = re.findall(r"(?m)^\s*\d+\.\s+(.+?)\s*$", out)
    if not apps:
        dlg.ok(host_label(host), "%s\n%s" % (L(32026), out.strip()[-200:]))
        return None
    last = host.get("last_app")
    if last in apps:
        apps.remove(last)
        apps.insert(0, last)
    idx = dlg.select(L(32027) % host_label(host), apps)
    if idx < 0:
        return None
    update_host(host["address"], last_app=apps[idx])
    return apps[idx]


def stream_host(dlg, host):
    if unit_state() in ("active", "activating"):
        dlg.ok("Moonlight", L(32031))
        return
    app = pick_app(dlg, host)
    if app is None:
        return
    res = ADDON.getSetting("resolution") or "1080"
    codec = stream_codec()
    bitrate = ADDON.getSetting("bitrate") or "auto"
    # moonlight picks the TV mode for the stream itself (size + refresh
    # rate), no console pin needed; with -codec hevc it still offers
    # H.264, so a host without HEVC falls back to it
    w, h = RES_SIZE.get(res, RES_SIZE["1080"])
    args = ["-app", app, "-width", str(w), "-height", str(h),
            "-fps", str(stream_fps(res, codec)), "-codec", codec]
    if bitrate != "auto":
        args += ["-bitrate", bitrate]
    # end the app on the host too, or Sunshine stays busy for other
    # devices (and keeps a changed display mode until the app quits)
    if ADDON.getSetting("quit_app") != "false":
        args.append("-quitappafter")
    args.append(host["address"])
    if not dlg.yesno(L(32032), L(32028)):
        return
    # systemd-run: this unit survives kodi stopping (our process dies);
    # a failed earlier run must not block the unit name
    subprocess.run(["systemctl", "reset-failed", UNIT + ".service"],
                   capture_output=True)
    r = subprocess.run(
        ["systemd-run", "--collect", "--unit=" + UNIT,
         "--description=Moonlight stream",
         "--setenv=MOONLIGHT_RUNTIME=" + runtime_dir(),
         "--property=ExecStopPost=/usr/bin/systemctl --no-block start kodi",
         "--property=TimeoutStopSec=5",
         "/bin/sh", LAUNCHER] + args,
        capture_output=True, text=True)
    if r.returncode != 0:
        xbmc.log("moonlight: systemd-run failed: %s" % r.stderr.strip(),
                 xbmc.LOGERROR)
        dlg.ok("Moonlight", "%s\n%s" % (L(32030), r.stderr.strip()[-300:]))
        return
    xbmcgui.Dialog().notification("Moonlight", L(32029))
    return True


def host_menu(dlg, host):
    """Returns True once a stream was started (the menu must close: Kodi
    is about to stop and would wait for this script)."""
    items = [L(32032), L(32033), L(32034), L(32035)]
    label = host_label(host)
    idx = dlg.select(label, items)
    if idx == 0:
        return stream_host(dlg, host)
    elif idx == 1:
        rc, out = run_ml("quit", host["address"], timeout=30)
        dlg.ok(label, L(32037) if rc == 0 else "%s\n%s"
               % (L(32038), out.strip()[-200:]))
    elif idx == 2:
        pair_host(dlg, host["address"])
    elif idx == 3:
        if dlg.yesno(label, L(32036) % label):
            run_ml("unpair", host["address"], timeout=30)
            save_hosts([h for h in load_hosts()
                        if h.get("address") != host["address"]])


RES_SIZE = {"720": (1280, 720), "1080": (1920, 1080), "1440": (2560, 1440),
            "4k": (3840, 2160)}


def video_decoders():
    """Names of this device's V4L2 video devices."""
    names = set()
    for path in glob.glob("/sys/class/video4linux/video*/name"):
        try:
            with open(path) as f:
                names.add(f.read().strip())
        except OSError:
            continue
    return names


def stream_codec():
    """The codec setting; 'auto' = HEVC where a hardware HEVC decoder
    exists (Raspberry Pi 4/5 'rpi-hevc-dec': ~5 ms per 1080p frame,
    120 fps), else H.264."""
    codec = ADDON.getSetting("codec") or "auto"
    if codec != "auto":
        return {"h265": "hevc"}.get(codec, codec)
    return "hevc" if "rpi-hevc-dec" in video_decoders() else "h264"


def decoder_fps_cap(height, codec):
    """Frame rate this device's hardware decoder keeps up with, measured
    on a Raspberry Pi 4 with the zero-copy build: HEVC 1080p ~120 fps,
    H.264 ~100 fps at 720p and 60-70 at 1080p. None: no known limit."""
    decoders = video_decoders()
    if codec == "hevc" and "rpi-hevc-dec" in decoders:
        return 120 if height <= 1080 else 60
    if codec == "h264" and "bcm2835-codec-decode" in decoders:
        return 120 if height <= 720 else 60
    return None


def stream_fps(res, codec):
    """The fps setting; 'auto' = the highest refresh rate the TV offers
    for the stream size, as far as this device's decoder keeps up."""
    fps = ADDON.getSetting("fps") or "auto"
    if fps != "auto":
        return int(fps)
    w, h = RES_SIZE.get(res, RES_SIZE["1080"])
    rates = consolemode.refresh_rates(w, h)
    best = rates[0] if rates else 60
    cap = decoder_fps_cap(h, codec)
    return min(best, cap) if cap else best


def console_target():
    res = ADDON.getSetting("resolution") or "1080"
    w, h = RES_SIZE.get(res, RES_SIZE["1080"])
    size = "%dx%d" % (max(w, 1920), max(h, 1080))
    return "%s@%d" % (size, stream_fps(res, stream_codec()))


def console_mode(dlg):
    """Pin the console mode (for other apps; this moonlight build picks
    its stream mode itself) or remove an older pin."""
    mode = console_target()
    pinned = consolemode.current_mode()
    info = L(32050) % (consolemode.console_size() or "-",
                       pinned or L(32051))
    items, actions = [], []
    if pinned != mode and consolemode.supported(mode):
        items.append(L(32052) % mode)
        actions.append(mode)
    if pinned:
        items.append(L(32053))
        actions.append(None)
    if not items:
        dlg.ok(L(32014), info)
        return
    idx = dlg.select(L(32014), items)
    if idx < 0:
        return
    if not dlg.yesno(L(32014), info + "\n\n" + L(32054)):
        return
    try:
        consolemode.set_mode(actions[idx])
    except (OSError, subprocess.CalledProcessError) as exc:
        dlg.ok(L(32014), "%s\n%s" % (L(32055), exc))
        return
    if dlg.yesno(L(32014), L(32056)):
        xbmc.executebuiltin("Reboot")


def status(dlg):
    version = "-"
    if installed():
        rc, out = run_ml("help", timeout=10)
        m = re.search(r"Moonlight Embedded (\S+)", out)
        version = m.group(1) if m else "?"
    res = ADDON.getSetting("resolution") or "1080"
    codec = stream_codec()
    auto = " (%s)" % L(32080)
    video = "%d fps%s, %s%s" % (
        stream_fps(res, codec),
        auto if (ADDON.getSetting("fps") or "auto") == "auto" else "",
        {"hevc": "HEVC"}.get(codec, "H.264"),
        auto if (ADDON.getSetting("codec") or "auto") == "auto" else "")
    dlg.ok(L(32012), L(32046) % (
        runtime_dir(), version if installed() else L(32047),
        len(load_hosts()), res, video,
        consolemode.current_mode() or L(32051)))


def main():
    dlg = xbmcgui.Dialog()
    if not installed():
        if bundle_dir() is None:
            dlg.ok("Moonlight", L(32045))
            return
        if dlg.yesno("Moonlight", L(32040)):
            install_runtime(dlg)
        if not installed():
            return
    elif runtime_outdated() and dlg.yesno("Moonlight", L(32048)):
        install_runtime(dlg)
    while True:
        hosts = load_hosts()
        name_hosts(hosts)
        entries = [(L(32015) % host_label(h), h) for h in hosts]
        entries += [(L(32010), "pair"), (L(32011), "install"),
                    (L(32014), "console"), (L(32012), "status")]
        if unit_state() in ("active", "activating"):
            entries.append((L(32013), "stop"))
        idx = dlg.select("Moonlight", [e[0] for e in entries])
        if idx == -1:
            return
        what = entries[idx][1]
        if what == "pair":
            pair_host(dlg)
        elif what == "install":
            install_runtime(dlg)
        elif what == "console":
            console_mode(dlg)
        elif what == "status":
            status(dlg)
        elif what == "stop":
            subprocess.run(["systemctl", "stop", UNIT + ".service"],
                           capture_output=True)
        elif host_menu(dlg, what):
            return


if __name__ == "__main__":
    main()
