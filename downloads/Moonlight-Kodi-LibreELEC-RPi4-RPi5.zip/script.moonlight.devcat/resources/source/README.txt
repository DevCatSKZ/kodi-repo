moonlight-embedded in resources/runtime/aarch64 — corresponding source (GPLv3)

Upstream:  https://github.com/moonlight-stream/moonlight-embedded
Commit:    f32e415aea6797d261d6b470dcf8bf18727341c2 (2.7.1-master),
           with its git submodules (moonlight-common-c, enet, ...)
Changes:   moonlight-embedded-rpi.patch in this folder (git apply)

The patch keeps the Raspberry Pi hardware decoders (h264_v4l2m2m for
H.264, the stateless HEVC decoder as DRM hwaccel), shows their DRM PRIME
frames on a KMS overlay plane without copying (paced by a 2-frame vblank
queue), fetches decoded frames as soon as they are ready, retries instead
of dropping packets, and switches the display to a mode that fits the
stream (size and refresh rate). Input: Guide/Home held 1.5 s ends the
stream, Start held 0.75 s toggles gamepad mouse mode (stick/D-pad move
the pointer, A/B/X click, right stick scrolls), and text written to the
FIFO named by MOONLIGHT_TEXT_FIFO is sent to the host as Unicode.

Build: Debian bookworm arm64 with FFmpeg 5.1 from the Raspberry Pi OS
archive (archive.raspberrypi.com), plus libdrm-dev and the usual
moonlight-embedded build dependencies; cmake + make. The add-on
repository's tools/build_moonlight_chroot.sh does all of this on a
Raspberry Pi running LibreELEC.
