#!/usr/bin/env python3
"""Steam Link addon menu — launch app, fetch runtime, status."""
import json
import os
import platform
import subprocess
import sys
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon("script.steamlink")
ADDON_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
LAUNCHER = os.path.join(ADDON_DIR, "resources", "bin", "steamlink.sh")
FETCHER = os.path.join(ADDON_DIR, "resources", "bin", "fetch_runtime.py")

L = ADDON.getLocalizedString


def runtime_dir():
    return ADDON.getSetting("runtime_dir") or "/storage/steamlink-runtime"


def steamlink_bin():
    return os.path.join(runtime_dir(), "steamlink", "bin", "shell")


def is_libreelec():
    return os.path.exists("/etc/os-release") and \
        "LibreELEC" in open("/etc/os-release").read()


def is_windows():
    return sys.platform.startswith("win")


def _arch():
    return platform.machine().lower()


def supported_arch():
    # Valve ships steamlink for arm64 (Pi4/Pi5 64-bit OS) and armhf
    return _arch() in ("aarch64", "arm64", "armv7l", "armv6l")


def fetch_runtime(dlg):
    """Download payload + libs on-device (progress dialog)."""
    if not dlg.yesno(L(32004),
                     L(32005)):
        return
    prog = xbmcgui.DialogProgress()
    prog.create(L(32004), L(32006))
    logpath = os.path.join(runtime_dir(), "fetch.log")
    os.makedirs(runtime_dir(), exist_ok=True)
    arch = "arm64" if _arch() in ("aarch64", "arm64") else "armhf"
    cmd = ["python3", FETCHER, runtime_dir(), "--arch", arch]
    try:
        with open(logpath, "w") as lf:
            proc = subprocess.Popen(cmd, stdout=lf,
                                    stderr=subprocess.STDOUT)
        while proc.poll() is None:
            if prog.iscanceled():
                proc.kill()
                break
            xbmc.sleep(500)
        rc = proc.wait()
    except OSError as exc:
        prog.close()
        dlg.ok(L(32004), f"{L(32007)}\n{exc}")
        return
    prog.close()
    if rc == 0 and os.path.isfile(steamlink_bin()):
        dlg.ok(L(32004), L(32008))
    else:
        dlg.ok(L(32004), f"{L(32007)}\n{logpath}")


def launch(dlg):
    mode = ADDON.getSetting("mode") or "1920x1080@60"
    if not dlg.yesno(L(32000),
                     L(32001)):
        return
    os.chmod(LAUNCHER, 0o755)
    subprocess.run(["systemd-run", "--unit=steamlink-stream",
                    "--description=steamlink",
                    "/bin/sh", LAUNCHER, mode], capture_output=True)
    xbmcgui.Dialog().notification(
        "Steam Link", L(32002), xbmcgui.NOTIFICATION_INFO, 4000)


def status(dlg):
    rt = runtime_dir()
    have = os.path.isfile(steamlink_bin())
    ver = ""
    vf = os.path.join(rt, "steamlink", "version.txt")
    if os.path.isfile(vf):
        ver = open(vf).read().strip()
    libs = 0
    lsys = os.path.join(rt, "lib-sys")
    if os.path.isdir(lsys):
        libs = len(os.listdir(lsys))
    dlg.ok("Steam Link",
           f"Runtime: {rt}\n"
           f"{L(32009)}: {'OK' if have else L(32010)}\n"
           f"Version: {ver or '-'}\n"
           f"Libs: {libs}\n"
           f"Mode: {ADDON.getSetting('mode')}")


def windows_flow(dlg):
    # No official Steam Link build for Windows — use Steam Remote Play
    if dlg.yesno("Steam Link", L(32011)):
        try:
            os.startfile("steam://open/bigpicture")
        except OSError:
            dlg.ok("Steam Link", L(32012))


def main():
    dlg = xbmcgui.Dialog()
    if is_windows():
        windows_flow(dlg)
        return
    if not supported_arch():
        dlg.ok("Steam Link", L(32013))
        return
    while True:
        have = os.path.isfile(steamlink_bin())
        items = [L(32000), L(32014) if have else L(32004), L(32015),
                 L(32019)]
        idx = dlg.select("Steam Link", items)
        if idx == -1:
            return
        if idx == 0:
            if not have:
                if dlg.yesno("Steam Link", L(32016)):
                    fetch_runtime(dlg)
                continue
            launch(dlg)
            return
        elif idx == 1:
            fetch_runtime(dlg)
        elif idx == 2:
            status(dlg)
        else:
            subprocess.run(["pkill", "-TERM", "-f", "bin/shell"],
                           capture_output=True)
            xbmcgui.Dialog().notification(
                "Steam Link", L(32020), xbmcgui.NOTIFICATION_INFO, 3000)


if __name__ == "__main__":
    main()
