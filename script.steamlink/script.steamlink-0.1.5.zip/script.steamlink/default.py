#!/usr/bin/env python3
"""Steam Link addon menu — launch app, fetch runtime, status."""
import os
import platform
import subprocess
import sys
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon("script.steamlink")
ADDON_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
LAUNCHER = os.path.join(ADDON_DIR, "resources", "bin", "steamlink.sh")
FETCHER = os.path.join(ADDON_DIR, "resources", "bin", "fetch_runtime.py")
UNIT = "steamlink-stream"

sys.path.insert(0, os.path.join(ADDON_DIR, "resources", "lib"))
import consolemode  # noqa: E402

L = ADDON.getLocalizedString


def runtime_dir():
    return ADDON.getSetting("runtime_dir") or "/storage/steamlink-runtime"


def steamlink_bin():
    return os.path.join(runtime_dir(), "steamlink", "bin", "shell")


def is_windows():
    return sys.platform.startswith("win")


def _arch():
    return platform.machine().lower()


def supported_arch():
    # Valve ships arm64 and armhf (ARMv7) builds; the Debian armhf
    # libraries need ARMv7, so ARMv6 (Pi 1/Zero) is out
    return _arch() in ("aarch64", "arm64", "armv7l", "armv8l")


def unit_state():
    r = subprocess.run(["systemctl", "is-active", UNIT + ".service"],
                       capture_output=True, text=True)
    return r.stdout.strip() or "unknown"


def fetch_runtime(dlg):
    """Download payload + libs on-device (progress dialog)."""
    if not dlg.yesno(L(32004), L(32005)):
        return
    prog = xbmcgui.DialogProgress()
    prog.create(L(32004), L(32006))
    logpath = os.path.join(runtime_dir(), "fetch.log")
    os.makedirs(runtime_dir(), exist_ok=True)
    arch = "arm64" if _arch() in ("aarch64", "arm64") else "armhf"
    cmd = ["python3", FETCHER, runtime_dir(), "--arch", arch]
    rc = -1
    try:
        with open(logpath, "w") as lf:
            proc = subprocess.Popen(cmd, stdout=lf,
                                    stderr=subprocess.STDOUT)
        pct = 0
        while proc.poll() is None:
            if prog.iscanceled():
                proc.kill()
                break
            pct = min(pct + 1, 95)
            prog.update(pct, L(32006))
            xbmc.sleep(1000)
        rc = proc.wait()
    except OSError as exc:
        prog.close()
        dlg.ok(L(32004), "%s\n%s" % (L(32007), exc))
        return
    prog.close()
    if rc == 0 and os.path.isfile(steamlink_bin()):
        dlg.ok(L(32004), L(32008))
    else:
        dlg.ok(L(32004), "%s\n%s" % (L(32007), logpath))


def launch(dlg):
    if unit_state() in ("active", "activating"):
        dlg.ok("Steam Link", L(32021))
        return
    mode = ADDON.getSetting("mode") or "1920x1080@60"
    if not dlg.yesno(L(32000), L(32001)):
        return
    # a crashed earlier run leaves a failed unit behind, which would
    # block the unit name — clear it; --collect stops that for good
    subprocess.run(["systemctl", "reset-failed", UNIT + ".service"],
                   capture_output=True)
    r = subprocess.run(
        ["systemd-run", "--collect", "--unit=" + UNIT,
         "--description=Steam Link",
         "--setenv=STEAMLINK_RUNTIME=" + runtime_dir(),
         # safety net if the launcher itself gets killed hard
         "--property=ExecStopPost=/usr/bin/systemctl --no-block start kodi",
         "/bin/sh", LAUNCHER, mode],
        capture_output=True, text=True)
    if r.returncode != 0:
        xbmc.log("steamlink: systemd-run failed: %s" % r.stderr.strip(),
                 xbmc.LOGERROR)
        dlg.ok("Steam Link", "%s\n%s" % (L(32022), r.stderr.strip()[-300:]))
        return
    xbmcgui.Dialog().notification(
        "Steam Link", L(32002), xbmcgui.NOTIFICATION_INFO, 4000)


def quit_app():
    subprocess.run(["pkill", "-TERM", "-f",
                    "^" + os.path.join(runtime_dir(), "steamlink", "bin",
                                       "shell")],
                   capture_output=True)
    xbmcgui.Dialog().notification(
        "Steam Link", L(32020), xbmcgui.NOTIFICATION_INFO, 3000)


def console_mode(dlg):
    """Pin the console mode so streams don't inherit the TV's 4K@30."""
    mode = ADDON.getSetting("mode") or "1920x1080@60"
    pinned = consolemode.current_mode()
    info = L(32024) % (consolemode.console_size() or "-",
                       pinned or L(32025))
    items = []
    actions = []
    if mode != "preferred" and pinned != mode:
        items.append(L(32026) % mode)
        actions.append(mode)
    if pinned:
        items.append(L(32027))
        actions.append(None)
    if not items:
        dlg.ok(L(32023), info)
        return
    idx = dlg.select(L(32023), items)
    if idx < 0:
        return
    if not dlg.yesno(L(32023), info + "\n\n" + L(32028)):
        return
    try:
        consolemode.set_mode(actions[idx])
    except (OSError, subprocess.CalledProcessError) as exc:
        dlg.ok(L(32023), "%s\n%s" % (L(32029), exc))
        return
    if dlg.yesno(L(32023), L(32030)):
        xbmc.executebuiltin("Reboot")


def status(dlg):
    rt = runtime_dir()
    have = os.path.isfile(steamlink_bin())
    ver = ""
    vf = os.path.join(rt, "steamlink", "version.txt")
    if os.path.isfile(vf):
        with open(vf) as f:
            ver = f.read().strip()
    libs = 0
    lsys = os.path.join(rt, "lib-sys")
    if os.path.isdir(lsys):
        libs = len(os.listdir(lsys))
    dlg.ok("Steam Link",
           "Runtime: %s\n%s: %s\nVersion: %s\nLibs: %d\n%s: %s\n%s: %s"
           % (rt, L(32009), "OK" if have else L(32010), ver or "-", libs,
              L(32018), ADDON.getSetting("mode"),
              L(32023), consolemode.current_mode() or L(32025)))


def windows_flow(dlg):
    # No official Steam Link build for Windows — use Steam Remote Play
    if dlg.yesno("Steam Link", L(32011)):
        try:
            os.startfile("steam://open/bigpicture")
        except OSError:
            dlg.ok("Steam Link", L(32012))


def main():
    dlg = xbmcgui.Dialog()
    if is_windows():
        windows_flow(dlg)
        return
    if not supported_arch():
        dlg.ok("Steam Link", L(32013))
        return
    while True:
        have = os.path.isfile(steamlink_bin())
        running = unit_state() in ("active", "activating")
        items = [L(32000), L(32014) if have else L(32004), L(32015),
                 L(32023)]
        if running:
            items.append(L(32019))
        idx = dlg.select("Steam Link", items)
        if idx == -1:
            return
        if idx == 0:
            if not have:
                if dlg.yesno("Steam Link", L(32016)):
                    fetch_runtime(dlg)
                continue
            launch(dlg)
            return
        elif idx == 1:
            fetch_runtime(dlg)
        elif idx == 2:
            status(dlg)
        elif idx == 3:
            console_mode(dlg)
        else:
            quit_app()


if __name__ == "__main__":
    main()
