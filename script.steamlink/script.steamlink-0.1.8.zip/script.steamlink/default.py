#!/usr/bin/env python3
"""Steam Link addon menu — launch app, fetch runtime, status."""
import os
import platform
import re
import subprocess
import sys
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon("script.steamlink")
ADDON_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
LAUNCHER = os.path.join(ADDON_DIR, "resources", "bin", "steamlink.sh")
FETCHER = os.path.join(ADDON_DIR, "resources", "bin", "fetch_runtime.py")
UNIT = "steamlink-stream"

sys.path.insert(0, os.path.join(ADDON_DIR, "resources", "lib"))
import consolemode  # noqa: E402
import slsettings  # noqa: E402

L = ADDON.getLocalizedString

# runtime_format.txt written by fetch_runtime.py; 2 = FFmpeg from
# Raspberry Pi OS (the app's hardware decoding needs it)
RUNTIME_FORMAT = 2


def runtime_dir():
    return ADDON.getSetting("runtime_dir") or "/storage/steamlink-runtime"


def steamlink_bin():
    return os.path.join(runtime_dir(), "steamlink", "bin", "shell")


def runtime_format():
    try:
        with open(os.path.join(runtime_dir(), "runtime_format.txt")) as f:
            return int(f.read().strip() or 1)
    except (OSError, ValueError):
        return 1


def stream_framerate(mode):
    """The frame rate limit to hand Steam Link: 'mode' (default) = the
    refresh rate of the display mode, 'app' = leave the app's own
    setting alone (slsettings.KEEP), or a number."""
    rate = ADDON.getSetting("framerate") or "mode"
    if rate == "app":
        return slsettings.KEEP
    if rate == "mode":
        m = re.search(r"@(\d+)$", mode or "")
        return int(m.group(1)) if m else slsettings.KEEP
    return int(rate)


def is_windows():
    return sys.platform.startswith("win")


def _arch():
    return platform.machine().lower()


def supported_arch():
    # Valve ships arm64 and armhf (ARMv7) builds; the Debian armhf
    # libraries need ARMv7, so ARMv6 (Pi 1/Zero) is out
    return _arch() in ("aarch64", "arm64", "armv7l", "armv8l")


def unit_state():
    r = subprocess.run(["systemctl", "is-active", UNIT + ".service"],
                       capture_output=True, text=True)
    return r.stdout.strip() or "unknown"


def fetch_runtime(dlg):
    """Download payload + libs on-device (progress dialog)."""
    if not dlg.yesno(L(32004), L(32005)):
        return
    prog = xbmcgui.DialogProgress()
    prog.create(L(32004), L(32006))
    logpath = os.path.join(runtime_dir(), "fetch.log")
    os.makedirs(runtime_dir(), exist_ok=True)
    arch = "arm64" if _arch() in ("aarch64", "arm64") else "armhf"
    cmd = ["python3", FETCHER, runtime_dir(), "--arch", arch]
    rc = -1
    try:
        with open(logpath, "w") as lf:
            proc = subprocess.Popen(cmd, stdout=lf,
                                    stderr=subprocess.STDOUT)
        pct = 0
        while proc.poll() is None:
            if prog.iscanceled():
                proc.kill()
                break
            pct = min(pct + 1, 95)
            prog.update(pct, L(32006))
            xbmc.sleep(1000)
        rc = proc.wait()
    except OSError as exc:
        prog.close()
        dlg.ok(L(32004), "%s\n%s" % (L(32007), exc))
        return
    prog.close()
    if rc == 0 and os.path.isfile(steamlink_bin()):
        dlg.ok(L(32004), L(32008))
    else:
        dlg.ok(L(32004), "%s\n%s" % (L(32007), logpath))


def offer_console_pin(dlg, target):
    """Once per mode: offer to pin the console mode the stream inherits —
    when the console runs wider (the TV's 4K@30) or another mode is
    pinned (e.g. 1080p@60 while 1080p@120 is set). Returns True if a
    reboot was started (skip launch)."""
    marker = os.path.join(PROFILE, "console_asked")
    try:
        with open(marker) as f:
            # empty: written by 0.1.6 and older, asked for the default
            asked = f.read().strip() or "1920x1080@60"
    except OSError:
        asked = None
    pinned = consolemode.current_mode()
    if asked == target:
        return False
    if pinned and pinned != target:
        question = L(32048) % (pinned, target)
    elif consolemode.needs_pin(target):
        question = L(32031) % (consolemode.console_size(), target)
    else:
        return False
    os.makedirs(PROFILE, exist_ok=True)
    with open(marker, "w") as f:
        f.write(target)
    if not dlg.yesno(L(32023), question):
        return False
    try:
        consolemode.set_mode(target)
    except (OSError, subprocess.CalledProcessError) as exc:
        dlg.ok(L(32023), "%s\n%s" % (L(32029), exc))
        return False
    if dlg.yesno(L(32023), L(32030)):
        xbmc.executebuiltin("Reboot")
        return True
    return False


def launch(dlg):
    if unit_state() in ("active", "activating"):
        dlg.ok("Steam Link", L(32021))
        return
    mode = ADDON.getSetting("mode") or "1920x1080@60"
    if mode != "preferred" and not consolemode.supported(mode):
        dlg.ok("Steam Link", L(32047) % mode)
        return
    if mode != "preferred" and offer_console_pin(dlg, mode):
        return
    if not dlg.yesno(L(32000), L(32001)):
        return
    # Steam Link's own "Automatic" streams at 60 fps even on 120 Hz;
    # its decoder limit from a Debian-FFmpeg runtime would keep it on
    # H.264 software decoding (the app finds the limit anew every run)
    try:
        slsettings.update(stream_framerate(mode), forget_decoder=True)
    except (OSError, ValueError) as exc:
        xbmc.log("steamlink: streaming settings not updated: %s" % exc,
                 xbmc.LOGWARNING)
    # a crashed earlier run leaves a failed unit behind, which would
    # block the unit name — clear it; --collect stops that for good
    subprocess.run(["systemctl", "reset-failed", UNIT + ".service"],
                   capture_output=True)
    r = subprocess.run(
        ["systemd-run", "--collect", "--unit=" + UNIT,
         "--description=Steam Link",
         "--setenv=STEAMLINK_RUNTIME=" + runtime_dir(),
         # safety net if the launcher itself gets killed hard; the app
         # ignores SIGTERM mid-stream, so don't wait 90 s for SIGKILL
         "--property=ExecStopPost=/usr/bin/systemctl --no-block start kodi",
         "--property=TimeoutStopSec=5",
         "/bin/sh", LAUNCHER, mode],
        capture_output=True, text=True)
    if r.returncode != 0:
        xbmc.log("steamlink: systemd-run failed: %s" % r.stderr.strip(),
                 xbmc.LOGERROR)
        dlg.ok("Steam Link", "%s\n%s" % (L(32022), r.stderr.strip()[-300:]))
        return
    xbmcgui.Dialog().notification(
        "Steam Link", L(32002), xbmcgui.NOTIFICATION_INFO, 4000)


def quit_app():
    # SIGTERM is ignored while a stream runs: kill after a grace period
    pattern = "^" + os.path.join(runtime_dir(), "steamlink", "bin", "shell")
    subprocess.run(["pkill", "-TERM", "-f", pattern], capture_output=True)
    for _ in range(16):
        xbmc.sleep(250)
        if subprocess.run(["pgrep", "-f", pattern],
                          capture_output=True).returncode != 0:
            break
    else:
        subprocess.run(["pkill", "-KILL", "-f", pattern], capture_output=True)
    xbmcgui.Dialog().notification(
        "Steam Link", L(32020), xbmcgui.NOTIFICATION_INFO, 3000)


def console_mode(dlg):
    """Pin the console mode so streams don't inherit the TV's 4K@30."""
    mode = ADDON.getSetting("mode") or "1920x1080@60"
    pinned = consolemode.current_mode()
    info = L(32024) % (consolemode.console_size() or "-",
                       pinned or L(32025))
    items = []
    actions = []
    if mode != "preferred" and pinned != mode:
        if not consolemode.supported(mode):
            dlg.ok(L(32023), L(32047) % mode)
            return
        items.append(L(32026) % mode)
        actions.append(mode)
    if pinned:
        items.append(L(32027))
        actions.append(None)
    if not items:
        dlg.ok(L(32023), info)
        return
    idx = dlg.select(L(32023), items)
    if idx < 0:
        return
    if not dlg.yesno(L(32023), info + "\n\n" + L(32028)):
        return
    try:
        consolemode.set_mode(actions[idx])
    except (OSError, subprocess.CalledProcessError) as exc:
        dlg.ok(L(32023), "%s\n%s" % (L(32029), exc))
        return
    if dlg.yesno(L(32023), L(32030)):
        xbmc.executebuiltin("Reboot")


def status(dlg):
    rt = runtime_dir()
    have = os.path.isfile(steamlink_bin())
    ver = ""
    vf = os.path.join(rt, "steamlink", "version.txt")
    if os.path.isfile(vf):
        with open(vf) as f:
            ver = f.read().strip()
    libs = 0
    lsys = os.path.join(rt, "lib-sys")
    if os.path.isdir(lsys):
        libs = len(os.listdir(lsys))
    mode = ADDON.getSetting("mode") or "1920x1080@60"
    rate = stream_framerate(mode)
    dlg.ok("Steam Link",
           "Runtime: %s\n%s: %s\nVersion: %s\nLibs: %d\n%s: %s\n%s: %s\n%s: %s"
           % (rt, L(32009), "OK" if have else L(32010), ver or "-", libs,
              L(32018), mode,
              L(32050), L(32052) if rate is slsettings.KEEP else "%d fps" % rate,
              L(32023), consolemode.current_mode() or L(32025)))


def windows_flow(dlg):
    # No official Steam Link build for Windows — use Steam Remote Play
    if dlg.yesno("Steam Link", L(32011)):
        try:
            os.startfile("steam://open/bigpicture")
        except OSError:
            dlg.ok("Steam Link", L(32012))


def main():
    dlg = xbmcgui.Dialog()
    if is_windows():
        windows_flow(dlg)
        return
    if not supported_arch():
        dlg.ok("Steam Link", L(32013))
        return
    if (os.path.isfile(steamlink_bin()) and runtime_format() < RUNTIME_FORMAT
            and dlg.yesno("Steam Link", L(32049))):
        fetch_runtime(dlg)
    while True:
        have = os.path.isfile(steamlink_bin())
        running = unit_state() in ("active", "activating")
        items = [L(32000), L(32014) if have else L(32004), L(32015),
                 L(32023)]
        if running:
            items.append(L(32019))
        idx = dlg.select("Steam Link", items)
        if idx == -1:
            return
        if idx == 0:
            if not have:
                if dlg.yesno("Steam Link", L(32016)):
                    fetch_runtime(dlg)
                continue
            launch(dlg)
            return
        elif idx == 1:
            fetch_runtime(dlg)
        elif idx == 2:
            status(dlg)
        elif idx == 3:
            console_mode(dlg)
        else:
            quit_app()


if __name__ == "__main__":
    main()
