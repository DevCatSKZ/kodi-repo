"""Steam Link's streaming settings (streaming_settings.bin).

The file is a serialized CStreamingClientConfig (steammessages_remoteplay
.proto, read from the descriptor embedded in the app). Only the fields
below are touched; every other one is written back as it was read:

    #4 desired_framerate_numerator    uint32   e.g. 12000
    #5 desired_framerate_denominator  uint32   e.g. 100    -> 120 fps

Both unset = the app's "Automatic", which streams at 60 fps even on a
120 Hz display. The app's own menu offers 30, 50, 59.94, 60, 90, 120,
144 and 240 fps with denominator 100.

    #24 decoder_limit (CStreamVideoLimit: codec, mode)

is what the app found its decoder can do; a runtime that still had
Debian's FFmpeg left "H.264, 1080p" there. The app writes it anew on
every run, so it is dropped before a launch.
"""
import os

SETTINGS = os.path.expanduser(
    "~/.local/share/Valve Corporation/SteamLink/streaming_settings.bin")
NUMERATOR, DENOMINATOR, DECODER_LIMIT = 4, 5, 24


def _varint(buf, i):
    value = shift = 0
    while True:
        b = buf[i]
        value |= (b & 0x7f) << shift
        i += 1
        if b < 0x80:
            return value, i
        shift += 7


def _encode_varint(value):
    out = bytearray()
    while True:
        b = value & 0x7f
        value >>= 7
        if value:
            out.append(b | 0x80)
        else:
            out.append(b)
            return bytes(out)


def _fields(buf):
    """Top-level (number, raw bytes incl. key) pairs, in file order."""
    out, i = [], 0
    while i < len(buf):
        start = i
        key, i = _varint(buf, i)
        wire = key & 7
        if wire == 0:
            _, i = _varint(buf, i)
        elif wire == 1:
            i += 8
        elif wire == 2:
            n, i = _varint(buf, i)
            i += n
        elif wire == 5:
            i += 4
        else:
            raise ValueError("unsupported wire type %d" % wire)
        if i > len(buf):
            raise ValueError("truncated field %d" % (key >> 3))
        out.append((key >> 3, buf[start:i]))
    return out


def framerate(path=SETTINGS):
    """The configured limit in fps, or None for "Automatic"."""
    try:
        with open(path, "rb") as f:
            fields = dict((n, raw) for n, raw in _fields(f.read()))
    except (OSError, ValueError):
        return None
    if NUMERATOR not in fields or DENOMINATOR not in fields:
        return None
    num = _varint(fields[NUMERATOR], 1)[0]
    den = _varint(fields[DENOMINATOR], 1)[0]
    return num / den if den else None


KEEP = object()


def update(framerate=KEEP, forget_decoder=False, path=SETTINGS):
    """framerate: the limit in fps (e.g. 120 or 59.94), None for the
    app's "Automatic", KEEP to leave it alone. forget_decoder drops the
    stored decoder limit. Every other setting stays as it is; a missing
    file is created with just the limit (the app fills in the rest)."""
    drop = set()
    if framerate is not KEEP:
        drop |= {NUMERATOR, DENOMINATOR}
    if forget_decoder:
        drop.add(DECODER_LIMIT)
    if not drop:
        return
    try:
        with open(path, "rb") as f:
            fields = _fields(f.read())
    except OSError:
        fields = []
    fields = [(n, raw) for n, raw in fields if n not in drop]
    if framerate is not KEEP and framerate:
        num = int(round(float(framerate) * 100))
        fields.append((NUMERATOR, _encode_varint(NUMERATOR << 3) + _encode_varint(num)))
        fields.append((DENOMINATOR, _encode_varint(DENOMINATOR << 3) + _encode_varint(100)))
        fields.sort(key=lambda f: f[0])
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".new"
    with open(tmp, "wb") as f:
        f.write(b"".join(raw for _, raw in fields))
    os.replace(tmp, path)
