"""Console display mode via the kernel command line (LibreELEC).

While Kodi is stopped the KMS output falls back to the console mode,
and SDL-based stream players (Steam Link, moonlight) take that mode as
their "desktop mode". On TVs whose preferred mode is 4K@30 that caps
every stream at 30 fps. A video=<connector>:<mode> entry in
/flash/cmdline.txt pins the console mode instead (needs a reboot).
Kodi still switches to its own GUI/video modes as before.
"""
import glob
import os
import re
import shutil
import subprocess

CMDLINE = "/flash/cmdline.txt"
BACKUP = "/storage/.config/cmdline.txt.bak"


def connected_connector():
    """Kernel name (e.g. HDMI-A-1) of the first connected HDMI port."""
    for status in sorted(glob.glob("/sys/class/drm/card*-HDMI-A-*/status")):
        try:
            with open(status) as f:
                if f.read().strip() == "connected":
                    return os.path.basename(
                        os.path.dirname(status)).split("-", 1)[1]
        except OSError:
            continue
    return None


def _args():
    with open(CMDLINE) as f:
        return f.read().split()


def current_mode(connector=None):
    """The pinned mode for `connector` (default: connected port)."""
    connector = connector or connected_connector()
    try:
        args = _args()
    except OSError:
        return None
    for a in args:
        m = re.match(r"video=([^:]+):(\S+)$", a)
        if m and m.group(1) == connector:
            return m.group(2)
    return None


def display_modes(connector=None):
    """Progressive modes the connected display offers, as
    (width, height, refresh) with the refresh rounded (119.88 -> 120),
    largest first. Empty if kmsprint can't tell."""
    connector = connector or connected_connector()
    try:
        out = subprocess.run(["kmsprint", "-m"], capture_output=True,
                             text=True, timeout=10).stdout
    except (OSError, subprocess.SubprocessError):
        return []
    modes, current = set(), None
    for line in out.splitlines():
        m = re.match(r"Connector \d+ \(\d+\) (\S+)", line)
        if m:
            current = m.group(1)
            continue
        # interlaced modes read "1920x1080i@60.00" and don't match
        m = re.match(r"\s+\d+\s+(\d+)x(\d+)@([\d.]+)\s", line)
        if m and current == connector:
            modes.add((int(m.group(1)), int(m.group(2)),
                       int(round(float(m.group(3))))))
    return sorted(modes, reverse=True)


def refresh_rates(width, height):
    """Refresh rates of the display's modes of at least width x height,
    highest first (a 720p stream can use a 1080p@120 mode)."""
    return sorted({r for w, h, r in display_modes()
                   if w >= width and h >= height}, reverse=True)


def supported(mode):
    """True if the display offers `mode` ('1920x1080@120') — or if its
    modes can't be read. Pinning a mode the TV lacks makes the kernel
    calculate one the TV may not show."""
    m = re.match(r"(\d+)x(\d+)@(\d+)$", mode or "")
    modes = display_modes()
    if not m or not modes:
        return True
    return tuple(int(g) for g in m.groups()) in modes


def console_size():
    """Current console framebuffer size, e.g. '3840x2160'."""
    try:
        with open("/sys/class/graphics/fb0/virtual_size") as f:
            return f.read().strip().replace(",", "x")
    except OSError:
        return None


def needs_pin(target):
    """True if the console runs wider than `target` ('1920x1080@60') and
    nothing is pinned for the connected port — typically the TV's 4K@30,
    which streams would inherit."""
    if not target or "x" not in target or current_mode():
        return False
    try:
        console_w = int((console_size() or "").split("x")[0])
        target_w = int(target.split("x")[0])
    except ValueError:
        return False
    return console_w > target_w


def set_mode(mode):
    """Pin the console mode of the connected port ('1920x1080@60');
    mode=None removes the pin. Other video= entries stay untouched.
    Backs up the original cmdline.txt once. Returns the new line."""
    connector = connected_connector() or "HDMI-A-1"
    args = [a for a in _args()
            if not a.startswith("video=%s:" % connector)]
    if mode:
        args.append("video=%s:%s" % (connector, mode))
    line = " ".join(args) + "\n"
    if not os.path.exists(BACKUP):
        os.makedirs(os.path.dirname(BACKUP), exist_ok=True)
        shutil.copy2(CMDLINE, BACKUP)
    subprocess.run(["mount", "-o", "remount,rw", "/flash"], check=True,
                   capture_output=True)
    try:
        tmp = CMDLINE + ".new"
        with open(tmp, "w") as f:
            f.write(line)
            f.flush()
            os.fsync(f.fileno())
        os.rename(tmp, CMDLINE)
    finally:
        subprocess.run(["mount", "-o", "remount,ro", "/flash"],
                       capture_output=True)
    return line.strip()
