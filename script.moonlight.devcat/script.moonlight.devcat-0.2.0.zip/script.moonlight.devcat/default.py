#!/usr/bin/env python3
"""Moonlight client menu — pair hosts, pick an app, stream via Kodi suspend."""
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import threading
import time
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon("script.moonlight.devcat")
ADDON_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
HOSTS_FILE = os.path.join(PROFILE, "hosts.json")
# hosts paired with the add-on before its ID changed (script.moonlight)
OLD_HOSTS_FILE = xbmcvfs.translatePath(
    "special://profile/addon_data/script.moonlight/hosts.json")
LAUNCHER = os.path.join(ADDON_DIR, "resources", "bin", "stream.sh")
FETCHER = os.path.join(ADDON_DIR, "resources", "bin", "fetch_runtime.py")
UNIT = "moonlight-stream"
PAIR_TIMEOUT = 180

sys.path.insert(0, os.path.join(ADDON_DIR, "resources", "lib"))
import consolemode  # noqa: E402

L = ADDON.getLocalizedString


def runtime_dir():
    return ADDON.getSetting("runtime_dir") or "/storage/moonlight-runtime"


def moonlight():
    return os.path.join(runtime_dir(), "bin", "moonlight")


def installed():
    return os.path.isfile(moonlight())


def bundle_dir():
    """Bundled moonlight-embedded build for this machine, if any."""
    arch = {"aarch64": "aarch64", "arm64": "aarch64"}.get(
        platform.machine().lower())
    path = os.path.join(ADDON_DIR, "resources", "runtime", arch or "-")
    return path if arch and os.path.isdir(path) else None


def env():
    e = dict(os.environ)
    e["LD_LIBRARY_PATH"] = os.path.join(runtime_dir(), "lib")
    e["HOME"] = "/storage"
    return e


def load_hosts():
    for path in (HOSTS_FILE, OLD_HOSTS_FILE):
        try:
            with open(path) as f:
                hosts = json.load(f)
        except (OSError, ValueError):
            continue
        if path != HOSTS_FILE:
            save_hosts(hosts)
        return hosts
    return []


def save_hosts(hosts):
    os.makedirs(PROFILE, exist_ok=True)
    with open(HOSTS_FILE, "w") as f:
        json.dump(hosts, f)


def run_ml(*args, timeout=60):
    """Run moonlight, return (rc, output)."""
    try:
        p = subprocess.run([moonlight()] + list(args), env=env(),
                           capture_output=True, text=True, timeout=timeout,
                           stdin=subprocess.DEVNULL)
        return p.returncode, (p.stdout or "") + (p.stderr or "")
    except subprocess.TimeoutExpired:
        return -1, "timeout"
    except OSError as exc:
        return -1, str(exc)


def unit_state():
    r = subprocess.run(["systemctl", "is-active", UNIT + ".service"],
                       capture_output=True, text=True)
    return r.stdout.strip() or "unknown"


def install_runtime(dlg):
    bundle = bundle_dir()
    if not bundle:
        dlg.ok("Moonlight", L(32045))
        return
    rt = runtime_dir()
    if not dlg.yesno(L(32011), L(32041) % rt):
        return
    new = rt + ".new"
    shutil.rmtree(new, ignore_errors=True)
    os.makedirs(os.path.dirname(rt) or "/", exist_ok=True)
    logpath = rt + "-fetch.log"
    prog = xbmcgui.DialogProgress()
    prog.create(L(32011), L(32042))
    try:
        with open(logpath, "w") as lf:
            proc = subprocess.Popen(["python3", FETCHER, new,
                                     "--bundle", bundle],
                                    stdout=lf, stderr=subprocess.STDOUT)
        pct = 0
        while proc.poll() is None:
            if prog.iscanceled():
                proc.kill()
                break
            pct = min(pct + 1, 95)
            prog.update(pct, L(32042))
            xbmc.sleep(1000)
        rc = proc.wait()
    except OSError as exc:
        prog.close()
        dlg.ok(L(32011), "%s\n%s" % (L(32044), exc))
        return
    prog.close()
    if rc != 0 or not os.path.isfile(os.path.join(new, "bin", "moonlight")):
        shutil.rmtree(new, ignore_errors=True)
        dlg.ok(L(32011), "%s\n%s" % (L(32044), logpath))
        return
    old = rt + ".old"
    shutil.rmtree(old, ignore_errors=True)
    if os.path.isdir(rt):
        os.rename(rt, old)
    os.rename(new, rt)
    shutil.rmtree(old, ignore_errors=True)
    dlg.ok(L(32011), L(32043))


def pair_host(dlg, host=None):
    if host is None:
        host = dlg.input(L(32020), type=xbmcgui.INPUT_ALPHANUM).strip()
    if not host:
        return
    if not dlg.yesno(L(32010), L(32021) % host):
        return
    # PTY: moonlight prints the PIN and then blocks until it is typed in
    # on the host — through a pipe stdio would hold the line back
    import pty
    master, slave = pty.openpty()
    try:
        proc = subprocess.Popen([moonlight(), "pair", host], env=env(),
                                stdin=subprocess.DEVNULL, stdout=slave,
                                stderr=slave, close_fds=True)
    except OSError as exc:
        os.close(master)
        os.close(slave)
        dlg.ok(L(32010), "%s\n%s" % (L(32025), exc))
        return
    os.close(slave)
    out = []

    def reader():
        while True:
            try:
                chunk = os.read(master, 1024)
            except OSError:
                return
            if not chunk:
                return
            out.append(chunk.decode("utf-8", "replace"))

    t = threading.Thread(target=reader, daemon=True)
    t.start()
    progress = xbmcgui.DialogProgress()
    progress.create(L(32010), L(32022) % host)
    start = time.time()
    while proc.poll() is None:
        xbmc.sleep(300)
        m = re.search(r"PIN[^0-9]*(\d{4})", "".join(out))
        elapsed = time.time() - start
        if m:
            progress.update(int(100 * elapsed / PAIR_TIMEOUT),
                            L(32023) % m.group(1))
        if progress.iscanceled() or elapsed > PAIR_TIMEOUT:
            proc.kill()
            proc.wait()
            break
    t.join(2)
    os.close(master)
    progress.close()
    text = "".join(out)
    if re.search(r"succes+fully paired|already paired", text, re.I):
        hosts = load_hosts()
        if host not in hosts:
            hosts.append(host)
            save_hosts(hosts)
        dlg.ok(L(32010), L(32024) % host)
    else:
        dlg.ok(L(32010), "%s\n%s" % (L(32025), text.strip()[-300:] or "-"))


def pick_app(dlg, host):
    rc, out = run_ml("list", host, timeout=30)
    apps = re.findall(r"(?m)^\s*\d+\.\s+(.+?)\s*$", out)
    if not apps:
        dlg.ok(host, "%s\n%s" % (L(32026), out.strip()[-200:]))
        return None
    idx = dlg.select(L(32027) % host, apps)
    return apps[idx] if idx >= 0 else None


def stream_host(dlg, host):
    if unit_state() in ("active", "activating"):
        dlg.ok("Moonlight", L(32031))
        return
    app = pick_app(dlg, host)
    if app is None:
        return
    res = ADDON.getSetting("resolution") or "720"
    fps = ADDON.getSetting("fps") or "60"
    args = ["-app", app, {"1080": "-1080", "4k": "-4k"}.get(res, "-720"),
            "-fps", fps, host]
    if not dlg.yesno(L(32032), L(32028)):
        return
    # systemd-run: this unit survives kodi stopping (our process dies);
    # a failed earlier run must not block the unit name
    subprocess.run(["systemctl", "reset-failed", UNIT + ".service"],
                   capture_output=True)
    r = subprocess.run(
        ["systemd-run", "--collect", "--unit=" + UNIT,
         "--description=Moonlight stream",
         "--setenv=MOONLIGHT_RUNTIME=" + runtime_dir(),
         "--property=ExecStopPost=/usr/bin/systemctl --no-block start kodi",
         "/bin/sh", LAUNCHER] + args,
        capture_output=True, text=True)
    if r.returncode != 0:
        xbmc.log("moonlight: systemd-run failed: %s" % r.stderr.strip(),
                 xbmc.LOGERROR)
        dlg.ok("Moonlight", "%s\n%s" % (L(32030), r.stderr.strip()[-300:]))
        return
    xbmcgui.Dialog().notification("Moonlight", L(32029))


def host_menu(dlg, host):
    items = [L(32032), L(32033), L(32034), L(32035)]
    idx = dlg.select(host, items)
    if idx == 0:
        stream_host(dlg, host)
    elif idx == 1:
        rc, out = run_ml("quit", host, timeout=30)
        dlg.ok(host, L(32037) if rc == 0 else "%s\n%s"
               % (L(32038), out.strip()[-200:]))
    elif idx == 2:
        pair_host(dlg, host)
    elif idx == 3:
        if dlg.yesno(host, L(32036) % host):
            run_ml("unpair", host, timeout=30)
            save_hosts([h for h in load_hosts() if h != host])


def console_target():
    res = ADDON.getSetting("resolution") or "720"
    fps = ADDON.getSetting("fps") or "60"
    size = "3840x2160" if res == "4k" else "1920x1080"
    return "%s@%s" % (size, fps)


def console_mode(dlg):
    """Pin the console mode so streams don't inherit the TV's 4K@30."""
    mode = console_target()
    pinned = consolemode.current_mode()
    info = L(32050) % (consolemode.connected_connector() or "-",
                       consolemode.console_size() or "-",
                       pinned or L(32051))
    items, actions = [], []
    if pinned != mode:
        items.append(L(32052) % mode)
        actions.append(mode)
    if pinned:
        items.append(L(32053))
        actions.append(None)
    idx = dlg.select(L(32014), items)
    if idx < 0:
        return
    if not dlg.yesno(L(32014), info + "\n\n" + L(32054)):
        return
    try:
        consolemode.set_mode(actions[idx])
    except (OSError, subprocess.CalledProcessError) as exc:
        dlg.ok(L(32014), "%s\n%s" % (L(32055), exc))
        return
    if dlg.yesno(L(32014), L(32056)):
        xbmc.executebuiltin("Reboot")


def status(dlg):
    version = "-"
    if installed():
        rc, out = run_ml("help", timeout=10)
        m = re.search(r"Moonlight Embedded (\S+)", out)
        version = m.group(1) if m else "?"
    dlg.ok(L(32012), L(32046) % (
        runtime_dir(), version if installed() else L(32047),
        len(load_hosts()), ADDON.getSetting("resolution") or "720",
        ADDON.getSetting("fps") or "60",
        consolemode.current_mode() or L(32051)))


def main():
    dlg = xbmcgui.Dialog()
    if not installed():
        if bundle_dir() is None:
            dlg.ok("Moonlight", L(32045))
            return
        if dlg.yesno("Moonlight", L(32040)):
            install_runtime(dlg)
        if not installed():
            return
    while True:
        hosts = load_hosts()
        entries = [(L(32015) % h, h) for h in hosts]
        entries += [(L(32010), "pair"), (L(32011), "install"),
                    (L(32014), "console"), (L(32012), "status")]
        if unit_state() in ("active", "activating"):
            entries.append((L(32013), "stop"))
        idx = dlg.select("Moonlight", [e[0] for e in entries])
        if idx == -1:
            return
        what = entries[idx][1]
        if what == "pair":
            pair_host(dlg)
        elif what == "install":
            install_runtime(dlg)
        elif what == "console":
            console_mode(dlg)
        elif what == "status":
            status(dlg)
        elif what == "stop":
            subprocess.run(["systemctl", "stop", UNIT + ".service"],
                           capture_output=True)
        else:
            host_menu(dlg, what)


if __name__ == "__main__":
    main()
