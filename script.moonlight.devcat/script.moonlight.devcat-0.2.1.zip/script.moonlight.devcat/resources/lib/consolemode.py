"""Console display mode via the kernel command line (LibreELEC).

While Kodi is stopped the KMS output falls back to the console mode,
and SDL-based stream players (Steam Link, moonlight) take that mode as
their "desktop mode". On TVs whose preferred mode is 4K@30 that caps
every stream at 30 fps. A video=<connector>:<mode> entry in
/flash/cmdline.txt pins the console mode instead (needs a reboot).
Kodi still switches to its own GUI/video modes as before.
"""
import glob
import os
import re
import shutil
import subprocess

CMDLINE = "/flash/cmdline.txt"
BACKUP = "/storage/.config/cmdline.txt.bak"


def connected_connector():
    """Kernel name (e.g. HDMI-A-1) of the first connected HDMI port."""
    for status in sorted(glob.glob("/sys/class/drm/card*-HDMI-A-*/status")):
        try:
            with open(status) as f:
                if f.read().strip() == "connected":
                    return os.path.basename(
                        os.path.dirname(status)).split("-", 1)[1]
        except OSError:
            continue
    return None


def _args():
    with open(CMDLINE) as f:
        return f.read().split()


def current_mode(connector=None):
    """The pinned mode for `connector` (default: connected port)."""
    connector = connector or connected_connector()
    try:
        args = _args()
    except OSError:
        return None
    for a in args:
        m = re.match(r"video=([^:]+):(\S+)$", a)
        if m and m.group(1) == connector:
            return m.group(2)
    return None


def console_size():
    """Current console framebuffer size, e.g. '3840x2160'."""
    try:
        with open("/sys/class/graphics/fb0/virtual_size") as f:
            return f.read().strip().replace(",", "x")
    except OSError:
        return None


def set_mode(mode):
    """Pin the console mode of the connected port ('1920x1080@60');
    mode=None removes the pin. Other video= entries stay untouched.
    Backs up the original cmdline.txt once. Returns the new line."""
    connector = connected_connector() or "HDMI-A-1"
    args = [a for a in _args()
            if not a.startswith("video=%s:" % connector)]
    if mode:
        args.append("video=%s:%s" % (connector, mode))
    line = " ".join(args) + "\n"
    if not os.path.exists(BACKUP):
        os.makedirs(os.path.dirname(BACKUP), exist_ok=True)
        shutil.copy2(CMDLINE, BACKUP)
    subprocess.run(["mount", "-o", "remount,rw", "/flash"], check=True,
                   capture_output=True)
    try:
        tmp = CMDLINE + ".new"
        with open(tmp, "w") as f:
            f.write(line)
            f.flush()
            os.fsync(f.fileno())
        os.rename(tmp, CMDLINE)
    finally:
        subprocess.run(["mount", "-o", "remount,ro", "/flash"],
                       capture_output=True)
    return line.strip()
