#!/usr/bin/env python3
"""Moonlight client menu — hosts, pair, stream via Kodi suspend."""
import json
import os
import subprocess
import threading
import time
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon("script.moonlight")
ADDON_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
HOSTS_FILE = os.path.join(PROFILE, "hosts.json")
LAUNCHER = os.path.join(ADDON_DIR, "resources", "bin", "stream.sh")


def runtime_dir():
    return ADDON.getSetting("runtime_dir") or "/storage/moonlight-runtime"


def moonlight():
    return os.path.join(runtime_dir(), "bin", "moonlight")


def env():
    e = dict(os.environ)
    e["LD_LIBRARY_PATH"] = os.path.join(runtime_dir(), "lib")
    e["HOME"] = "/storage"
    e["SDL_VIDEODRIVER"] = "kmsdrm"
    e["SDL_KMSDRM_REQUIRE_DRM_MASTER"] = "0"
    return e


def load_hosts():
    try:
        return json.loads(xbmcvfs.File(HOSTS_FILE).read() or "[]")
    except Exception:
        return []


def save_hosts(h):
    os.makedirs(PROFILE, exist_ok=True)
    with open(HOSTS_FILE, "w") as f:
        json.dump(h, f)


def run_ml(*args, timeout=60):
    """Run moonlight, return (rc, output)."""
    try:
        p = subprocess.run([moonlight()] + list(args),
                           env=env(), capture_output=True,
                           text=True, timeout=timeout)
        return p.returncode, (p.stdout or "") + (p.stderr or "")
    except subprocess.TimeoutExpired:
        return -1, "timeout"


def pair_host(dlg):
    host = dlg.input("Sunshine-Host (IP/Name)", type=xbmcgui.INPUT_ALPHANUM)
    if not host:
        return
    if not dlg.yesno("Pairing", f"Pairing mit {host} starten.\n"
                     "Es erscheint eine PIN — diese auf dem Host in der\n"
                     "Sunshine Web-UI (PIN-Seite) eingeben.\n\nFortfahren?"):
        return
    progress = xbmcgui.DialogProgress()
    progress.create("Pairing", f"Verbinde mit {host}…")
    result = {"out": "", "done": False}

    def _pair():
        rc, out = run_ml("pair", host, timeout=120)
        result["out"] = out
        result["rc"] = rc
        result["done"] = True

    t = threading.Thread(target=_pair, daemon=True)
    t.start()
    pin_shown = False
    while not result["done"]:
        time.sleep(0.5)
        pin = ""
        for tok in result.get("out", "").split():
            if tok.isdigit() and len(tok) == 4:
                pin = tok
        if not pin_shown and pin:
            progress.update(50, f"PIN auf dem Host eingeben: {pin}")
            pin_shown = True
        if progress.iscanceled():
            for p in subprocess.run(["pgrep", "-f", "moonlight pair"],
                                    capture_output=True, text=True
                                    ).stdout.split():
                os.kill(int(p), 9)
            progress.close()
            return
        progress.update(10)
    progress.close()
    if "Succesfully paired" in result["out"] or "Successfully paired" in result["out"]:
        hosts = load_hosts()
        if host not in hosts:
            hosts.append(host)
            save_hosts(hosts)
        dlg.ok("Pairing", f"{host} erfolgreich gepairt.")
    else:
        dlg.ok("Pairing", "Fehlgeschlagen:\n" + result["out"][-200:])


def stream_host(dlg, host):
    hosts_apps = pick_app(dlg, host)
    if hosts_apps is None:
        return
    res = ADDON.getSetting("resolution") or "720"
    args = [LAUNCHER, host, "-app", hosts_apps, "-720" if res == "720" else "-1080"]
    if not dlg.yesno("Stream starten",
                     "Kodi wird kurz beendet, der Stream läuft\n"
                     "Vollbild, danach kommt Kodi zurück.\n\n"
                     "Starten?"):
        return
    # systemd-run: this unit survives kodi stopping (our process dies)
    subprocess.run(["systemd-run", "--unit=moonlight-stream",
                    "--description=moonlight stream",
                    "/bin/sh"] + args, capture_output=True)
    xbmcgui.Dialog().notification("Moonlight", "Stream startet — Kodi wird beendet")


def pick_app(dlg, host):
    rc, out = run_ml("list", host, timeout=30)
    apps = []
    for line in out.splitlines():
        if ". " in line[:4]:
            apps.append(line.split(". ", 1)[1].strip())
    if not apps:
        dlg.ok(host, "Keine Apps gefunden (gepairt?):\n" + out[-200:])
        return None
    idx = dlg.select(f"{host} — App wählen", apps)
    return apps[idx] if idx >= 0 else None


def main():
    dlg = xbmcgui.Dialog()
    if not xbmcvfs.exists(moonlight()):
        dlg.ok("Moonlight",
               "Runtime nicht installiert unter:\n" + runtime_dir() +
               "\n\nAuf dem Gerät bauen:\nsh tools/build_moonlight_chroot.sh")
        return
    while True:
        hosts = load_hosts()
        items = ["Neuen Host paaren"] + [f"{h} — streamen" for h in hosts] \
            + ["Status"]
        idx = dlg.select("Moonlight Stream Client", items)
        if idx == -1:
            return
        if idx == 0:
            pair_host(dlg)
        elif idx == len(items) - 1:
            rc, out = run_ml("--help") if False else (0, "")
            dlg.ok("Status",
                   f"Runtime: {runtime_dir()}\n"
                   f"Hosts: {len(hosts)}\n"
                   f"Auflösung: {ADDON.getSetting('resolution') or '720'}p")
        else:
            stream_host(dlg, hosts[idx - 1])


if __name__ == "__main__":
    main()
