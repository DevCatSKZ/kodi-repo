# -*- coding: utf-8 -*-
# plugin.nconnect.status - lists controllers connected via N-Connect as items
# (for use as a skin widget content path). Clicking a controller opens its
# own submenu with the same actions the N-Connect menu offers.
import os
import sys
import json
import time
from urllib.parse import parse_qsl, urlencode
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

STATUS_JSON = xbmcvfs.translatePath(
    'special://profile/addon_data/service.nconnect/status.json')
NCONNECT_ICON = xbmcvfs.translatePath(
    'special://home/addons/service.nconnect/resources/icon.png')
NCONNECT_ICONS = xbmcvfs.translatePath(
    'special://home/addons/service.nconnect/resources/icons')
FALLBACK_ICON = 'DefaultAddonGame.png'

ICON_WARN = 'DefaultIconWarning.png'
ICON_INFO = 'DefaultIconInfo.png'
ICON_SERVICE = 'DefaultAddonService.png'

_KIND_ICONS = {
    'JoyCon2Left': 'joycon_l.png', 'JoyCon2Right': 'joycon_r.png',
    'JoyConLeft': 'joycon_l.png', 'JoyConRight': 'joycon_r.png',
    'ProController2': 'pro.png', 'ProController': 'pro.png',
    'GameCube2': 'gamecube.png', 'GameCube': 'gamecube.png',
}


def icon():
    own = os.path.join(xbmcaddon.Addon().getAddonInfo('path'),
                       'resources', 'icon.png')
    for candidate in (own, NCONNECT_ICON):
        if os.path.exists(candidate):
            return candidate
    return FALLBACK_ICON


def _nconnect_icon(filename):
    """Icon aus service.nconnect/resources/icons (vorhanden ab service.nconnect 0.3.2)."""
    path = os.path.join(NCONNECT_ICONS, filename)
    return path if os.path.exists(path) else icon()


def kind_icon(kind, name=''):
    if kind in _KIND_ICONS:
        return _nconnect_icon(_KIND_ICONS[kind])
    lower = (name or '').lower()
    if 'joy-con' in lower:
        return _nconnect_icon('joycon_l.png' if '(l' in lower else 'joycon_r.png')
    for key, fname in (('xbox', 'xbox.png'), ('playstation', 'playstation.png'),
                       ('dualshock', 'playstation.png'), ('dualsense', 'playstation.png'),
                       ('gamecube', 'gamecube.png')):
        if key in lower:
            return _nconnect_icon(fname)
    return _nconnect_icon('gamepad.png')


def player_icon(player):
    devices = player.get('devices', [])
    if len(devices) > 1:
        return _nconnect_icon('joycon_pair.png')
    for d in devices:
        if d.get('kind') in _KIND_ICONS:
            return _nconnect_icon(_KIND_ICONS[d['kind']])
    return kind_icon('', player.get('name'))


def battery_str(dev):
    parts = []
    if dev.get('battery', -1) >= 0:
        parts.append('Akku %d%%' % int(dev['battery']))
    if dev.get('charging'):
        parts.append('wird geladen')
    return ' | '.join(parts)


def read_status():
    try:
        with open(STATUS_JSON, 'r', encoding='utf-8') as f:
            status = json.load(f)
        age = time.time() - os.path.getmtime(STATUS_JSON)
    except (OSError, ValueError):
        return None
    state = status.get('state')
    if state == 'running' and age <= 15 or state == 'starting' and age <= 60:
        return status
    return None


def send_command(command):
    # same transport the N-Connect menu uses (NotifyAll is forwarded to the daemon)
    xbmc.executebuiltin('NotifyAll(service.nconnect,{0})'.format(command))


def url(**params):
    return '{0}?{1}'.format(sys.argv[0], urlencode(params))


def entry(label, label2='', art=None, plot='', params=None, folder=True):
    li = xbmcgui.ListItem(label, label2)
    art = art or icon()
    li.setArt({'icon': art, 'thumb': art, 'poster': art})
    if plot:
        li.setInfo('video', {'title': label, 'plot': plot})
    target = url(**params) if params else url(action='list')
    return (target, li, folder)


def player_plot(p):
    rows = []
    for d in p.get('devices', []):
        rows.append('[B]{0}[/B]'.format(d.get('name', '?')))
        if d.get('address'):
            rows.append('Adresse: {0}'.format(d['address']))
        if d.get('serial'):
            rows.append('Seriennummer: {0}'.format(d['serial']))
        if d.get('firmware'):
            rows.append('Firmware: {0}'.format(d['firmware']))
        if d.get('battery', -1) >= 0:
            rows.append('Akku: {0}%'.format(int(d['battery'])))
        if d.get('rate'):
            rows.append('Rate: {0} Hz'.format(int(d['rate'])))
        rows.append('')
    return '[CR]'.join(rows)


def player_label2(p):
    parts = ['Spieler {0}'.format(p.get('player', '?'))]
    info = battery_str(p)
    if p.get('devices'):
        sub = [battery_str(d) for d in p['devices'] if battery_str(d)]
        if sub:
            info = ' | '.join(sub)
    parts.append(info or 'verbunden')
    if p.get('charging') and 'wird geladen' not in info:
        parts.append('wird geladen')
    rate = sum(int(d.get('rate', 0)) for d in p.get('devices', []))
    if rate:
        parts.append('{0} Hz'.format(rate))
    return ' | '.join(parts)


def build_list(handle):
    items = []
    status = read_status()

    if status is None:
        items.append(entry('N-Connect: kein Status', 'Dienst nicht aktiv',
                           art=ICON_WARN))
    elif status.get('state') == 'starting':
        items.append(entry('N-Connect startet...', 'Bitte warten',
                           art=ICON_INFO))
    elif status.get('bluetooth') != 'on':
        bt = status.get('bluetooth')
        note = 'Bluetooth fehlt' if bt == 'missing' else 'Bluetooth aus'
        items.append(entry(note, 'In den LibreELEC-Einstellungen aktivieren',
                           art=ICON_WARN))
    else:
        players = status.get('players') or []
        gamepads = status.get('gamepads') or []
        connecting = status.get('connecting') or []

        for p in players:
            num = p.get('player', '?')
            name = p.get('name') or 'Controller'
            items.append(entry(name, player_label2(p), art=player_icon(p),
                               plot=player_plot(p),
                               params={'action': 'player', 'player': num}))
        for g in gamepads:
            name = g.get('name') or 'Gamepad'
            if not g.get('connected'):
                continue
            items.append(entry(name, battery_str(g) or 'verbunden',
                               art=kind_icon('', name),
                               params={'action': 'gamepad',
                                       'address': g.get('address', ''),
                                       'name': name}))
        for c in connecting:
            items.append(entry('Verbindet...', str(c), art=ICON_INFO,
                               params={'action': 'list'}))

        if not players and not gamepads and not connecting:
            note = 'Keine Controller verbunden'
            if status.get('scanning'):
                note += ' - Suche aktiv'
            items.append(entry(note, 'SYNC-Taste am Controller druecken',
                               art=ICON_INFO, params={'action': 'list'}))

    items.append(entry('Aktualisieren', 'Anzeige neu laden', art=ICON_INFO,
                       params={'action': 'list'}))
    items.append(entry('N-Connect Menue oeffnen', 'Pairing, Diagnose, Einstellungen',
                       art=ICON_SERVICE, params={'action': 'menu'}))

    for target, li, folder in items:
        xbmcplugin.addDirectoryItem(handle, target, li, folder)
    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False,
                              cacheToDisc=False)


def show_player_actions(handle, status, num):
    player = None
    for p in (status or {}).get('players', []):
        if str(p.get('player')) == str(num):
            player = p
            break
    if player is None:
        items = [entry('Controller nicht mehr verbunden', '', art=ICON_WARN,
                       params={'action': 'list'})]
    else:
        name = player.get('name') or 'Controller'
        title = 'Spieler {0}: {1}'.format(num, name)
        items = [
            entry('{0} trennen'.format(name), 'Verbindung beenden',
                  art=ICON_WARN,
                  params={'action': 'cmd', 'cmd': 'disconnect-{0}'.format(num),
                          'back': 'player:{0}'.format(num)}),
            entry('Details', player_label2(player), plot=player_plot(player),
                  params={'action': 'playerdetails', 'player': num}),
            entry('Zurueck', '', params={'action': 'list'}),
        ]
    for target, li, folder in items:
        xbmcplugin.addDirectoryItem(handle, target, li, folder)
    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False,
                              cacheToDisc=False)


def show_player_details(handle, status, num):
    player = None
    for p in (status or {}).get('players', []):
        if str(p.get('player')) == str(num):
            player = p
            break
    items = []
    if player is None:
        items.append(entry('Controller nicht mehr verbunden', '', art=ICON_WARN,
                           params={'action': 'list'}))
    else:
        refresh = {'action': 'playerdetails', 'player': num}
        items.append(entry('Spieler {0}: {1}'.format(num, player.get('name')),
                           player_label2(player), params=refresh))
        for d in player.get('devices', []):
            details = []
            if d.get('address'):
                details.append(d['address'])
            if d.get('battery', -1) >= 0:
                details.append('Akku {0}%'.format(int(d['battery'])))
            if d.get('rate'):
                details.append('{0} Hz'.format(int(d['rate'])))
            plot = player_plot({'devices': [d]})
            items.append(entry(d.get('name', '?'), ' | '.join(details),
                               art=kind_icon(d.get('kind'), d.get('name')),
                               plot=plot, params=refresh))
            if d.get('serial'):
                items.append(entry('  Seriennummer', d['serial'],
                                   params=refresh))
            if d.get('firmware'):
                items.append(entry('  Firmware', d['firmware'],
                                   params=refresh))
        items.append(entry('Zurueck', '',
                           params={'action': 'player', 'player': num}))
    for target, li, folder in items:
        xbmcplugin.addDirectoryItem(handle, target, li, folder)
    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False,
                              cacheToDisc=False)


def show_gamepad_actions(handle, status, address, name):
    pad = None
    for g in (status or {}).get('gamepads', []):
        if g.get('address') == address:
            pad = g
            break
    if pad is None:
        items = [entry('Gamepad nicht gefunden', '', art=ICON_WARN,
                       params={'action': 'list'})]
    else:
        items = []
        if pad.get('connected'):
            items.append(entry('{0} trennen'.format(name),
                               'Verbindung beenden', art=ICON_WARN,
                               params={'action': 'cmd',
                                       'cmd': 'gamepad-disconnect-{0}'.format(address),
                                       'back': 'list'}))
        items.append(entry('{0} vergessen'.format(name),
                           'Kopplung entfernen', art=ICON_WARN,
                           params={'action': 'cmd',
                                   'cmd': 'gamepad-forget-{0}'.format(address),
                                   'back': 'list'}))
        refresh = {'action': 'gamepad', 'address': address, 'name': name}
        if pad.get('battery', -1) >= 0:
            items.append(entry('Akku', '{0}%'.format(int(pad['battery'])),
                               params=refresh))
        items.append(entry('Adresse', address, params=refresh))
        items.append(entry('Zurueck', '', params={'action': 'list'}))
    for target, li, folder in items:
        xbmcplugin.addDirectoryItem(handle, target, li, folder)
    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False,
                              cacheToDisc=False)


def run_command(handle, cmd, back):
    send_command(cmd)
    xbmcgui.Dialog().notification('N-Connect', 'Befehl gesendet: {0}'.format(cmd),
                                  icon(), 2500)
    xbmc.sleep(800)
    status = read_status()
    if back and back.startswith('player:'):
        show_player_actions(handle, status, back.split(':', 1)[1])
    else:
        build_list(handle)


def main():
    handle = int(sys.argv[1]) if len(sys.argv) > 1 else 0
    params = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    action = params.get('action', 'list')

    if action == 'cmd':
        run_command(handle, params.get('cmd', ''), params.get('back', ''))
        return
    if action == 'menu':
        xbmc.executebuiltin('RunScript(service.nconnect)')
        build_list(handle)
        return
    if action == 'player':
        show_player_actions(handle, read_status(), params.get('player'))
        return
    if action == 'playerdetails':
        show_player_details(handle, read_status(), params.get('player'))
        return
    if action == 'gamepad':
        show_gamepad_actions(handle, read_status(), params.get('address', ''),
                             params.get('name', 'Gamepad'))
        return
    build_list(handle)


if __name__ == '__main__':
    main()
