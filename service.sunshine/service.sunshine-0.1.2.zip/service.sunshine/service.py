#!/usr/bin/env python3
"""Sunshine service daemon for LibreELEC.

Prepares the runtime environment (/usr/share overlayfs, config,
LD_LIBRARY_PATH) and keeps sunshine running while Kodi is up.
"""
import os
import shutil
import subprocess
import sys
import time
import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon("service.sunshine")
ADDON_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
PROFILE_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))

USR_SHARE = "/usr/share"
SHARE_UPPER = "/storage/sunshine-share-upper"
SHARE_WORK = "/storage/sunshine-share-work"
# Leftovers from the old symlink-mirror overlay approach
LEGACY_SHARE_DIRS = ("/storage/sunshine-share-overlay",
                     "/storage/sunshine-share-real")


def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"sunshine: {msg}", level)


def runtime_dir():
    return ADDON.getSetting("runtime_dir") or os.path.join(
        ADDON_DIR, "resources", "runtime", "aarch64")


def share_src():
    return os.path.join(runtime_dir(), "share", "sunshine")


def sunshine_bin():
    return os.path.join(runtime_dir(), "bin", "sunshine")


def config_dir():
    # sunshine uses $HOME/.config/sunshine
    return "/storage/.config/sunshine"


def _overlay_healthy():
    # If the overlay ever shadows real content we break ALSA/Kodi —
    # sanity-probe well-known files before trusting the mount.
    return (os.path.exists("/usr/share/sunshine/apps.json")
            and os.path.exists("/usr/share/alsa/alsa.conf")
            and os.path.isdir("/usr/share/kodi"))


def _peel_stale_mounts(path):
    """Our overlay leaves a 'sunshine' entry behind — the real
    /usr/share never has one. Peel stacked mounts until the entry
    is gone."""
    for _ in range(5):
        if not os.path.ismount(path):
            return
        if not os.path.lexists(os.path.join(path, "sunshine")):
            return
        subprocess.run(["umount", path], capture_output=True)


def ensure_share_overlay():
    """Sunshine's assets path (/usr/share/sunshine) is compiled in and
    /usr/share is SquashFS. Merge the runtime assets on top with
    overlayfs. Idempotent; rolls back on failure."""
    if _overlay_healthy():
        return True
    if not os.path.isdir(share_src()):
        log(f"sunshine assets missing at {share_src()}", xbmc.LOGERROR)
        return False
    _peel_stale_mounts(USR_SHARE)
    for legacy in LEGACY_SHARE_DIRS:
        _peel_stale_mounts(legacy)
        shutil.rmtree(legacy, ignore_errors=True)
    for d in (SHARE_UPPER, SHARE_WORK):
        os.makedirs(d, exist_ok=True)
    link = os.path.join(SHARE_UPPER, "sunshine")
    if os.path.lexists(link):
        os.remove(link)
    os.symlink(share_src(), link)
    r = subprocess.run(
        ["mount", "-t", "overlay", "overlay",
         "-o", f"lowerdir={USR_SHARE},upperdir={SHARE_UPPER},"
               f"workdir={SHARE_WORK}", USR_SHARE],
        capture_output=True, text=True)
    if r.returncode != 0:
        log(f"overlay mount failed: {r.stderr.strip()}", xbmc.LOGERROR)
        return False
    if not _overlay_healthy():
        for p in ("sunshine/apps.json", "alsa/alsa.conf", "kodi"):
            log(f"probe {p}: "
                f"{os.path.exists(os.path.join(USR_SHARE, p))}",
                xbmc.LOGWARNING)
        log("overlay self-test failed — rolling back", xbmc.LOGERROR)
        subprocess.run(["umount", USR_SHARE], capture_output=True)
        return False
    log("/usr/share overlay active")
    return True


def teardown_share_overlay():
    _peel_stale_mounts(USR_SHARE)
    _peel_stale_mounts(SHARE_WORK)


def ensure_audio_sink():
    """LibreELEC runs pulseaudio in system mode, but Kodi talks to
    ALSA directly — so pulse has only the null sink. Load the ALSA
    card into pulse so audio actually flows through it; sunshine then
    captures the sink's monitor. Idempotent."""
    try:
        out = subprocess.run(["pactl", "list", "short", "sinks"],
                             capture_output=True, text=True).stdout
        if "alsa_output." in out:
            return True
        for card in ("0", "1"):
            if subprocess.run(
                    ["pactl", "load-module", "module-alsa-card",
                     "device_id=" + card],
                    capture_output=True).returncode == 0:
                log(f"pulse alsa card {card} loaded")
                return True
    except OSError:
        pass
    log("pulse audio sink setup failed — stream may be silent",
        xbmc.LOGWARNING)
    return False


def ensure_config():
    cfg = config_dir()
    os.makedirs(cfg, exist_ok=True)
    conf = os.path.join(cfg, "sunshine.conf")
    content = ""
    if os.path.exists(conf):
        content = open(conf).read()
    changed = False
    if "system_tray" not in content:
        content += "\nsystem_tray = false\n"
        changed = True
    if "audio_sink" not in content:
        try:
            sinks = ""
            for _ in range(5):
                sinks = subprocess.run(
                    ["pactl", "list", "short", "sinks"],
                    capture_output=True, text=True).stdout
                if "alsa_output." in sinks:
                    break
                time.sleep(2)
            for line in sinks.splitlines():
                parts = line.split("\t")
                if len(parts) > 1 and parts[1].startswith("alsa_output."):
                    content += f"\naudio_sink = {parts[1]}\n"
                    changed = True
                    break
        except OSError:
            pass
    port = ADDON.getSetting("webui_port") or "47990"
    if "port =" not in content and port != "47990":
        content += f"\nport = {port}\n"
        changed = True
    if changed:
        with open(conf, "w") as f:
            f.write(content.lstrip())
    return True


def sunshine_env():
    env = dict(os.environ)
    env["HOME"] = "/storage"
    env["LD_LIBRARY_PATH"] = os.path.join(runtime_dir(), "lib") +         ":" + env.get("LD_LIBRARY_PATH", "")
    return env


def is_running():
    r = subprocess.run(["pgrep", "-f", "bin/sunshine"],
                       capture_output=True)
    return r.returncode == 0


def start():
    if not os.path.isfile(sunshine_bin()):
        log(f"runtime missing at {sunshine_bin()} — run the addon menu to install",
            xbmc.LOGERROR)
        return False
    if not ensure_share_overlay():
        return False
    ensure_audio_sink()
    ensure_config()
    if is_running():
        log("already running")
        return True
    proc = subprocess.Popen(
        [sunshine_bin()],
        env=sunshine_env(),
        stdout=subprocess.DEVNULL,
        stderr=subprocess.STDOUT,
        stdin=subprocess.DEVNULL,
        start_new_session=True,
    )
    log(f"sunshine started, pid {proc.pid}")
    return True


def stop():
    subprocess.run(["pkill", "-f", "bin/sunshine"], capture_output=True)
    log("sunshine stopped")


def main():
    if ADDON.getSetting("autostart") != "false":
        if not os.path.isfile(sunshine_bin()):
            log("no runtime installed yet — open the addon once to fetch it")
        else:
            start()
    monitor = xbmc.Monitor()
    while not monitor.waitForAbort(10):
        pass
    stop()
    teardown_share_overlay()


if __name__ == "__main__":
    main()
