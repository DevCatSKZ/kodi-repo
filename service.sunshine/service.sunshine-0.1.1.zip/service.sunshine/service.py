#!/usr/bin/env python3
"""Sunshine service daemon for LibreELEC.

Prepares the runtime environment (shared-asset overlay, config,
LD_LIBRARY_PATH) and keeps sunshine running while Kodi is up.
"""
import os
import subprocess
import sys
import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon("service.sunshine")
ADDON_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
PROFILE_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))

USR_SHARE = "/usr/share"
SHARE_OVERLAY = "/storage/sunshine-share-overlay"


def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"sunshine: {msg}", level)


def runtime_dir():
    return ADDON.getSetting("runtime_dir") or os.path.join(
        ADDON_DIR, "resources", "runtime", "aarch64")


def share_src():
    return os.path.join(runtime_dir(), "share", "sunshine")


def sunshine_bin():
    return os.path.join(runtime_dir(), "bin", "sunshine")


def config_dir():
    # sunshine uses $HOME/.config/sunshine
    return "/storage/.config/sunshine"


def ensure_share_overlay():
    """/usr/share is SquashFS — mirror it with symlinks, add the real
    sunshine asset dir, bind-mount back. Idempotent."""
    if os.path.ismount(USR_SHARE) or xbmcvfs.exists(
            os.path.join(USR_SHARE, "sunshine", "apps.json")):
        return True
    os.makedirs(SHARE_OVERLAY, exist_ok=True)
    for entry in os.listdir(USR_SHARE):
        if entry == "sunshine":
            continue
        link = os.path.join(SHARE_OVERLAY, entry)
        if not os.path.exists(link):
            os.symlink(os.path.join(USR_SHARE, entry), link)
    dst = os.path.join(SHARE_OVERLAY, "sunshine")
    if not os.path.isdir(dst):
        subprocess.run(["cp", "-r", share_src(), dst], check=False)
    if not os.path.isdir(os.path.join(dst, "web")):
        log("sunshine assets missing in overlay", xbmc.LOGERROR)
        return False
    r = subprocess.run(["mount", "--bind", SHARE_OVERLAY, USR_SHARE],
                       capture_output=True, text=True)
    if r.returncode != 0:
        log(f"bind-mount /usr/share failed: {r.stderr.strip()}", xbmc.LOGERROR)
        return False
    log("/usr/share overlay active")
    return True


def ensure_audio_sink():
    """LibreELEC runs pulseaudio in system mode, but Kodi talks to
    ALSA directly — so pulse has only the null sink. Load the ALSA
    card into pulse so audio actually flows through it; sunshine then
    captures the sink's monitor. Idempotent."""
    try:
        out = subprocess.run(["pactl", "list", "short", "sinks"],
                             capture_output=True, text=True).stdout
        if "alsa_output." in out:
            return True
        for card in ("0", "1"):
            if subprocess.run(
                    ["pactl", "load-module", "module-alsa-card",
                     "device_id=" + card],
                    capture_output=True).returncode == 0:
                log(f"pulse alsa card {card} loaded")
                return True
    except OSError:
        pass
    log("pulse audio sink setup failed — stream may be silent",
        xbmc.LOGWARNING)
    return False


def ensure_config():
    cfg = config_dir()
    os.makedirs(cfg, exist_ok=True)
    conf = os.path.join(cfg, "sunshine.conf")
    content = ""
    if os.path.exists(conf):
        content = open(conf).read()
    changed = False
    if "system_tray" not in content:
        content += "\nsystem_tray = false\n"
        changed = True
    if "audio_sink" not in content:
        try:
            sinks = ""
            for _ in range(5):
                sinks = subprocess.run(
                    ["pactl", "list", "short", "sinks"],
                    capture_output=True, text=True).stdout
                if "alsa_output." in sinks:
                    break
                time.sleep(2)
            for line in sinks.splitlines():
                parts = line.split("\t")
                if len(parts) > 1 and parts[1].startswith("alsa_output."):
                    content += f"\naudio_sink = {parts[1]}\n"
                    changed = True
                    break
        except OSError:
            pass
    port = ADDON.getSetting("webui_port") or "47990"
    if "port =" not in content and port != "47990":
        content += f"\nport = {port}\n"
        changed = True
    if changed:
        with open(conf, "w") as f:
            f.write(content.lstrip())
    return True


def sunshine_env():
    env = dict(os.environ)
    env["HOME"] = "/storage"
    env["LD_LIBRARY_PATH"] = os.path.join(runtime_dir(), "lib") + \
        ":" + env.get("LD_LIBRARY_PATH", "")
    return env


def is_running():
    r = subprocess.run(["pgrep", "-f", "bin/sunshine"],
                       capture_output=True)
    return r.returncode == 0


def start():
    if not xbmcvfs.exists(sunshine_bin()):
        log(f"runtime missing at {sunshine_bin()} — run the addon menu to install", xbmc.LOGERROR)
        return False
    if not ensure_share_overlay():
        return False
    ensure_audio_sink()
    ensure_config()
    if is_running():
        log("already running")
        return True
    proc = subprocess.Popen(
        [sunshine_bin()],
        env=sunshine_env(),
        stdout=subprocess.DEVNULL,
        stderr=subprocess.STDOUT,
        stdin=subprocess.DEVNULL,
        start_new_session=True,
    )
    log(f"sunshine started, pid {proc.pid}")
    return True


def stop():
    subprocess.run(["pkill", "-f", "bin/sunshine"], capture_output=True)
    log("sunshine stopped")


def main():
    if ADDON.getSetting("autostart") != "false":
        if not xbmcvfs.exists(sunshine_bin()):
            log("no runtime installed yet — open the addon once to fetch it")
        else:
            start()
    monitor = xbmc.Monitor()
    while not monitor.waitForAbort(10):
        pass
    stop()


if __name__ == "__main__":
    main()
