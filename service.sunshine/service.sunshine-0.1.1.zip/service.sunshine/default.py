#!/usr/bin/env python3
"""Sunshine addon menu — status, start/stop, runtime install."""
import os
import subprocess
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon("service.sunshine")
ADDON_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
FETCHER = os.path.join(ADDON_DIR, "resources", "bin", "fetch_runtime.py")


def runtime_dir():
    return ADDON.getSetting("runtime_dir") or os.path.join(
        ADDON_DIR, "resources", "runtime", "aarch64")


def sunshine_bin():
    return os.path.join(runtime_dir(), "bin", "sunshine")


def is_running():
    return subprocess.run(["pgrep", "-f", "bin/sunshine"],
                          capture_output=True).returncode == 0


def get_ip():
    try:
        import socket
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "<ip>"


def do_start():
    r = subprocess.run(
        [sys_exe(), os.path.join(ADDON_DIR, "service_ctl.py"), "start"],
        capture_output=True, text=True)
    xbmcgui.Dialog().notification("Sunshine", "Dienst gestartet" if r.returncode == 0 else "Start fehlgeschlagen")


def sys_exe():
    return "python3"  # LibreELEC ships system python3


def install_runtime():
    dlg = xbmcgui.Dialog()
    if not xbmcvfs.exists(FETCHER):
        dlg.ok("Sunshine", "Fetcher nicht gefunden:\n" + FETCHER)
        return
    if not dlg.yesno(
            "Sunshine Runtime installieren",
            "Lädt Sunshine + Abhängigkeiten aus dem Ubuntu-Repo herunter\n"
            "und installiert sie nach /storage/sunshine-runtime (~300 MB).\n\n"
            "Fortfahren?"):
        return
    progress = xbmcgui.DialogProgress()
    progress.create("Sunshine Runtime", "Pakete werden geladen…")
    env = dict(os.environ)
    env["SUNSHINE_RUNTIME_DIR"] = "/storage/sunshine-runtime"
    proc = subprocess.Popen(
        [sys_exe(), FETCHER], env=env,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    line = ""
    while proc.poll() is None:
        out = proc.stdout.readline() if proc.stdout else ""
        if out:
            line = out.strip()[:80]
            progress.update(50, line)
        if progress.iscanceled():
            proc.terminate()
            progress.close()
            return
    progress.close()
    if proc.returncode == 0:
        dlg.ok("Sunshine", "Runtime installiert.\nSunshine startet beim nächsten Kodi-Start automatisch.")
    else:
        dlg.ok("Sunshine", "Installation fehlgeschlagen (siehe Log).")


def main():
    dlg = xbmcgui.Dialog()
    port = ADDON.getSetting("webui_port") or "47990"
    webui = f"https://{get_ip()}:{port}"
    items = [
        "Status anzeigen",
        "Sunshine starten",
        "Sunshine stoppen",
        "Runtime installieren / aktualisieren",
        "Web-UI-Adresse anzeigen",
    ]
    while True:
        idx = dlg.select("Sunshine Game Stream Host", items)
        if idx == -1:
            return
        if idx == 0:
            installed = xbmcvfs.exists(sunshine_bin())
            dlg.ok("Status",
                   f"Runtime installiert: {'ja' if installed else 'NEIN'}\n"
                   f"Pfad: {runtime_dir()}\n"
                   f"Dienst läuft: {'ja' if is_running() else 'nein'}\n"
                   f"Web-UI: {webui}")
        elif idx == 1:
            do_start()
        elif idx == 2:
            subprocess.run(["pkill", "-f", "bin/sunshine"], capture_output=True)
            xbmcgui.Dialog().notification("Sunshine", "Dienst gestoppt")
        elif idx == 3:
            install_runtime()
        elif idx == 4:
            dlg.ok("Web-UI",
                   f"{webui}\n\n"
                   "Beim ersten Aufruf Benutzername + Passwort wählen,\n"
                   "danach Clients per PIN paaren.")


if __name__ == "__main__":
    main()
