#!/usr/bin/env python3
"""One-shot control entry: `service_ctl.py start|stop` (used by the menu)."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

if __name__ == "__main__":
    import service
    cmd = sys.argv[1] if len(sys.argv) > 1 else "start"
    if cmd == "start":
        sys.exit(0 if service.start() else 1)
    if cmd == "stop":
        service.stop()
        sys.exit(0)
    sys.exit(2)
