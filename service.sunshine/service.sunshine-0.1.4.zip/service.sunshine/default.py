#!/usr/bin/env python3
"""Sunshine addon menu — status, start/stop, runtime install."""
import json
import os
import socket
import sys
import threading
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon("service.sunshine")
ADDON_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
FETCHER = os.path.join(ADDON_DIR, "resources", "bin", "fetch_runtime.py")
sys.path.insert(0, os.path.join(ADDON_DIR, "resources", "lib"))
import sunshinectl as core  # noqa: E402

STOPPED_PROP = "service.sunshine.stopped"   # read by service.py
L = ADDON.getLocalizedString


def log(msg, error=False):
    xbmc.log("sunshine: " + msg, xbmc.LOGERROR if error else xbmc.LOGINFO)


core.LOG = log


def runtime_dir():
    return ADDON.getSetting("runtime_dir") or core.DEFAULT_RUNTIME


def webui_port():
    return core.parse_port(ADDON.getSetting("webui_port"))


def get_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except OSError:
        return "<ip>"


def webui_url():
    return "https://%s:%d" % (get_ip(), core.webui_port_from_conf())


def jsonrpc(method, params):
    return json.loads(xbmc.executeJSONRPC(json.dumps(
        {"jsonrpc": "2.0", "id": 1, "method": method, "params": params})))


def kodi_audio_device():
    # live value — guisettings.xml is only written when Kodi saves
    try:
        return jsonrpc("Settings.GetSettingValue",
                       {"setting": "audiooutput.audiodevice"})["result"]["value"]
    except (KeyError, TypeError, ValueError):
        return core.kodi_audio_device()


def kodi_on_pulse():
    return kodi_audio_device().startswith("PULSE:")


def show_status(dlg):
    rt = runtime_dir()
    have = core.installed(rt)
    text = L(32020) % (
        rt, core.installed_version(rt) or (L(32037) if have else L(32023)),
        L(32021) if core.is_running(rt) else L(32022), webui_url(),
        kodi_audio_device().split("|")[0] or "-")
    if have and not kodi_on_pulse():
        text += "\n" + L(32024)      # dialogs hold ~7 lines in some skins
    dlg.ok(L(32010), text)


def do_start():
    xbmcgui.Window(10000).clearProperty(STOPPED_PROP)
    core.start(runtime_dir(), webui_port())
    ok = core.is_running(runtime_dir())
    xbmcgui.Dialog().notification(
        "Sunshine", L(32025) if ok else L(32026),
        xbmcgui.NOTIFICATION_INFO if ok else xbmcgui.NOTIFICATION_ERROR)


def do_stop():
    xbmcgui.Window(10000).setProperty(STOPPED_PROP, "1")
    core.stop(runtime_dir())
    xbmcgui.Dialog().notification("Sunshine", L(32027))


def install_runtime(dlg):
    rt = runtime_dir()
    if not dlg.yesno(L(32013), L(32028) % rt):
        return
    progress = xbmcgui.DialogProgress()
    progress.create(L(32013), L(32029))
    state = {"line": "", "count": 0, "cancel": False,
             "done": False, "result": None, "error": None}

    def on_line(line):
        if line.startswith("GET "):
            state["count"] += 1
            name = line.rsplit("/", 1)[-1].split("_", 1)[0]
            state["line"] = "%d: %s" % (state["count"], name[:60])

    def worker():
        try:
            state["result"] = core.install_runtime(
                rt, FETCHER, on_line, lambda: state["cancel"])
        except Exception as exc:     # surfaced in the dialog below
            state["error"] = str(exc)
        state["done"] = True

    win = xbmcgui.Window(10000)
    win.setProperty(STOPPED_PROP, "1")      # keep the watchdog away
    t = threading.Thread(target=worker, daemon=True)
    t.start()
    while not state["done"]:
        xbmc.sleep(500)
        if progress.iscanceled():
            state["cancel"] = True
        # the package count is not known up front (~250): approach 99 %
        progress.update(int(99 * (1 - 0.985 ** state["count"])),
                        "%s\n%s" % (L(32029), state["line"]))
    progress.close()
    win.clearProperty(STOPPED_PROP)
    if state["error"]:
        dlg.ok(L(32013), "%s\n%s" % (L(32031), state["error"][-400:]))
        return
    version, _ = state["result"]
    core.start(rt, webui_port())
    dlg.ok(L(32013), L(32030) % version)


def switch_kodi_audio(dlg):
    if not dlg.yesno(L(32015), L(32033)):
        return
    core.ensure_audio_sink()
    try:
        res = jsonrpc("Settings.GetSettings",
                      {"level": "expert",
                       "filter": {"section": "system", "category": "audio"}})
        value = None
        for s in res["result"]["settings"]:
            if s.get("id") != "audiooutput.audiodevice":
                continue
            values = [o["value"] for o in s.get("options", [])]
            pulse = [v for v in values if v.startswith("PULSE:Default")] \
                or [v for v in values if v.startswith("PULSE:")]
            value = pulse[0] if pulse else None
        if value is None:
            raise RuntimeError("no PulseAudio output offered by Kodi")
        res = jsonrpc("Settings.SetSettingValue",
                      {"setting": "audiooutput.audiodevice", "value": value})
        if res.get("result") is not True:
            raise RuntimeError(str(res.get("error") or res))
    except (KeyError, ValueError, RuntimeError) as exc:
        dlg.ok(L(32015), "%s\n%s" % (L(32035), exc))
        return
    dlg.ok(L(32015), L(32034))


def show_log(dlg):
    text = core.log_tail(80)
    if not text:
        dlg.ok(L(32016), L(32036))
        return
    dlg.textviewer(core.SUNSHINE_LOG, text)


def main():
    dlg = xbmcgui.Dialog()
    while True:
        rt = runtime_dir()
        running = core.is_running(rt)
        items = [(L(32010), show_status)]
        if running:
            items.append((L(32012), lambda d: do_stop()))
        else:
            items.append((L(32011), lambda d: do_start()))
        items.append((L(32013), install_runtime))
        items.append((L(32014), lambda d: d.ok(
            L(32014), "%s\n\n%s" % (webui_url(), L(32032)))))
        if core.installed(rt) and not kodi_on_pulse():
            items.append((L(32015), switch_kodi_audio))
        items.append((L(32016), show_log))
        idx = dlg.select("Sunshine Game Stream Host", [i[0] for i in items])
        if idx == -1:
            return
        items[idx][1](dlg)


if __name__ == "__main__":
    main()
