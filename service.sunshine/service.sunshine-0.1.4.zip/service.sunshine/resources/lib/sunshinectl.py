"""Sunshine control core for LibreELEC — no Kodi imports.

Used by the Kodi service (service.py), the add-on menu (default.py)
and the SSH command line (service_ctl.py). Everything that needs Kodi
(settings, dialogs, logging) is passed in by the caller.
"""
import glob
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import time
import urllib.request
import xml.etree.ElementTree as ET

USR_SHARE = "/usr/share"
SHARE_UPPER = "/storage/sunshine-share-upper"
SHARE_WORK = "/storage/sunshine-share-work"
# Leftovers from the old symlink-mirror overlay approach
LEGACY_SHARE_DIRS = ("/storage/sunshine-share-overlay",
                     "/storage/sunshine-share-real")

CONFIG_DIR = "/storage/.config/sunshine"     # $HOME/.config/sunshine
CONF = os.path.join(CONFIG_DIR, "sunshine.conf")
SUNSHINE_LOG = os.path.join(CONFIG_DIR, "sunshine.log")
DEFAULT_RUNTIME = "/storage/sunshine-runtime"
DEFAULT_WEBUI_PORT = 47990                   # = Sunshine base port + 1
GUISETTINGS = "/storage/.kodi/userdata/guisettings.xml"
ADDON_SETTINGS = ("/storage/.kodi/userdata/addon_data/service.sunshine/"
                  "settings.xml")

RELEASE_API = "https://api.github.com/repos/LizardByte/Sunshine/releases/latest"
# the Ubuntu 22.04 build + jammy libraries is the combination verified
# on LibreELEC 12 (RPi4)
RELEASE_ASSET = re.compile(r"^sunshine_[\d.]+-\d+\+ubuntu22\.04_arm64\.deb$")
UBUNTU_PORTS = "https://ports.ubuntu.com/ubuntu-ports"
UBUNTU_DISTS = ("jammy", "jammy-updates")
# LibreELEC's own Mesa must be used: Ubuntu's libgbm/libEGL in the
# runtime make KMS capture fail ("Couldn't create GBM device")
HOST_LIBS = ("libEGL", "libgbm", "libGLESv2", "libLLVM", "libgallium")


def _log(msg, error=False):
    sys.stderr.write(("ERROR: " if error else "") + msg + "\n")


LOG = _log      # callers may replace this (Kodi: xbmc.log)


# ---- settings --------------------------------------------------------

def read_addon_settings(path=ADDON_SETTINGS):
    """Add-on settings as Kodi stores them (for use outside Kodi)."""
    cfg = {"autostart": "true", "runtime_dir": DEFAULT_RUNTIME,
           "webui_port": str(DEFAULT_WEBUI_PORT)}
    try:
        for s in ET.parse(path).getroot().iter("setting"):
            if s.get("id") in cfg and s.text:
                cfg[s.get("id")] = s.text.strip()
    except (OSError, ET.ParseError):
        pass
    return cfg


def parse_port(value):
    try:
        port = int(value)
    except (TypeError, ValueError):
        return DEFAULT_WEBUI_PORT
    return port if 1025 <= port <= 65535 else DEFAULT_WEBUI_PORT


# ---- runtime / process -----------------------------------------------

def sunshine_bin(runtime):
    return os.path.join(runtime, "bin", "sunshine")


def installed(runtime):
    return os.path.isfile(sunshine_bin(runtime))


def share_src(runtime):
    return os.path.join(runtime, "share", "sunshine")


def pids(runtime):
    """PIDs whose executable is this runtime's sunshine binary."""
    target = os.path.realpath(sunshine_bin(runtime))
    out = []
    for d in glob.glob("/proc/[0-9]*"):
        try:
            if os.readlink(d + "/exe") == target:
                out.append(int(os.path.basename(d)))
        except OSError:
            continue
    return out


def is_running(runtime):
    return bool(pids(runtime))


def sunshine_env(runtime):
    env = dict(os.environ)
    env["HOME"] = "/storage"
    env["LD_LIBRARY_PATH"] = (os.path.join(runtime, "lib") + ":"
                              + env.get("LD_LIBRARY_PATH", ""))
    return env


def start(runtime, webui_port=DEFAULT_WEBUI_PORT):
    """Prepare overlay/audio/config and start sunshine. Returns the
    Popen (None if it was running already or could not start)."""
    if not installed(runtime):
        LOG("runtime missing at %s — install it from the add-on menu"
            % sunshine_bin(runtime), error=True)
        return None
    if not ensure_share_overlay(runtime):
        return None
    sink = ensure_audio_sink()
    ensure_config(webui_port, sink)
    if is_running(runtime):
        LOG("already running")
        return None
    proc = subprocess.Popen(
        [sunshine_bin(runtime)],
        env=sunshine_env(runtime),
        stdout=subprocess.DEVNULL,
        stderr=subprocess.STDOUT,
        stdin=subprocess.DEVNULL,
        start_new_session=True,
    )
    LOG("sunshine started, pid %d" % proc.pid)
    return proc


def stop(runtime, timeout=5.0):
    """SIGTERM, then SIGKILL after `timeout` seconds."""
    running = pids(runtime)
    for pid in running:
        try:
            os.kill(pid, signal.SIGTERM)
        except OSError:
            pass
    end = time.time() + timeout
    while running and time.time() < end:
        time.sleep(0.2)
        running = pids(runtime)
    for pid in running:
        try:
            os.kill(pid, signal.SIGKILL)
        except OSError:
            pass
    LOG("sunshine stopped")


# ---- /usr/share overlay ----------------------------------------------

def _overlay_healthy():
    # If the overlay ever shadows real content we break ALSA/Kodi —
    # sanity-probe well-known files before trusting the mount.
    return (os.path.exists("/usr/share/sunshine/apps.json")
            and os.path.exists("/usr/share/alsa/alsa.conf")
            and os.path.isdir("/usr/share/kodi"))


def _peel_stale_mounts(path):
    """Our overlay leaves a 'sunshine' entry behind — the real
    /usr/share never has one. Peel stacked mounts until the entry
    is gone."""
    for _ in range(5):
        if not os.path.ismount(path):
            return
        if not os.path.lexists(os.path.join(path, "sunshine")):
            return
        subprocess.run(["umount", path], capture_output=True)


def ensure_share_overlay(runtime):
    """Sunshine's assets path (/usr/share/sunshine) is compiled in and
    /usr/share is SquashFS. Merge the runtime assets on top with
    overlayfs. Idempotent; rolls back on failure."""
    if _overlay_healthy():
        return True
    if not os.path.isdir(share_src(runtime)):
        LOG("sunshine assets missing at %s" % share_src(runtime),
            error=True)
        return False
    _peel_stale_mounts(USR_SHARE)
    for legacy in LEGACY_SHARE_DIRS + (os.path.join(runtime, "share-overlay"),):
        _peel_stale_mounts(legacy)
        if not os.path.ismount(legacy):
            shutil.rmtree(legacy, ignore_errors=True)
    for d in (SHARE_UPPER, SHARE_WORK):
        os.makedirs(d, exist_ok=True)
    link = os.path.join(SHARE_UPPER, "sunshine")
    if os.path.lexists(link):
        os.remove(link)
    os.symlink(share_src(runtime), link)
    r = subprocess.run(
        ["mount", "-t", "overlay", "overlay",
         "-o", "lowerdir=%s,upperdir=%s,workdir=%s"
         % (USR_SHARE, SHARE_UPPER, SHARE_WORK), USR_SHARE],
        capture_output=True, text=True)
    if r.returncode != 0:
        LOG("overlay mount failed: %s" % r.stderr.strip(), error=True)
        return False
    if not _overlay_healthy():
        for p in ("sunshine/apps.json", "alsa/alsa.conf", "kodi"):
            LOG("probe %s: %s"
                % (p, os.path.exists(os.path.join(USR_SHARE, p))))
        LOG("overlay self-test failed — rolling back", error=True)
        subprocess.run(["umount", USR_SHARE], capture_output=True)
        return False
    LOG("/usr/share overlay active")
    return True


def teardown_share_overlay():
    # usually EBUSY while Kodi still has /usr/share files open — the
    # mount then simply stays until reboot and is reused next start
    _peel_stale_mounts(USR_SHARE)


# ---- audio -----------------------------------------------------------

def _pactl(*args):
    try:
        return subprocess.run(["pactl"] + list(args), capture_output=True,
                              text=True, timeout=10)
    except (OSError, subprocess.TimeoutExpired):
        return None


def connected_alsa_card():
    """ALSA card index of the HDMI port with a display attached.
    Pi4: HDMI-A-1 is card id vc4hdmi0, HDMI-A-2 is vc4hdmi1."""
    cards = {}
    try:
        with open("/proc/asound/cards") as f:
            for line in f:
                m = re.match(r"\s*(\d+)\s+\[(\S+)\s*\]", line)
                if m:
                    cards[m.group(2)] = m.group(1)
    except OSError:
        return None
    for status in sorted(glob.glob("/sys/class/drm/card*-HDMI-A-*/status")):
        try:
            with open(status) as f:
                if f.read().strip() != "connected":
                    continue
        except OSError:
            continue
        n = int(status.split("HDMI-A-")[1].split("/")[0]) - 1
        if "vc4hdmi%d" % n in cards:
            return cards["vc4hdmi%d" % n]
    return None


def ensure_audio_sink(retries=5):
    """LibreELEC runs pulseaudio in system mode, but by default it only
    has a null sink. Load the ALSA card of the connected HDMI port into
    pulse and make it the default sink (Kodi set to PULSE:Default then
    plays through it); sunshine captures that sink's monitor.
    Idempotent. Returns the sink name or None."""
    want = connected_alsa_card()
    for attempt in range(retries):
        r = _pactl("list", "short", "sinks")
        if r is not None and r.returncode == 0:
            break
        time.sleep(2)          # pulse may still be starting at boot
    else:
        LOG("pulseaudio not reachable — stream may be silent", error=True)
        return None
    sinks = [parts[1] for parts in
             (line.split("\t") for line in r.stdout.splitlines())
             if len(parts) > 1 and parts[1].startswith("alsa_output.")]
    if want is not None:
        mine = [s for s in sinks if s.startswith("alsa_output.%s." % want)]
        if mine:
            return mine[0]
        # drop a sink for the other (unplugged) port from an earlier run
        mods = _pactl("list", "short", "modules")
        for line in (mods.stdout.splitlines() if mods else []):
            parts = line.split("\t")
            if len(parts) < 3 or parts[1] != "module-alsa-card":
                continue
            m = re.search(r"device_id=\"?(\d+)", parts[2])
            if m and m.group(1) != want:
                _pactl("unload-module", parts[0])
        candidates = [want]
    else:
        if sinks:
            return sinks[0]
        candidates = ["0", "1"]
    for card in candidates:
        r = _pactl("load-module", "module-alsa-card", "device_id=" + card)
        if r is None or r.returncode != 0:
            continue
        out = _pactl("list", "short", "sinks")
        for line in (out.stdout.splitlines() if out else []):
            parts = line.split("\t")
            if len(parts) > 1 and parts[1].startswith("alsa_output.%s." % card):
                _pactl("set-default-sink", parts[1])
                LOG("pulse sink %s loaded (ALSA card %s)" % (parts[1], card))
                return parts[1]
    LOG("pulse audio sink setup failed — stream may be silent", error=True)
    return None


def kodi_audio_device():
    try:
        for s in ET.parse(GUISETTINGS).getroot().iter("setting"):
            if s.get("id") == "audiooutput.audiodevice":
                return (s.text or "").strip()
    except (OSError, ET.ParseError):
        pass
    return ""


# ---- sunshine.conf ---------------------------------------------------

def _read_conf():
    try:
        with open(CONF) as f:
            return f.read()
    except OSError:
        return ""


def conf_value(content, key):
    m = re.search(r"(?m)^\s*%s\s*=\s*(.*?)\s*$" % re.escape(key), content)
    return m.group(1) if m else None


def _set_conf_value(content, key, value):
    line = "%s = %s" % (key, value)
    pattern = r"(?m)^\s*%s\s*=.*$" % re.escape(key)
    if re.search(pattern, content):
        return re.sub(pattern, line, content, count=1)
    if content and not content.endswith("\n"):
        content += "\n"
    return content + line + "\n"


def ensure_config(webui_port=DEFAULT_WEBUI_PORT, sink=None):
    """Keep the add-on's keys in sunshine.conf in line; everything else
    (written by Sunshine's web UI) stays as it is. Returns True if the
    file changed (a running sunshine then needs a restart)."""
    os.makedirs(CONFIG_DIR, exist_ok=True)
    old = _read_conf()
    content = old
    if conf_value(content, "system_tray") is None:
        content = _set_conf_value(content, "system_tray", "false")
    if sink and conf_value(content, "audio_sink") != sink:
        content = _set_conf_value(content, "audio_sink", sink)
    # Sunshine's "port" is the BASE port; the web UI listens on port+1.
    # Only write it for a non-default web UI port, so a port chosen in
    # Sunshine's own web UI is left alone.
    webui_port = parse_port(webui_port)
    if webui_port != DEFAULT_WEBUI_PORT:
        content = _set_conf_value(content, "port", str(webui_port - 1))
    if content == old:
        return False
    with open(CONF, "w") as f:
        f.write(content.lstrip())
    return True


def webui_port_from_conf():
    try:
        return int(conf_value(_read_conf(), "port")) + 1
    except (TypeError, ValueError):
        return DEFAULT_WEBUI_PORT


def log_tail(lines=40):
    try:
        with open(SUNSHINE_LOG, errors="replace") as f:
            return "".join(f.readlines()[-lines:])
    except OSError:
        return ""


# ---- runtime install -------------------------------------------------

def latest_release():
    """(version, deb_url, sha256) of the newest Sunshine release."""
    req = urllib.request.Request(RELEASE_API,
                                 headers={"User-Agent": "service.sunshine"})
    rel = json.loads(urllib.request.urlopen(req, timeout=30).read())
    for asset in rel.get("assets", []):
        if RELEASE_ASSET.match(asset.get("name", "")):
            digest = asset.get("digest") or ""
            sha = digest[7:] if digest.startswith("sha256:") else None
            return (rel.get("tag_name", "").lstrip("v"),
                    asset["browser_download_url"], sha)
    raise RuntimeError("no Ubuntu 22.04 arm64 package in release %s"
                       % rel.get("tag_name"))


def installed_version(runtime):
    try:
        with open(os.path.join(runtime, "VERSION")) as f:
            return f.read().strip()
    except OSError:
        pass
    # runtimes set up before the installer existed have no VERSION file;
    # a running sunshine from this runtime logs its version at start
    if not is_running(runtime):
        return ""
    try:
        with open(SUNSHINE_LOG, errors="replace") as f:
            m = re.search(r"Sunshine version: (\S+)", f.read(20000))
    except OSError:
        return ""
    return m.group(1) if m else ""


def install_runtime(runtime, fetcher, on_line=None, cancelled=None):
    """Fetch the newest Sunshine + libraries into runtime.new, then
    swap it in (old runtime kept until the new one is in place).
    Sunshine is stopped for the swap; the caller restarts it.
    Raises RuntimeError on failure. Returns (version, was_running)."""
    version, url, sha = latest_release()
    LOG("installing sunshine %s from %s" % (version, url))
    new = runtime + ".new"
    old = runtime + ".old"
    shutil.rmtree(new, ignore_errors=True)
    cmd = [sys.executable if os.path.basename(sys.executable).startswith("python")
           else "python3", fetcher, new, "--deb", url,
           "--mirror", UBUNTU_PORTS, "--arch", "arm64"]
    if sha:
        cmd += ["--deb-sha256", sha]
    for dist in UBUNTU_DISTS:
        cmd += ["--dist", dist]
    for prefix in HOST_LIBS:
        cmd += ["--skip-lib", prefix]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True)
    tail = []
    for line in proc.stdout:
        line = line.rstrip()
        tail = (tail + [line])[-20:]
        if on_line:
            on_line(line)
        if cancelled and cancelled():
            proc.kill()
            proc.wait()
            shutil.rmtree(new, ignore_errors=True)
            raise RuntimeError("cancelled")
    if proc.wait() != 0 or not installed(new) \
            or not os.path.isdir(share_src(new)):
        shutil.rmtree(new, ignore_errors=True)
        raise RuntimeError("fetch failed:\n" + "\n".join(tail[-8:]))
    with open(os.path.join(new, "VERSION"), "w") as f:
        f.write(version + "\n")
    was_running = is_running(runtime)
    stop(runtime)
    shutil.rmtree(old, ignore_errors=True)
    if os.path.isdir(runtime):
        os.rename(runtime, old)
    os.rename(new, runtime)
    shutil.rmtree(old, ignore_errors=True)
    LOG("sunshine %s installed to %s" % (version, runtime))
    return version, was_running
