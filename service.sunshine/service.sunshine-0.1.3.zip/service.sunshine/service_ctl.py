#!/usr/bin/env python3
"""Sunshine control from a shell (SSH), without Kodi.

    python3 service_ctl.py start|stop|restart|status|install

Uses the add-on's saved settings (runtime folder, web UI port).
Note: Kodi's service watchdog restarts a stopped sunshine unless it was
stopped from the add-on menu.
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "resources", "lib"))
import sunshinectl as core  # noqa: E402


def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else "status"
    cfg = core.read_addon_settings()
    rt = cfg["runtime_dir"]
    port = core.parse_port(cfg["webui_port"])
    if cmd == "start":
        core.start(rt, port)
        return 0 if core.is_running(rt) else 1
    if cmd == "stop":
        core.stop(rt)
        return 0
    if cmd == "restart":
        core.stop(rt)
        core.start(rt, port)
        return 0 if core.is_running(rt) else 1
    if cmd == "status":
        print("runtime:    %s (%s)" % (rt, core.installed_version(rt) or
                                       ("installed" if core.installed(rt)
                                        else "missing")))
        print("running:    %s" % (core.pids(rt) or "no"))
        print("web UI:     https://<ip>:%d" % core.webui_port_from_conf())
        print("kodi audio: %s" % (core.kodi_audio_device() or "-"))
        return 0
    if cmd == "install":
        fetcher = os.path.join(HERE, "resources", "bin", "fetch_runtime.py")
        version, was_running = core.install_runtime(rt, fetcher,
                                                    on_line=print)
        if was_running:
            core.start(rt, port)
        print("installed sunshine %s" % version)
        return 0
    sys.stderr.write(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main())
