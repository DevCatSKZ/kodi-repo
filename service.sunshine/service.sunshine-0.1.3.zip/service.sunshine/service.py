#!/usr/bin/env python3
"""Sunshine service for LibreELEC.

Prepares the runtime environment (/usr/share overlayfs, pulse sink,
sunshine.conf) and keeps sunshine running while Kodi is up: a
watchdog restarts it after a crash (at most 5 times in 10 minutes)
unless it was stopped on purpose from the add-on menu.
"""
import os
import sys
import time
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon("service.sunshine")
ADDON_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
sys.path.insert(0, os.path.join(ADDON_DIR, "resources", "lib"))
import sunshinectl as core  # noqa: E402

# set by the menu's "stop", cleared by its "start"
STOPPED_PROP = "service.sunshine.stopped"
RESTART_LIMIT = 5
RESTART_WINDOW = 600


def log(msg, error=False):
    xbmc.log("sunshine: " + msg, xbmc.LOGERROR if error else xbmc.LOGINFO)


core.LOG = log


class Monitor(xbmc.Monitor):
    changed = False

    def onSettingsChanged(self):
        self.changed = True


def runtime_dir():
    return ADDON.getSetting("runtime_dir") or core.DEFAULT_RUNTIME


def webui_port():
    return core.parse_port(ADDON.getSetting("webui_port"))


def autostart():
    return ADDON.getSetting("autostart") != "false"


def main():
    monitor = Monitor()
    win = xbmcgui.Window(10000)
    win.clearProperty(STOPPED_PROP)
    proc = None
    restarts = []
    gave_up = False
    if autostart():
        if core.installed(runtime_dir()):
            proc = core.start(runtime_dir(), webui_port())
        else:
            log("no runtime installed yet — open the add-on once to fetch it")
    while not monitor.waitForAbort(10):
        if proc is not None and proc.poll() is not None:
            proc = None                     # reap our exited child
        rt = runtime_dir()
        if monitor.changed:
            monitor.changed = False
            if core.ensure_config(webui_port()) and core.is_running(rt):
                log("settings changed — restarting sunshine")
                core.stop(rt)
                proc = core.start(rt, webui_port())
        if (not autostart() or win.getProperty(STOPPED_PROP)
                or not core.installed(rt) or core.is_running(rt)):
            continue
        now = time.time()
        restarts = [t for t in restarts if now - t < RESTART_WINDOW]
        if len(restarts) >= RESTART_LIMIT:
            if not gave_up:
                gave_up = True
                log("sunshine keeps exiting — watchdog gives up, see %s"
                    % core.SUNSHINE_LOG, error=True)
                xbmcgui.Dialog().notification(
                    "Sunshine", ADDON.getLocalizedString(32040),
                    xbmcgui.NOTIFICATION_ERROR, 6000)
            continue
        gave_up = False
        restarts.append(now)
        log("sunshine is not running — restarting")
        proc = core.start(rt, webui_port())
    core.stop(runtime_dir())
    core.teardown_share_overlay()


if __name__ == "__main__":
    main()
