# -*- coding: utf-8 -*-
"""Google-News-Links → Verlags-URL, wie in der App (GoogleNewsDecoder.kt):
alte CBMi…-IDs enthalten die URL; neue brauchen Signatur + Zeitstempel aus der
Artikelseite und Googles eigene Auflösung (batchexecute, RPC Fbv4je).

Google sperrt bei zu vielen Abfragen per Captcha (429) – Aufrufer drosseln,
nach einer Sperre wird hier ``RATE_LIMITED`` gemeldet."""
import base64
import json
import re
import time
from urllib.parse import urlencode

from catnewz import http

BATCH_URL = "https://news.google.com/_/DotsSplashUi/data/batchexecute"
CONSENT_COOKIE = "SOCS=CAI"
RATE_LIMITED = "rate-limited"

_ID_CHARS = re.compile(r"^[A-Za-z0-9_-]+$")
_TS = re.compile(r'data-n-a-ts="(\d+)"')
_SG = re.compile(r'data-n-a-sg="([A-Za-z0-9_-]+)"')

_cooldown_until = [0.0]
_COOLDOWN_SECONDS = 30 * 60


def _raw_id(url):
    tail = url.split("/articles/", 1)[1] if "/articles/" in url else ""
    return tail.split("?", 1)[0].split("/", 1)[0]


def article_id(url):
    raw = _raw_id(url)
    return raw if len(raw) >= 24 and _ID_CHARS.match(raw) else None


def decode_local(url):
    """Alte IDs (Base64-Protobuf mit eingebetteter URL) ohne Netz auflösen."""
    raw = _raw_id(url)
    if len(raw) < 24:
        return None
    try:
        padded = raw.replace("-", "+").replace("_", "/")
        padded += "=" * (-len(padded) % 4)
        data = base64.b64decode(padded)
    except (ValueError, TypeError):
        return None
    index = 0
    while index < len(data) - 12:
        if data[index:index + 4] == b"http":
            end = index
            while end < len(data) and 0x21 <= data[end] <= 0x7E:
                end += 1
            candidate = data[index:end].decode("ascii", "ignore")
            if candidate.startswith(("http://", "https://")) and "google.com" not in candidate:
                return candidate
            index = end
        else:
            index += 1
    return None


def _inner_request(article, timestamp, signature):
    return ('["garturlreq",[["X","X",["X","X"],null,null,1,1,"US:en",null,1,null,null,null,'
            'null,null,0,1],"X","X",1,[1,1,1],1,1,null,0,0,null,0],"%s",%s,"%s"]'
            % (article, timestamp, signature))


def batch_request(entries):
    """entries: [(Artikel-ID, Zeitstempel, Signatur)] – ein batchexecute für alle."""
    calls = [["Fbv4je", _inner_request(article, ts, sg), None, "generic"]
             for article, ts, sg in entries]
    return json.dumps([calls], separators=(",", ":"))


def parse_batch_responses(body):
    """Alle Verlags-URLs der Antwort in Anfrage-Reihenfolge (None pro Lücke)."""
    try:
        outer = json.loads(body[body.index("["):])
    except (ValueError, IndexError):
        return []
    urls = []
    for entry in outer:
        if not isinstance(entry, list) or len(entry) < 3:
            continue
        if entry[0] != "wrb.fr" or entry[1] != "Fbv4je" or not isinstance(entry[2], str):
            continue
        try:
            payload = json.loads(entry[2])
        except ValueError:
            continue
        url = payload[1] if payload and payload[0] == "garturlres" and len(payload) > 1 else None
        if isinstance(url, str) and url.startswith("http") and "news.google.com" not in url:
            urls.append(url)
        else:
            urls.append(None)
    return urls


def parse_batch_response(body):
    """Erste Verlags-URL (Einzelauflösung, wie gehabt)."""
    for url in parse_batch_responses(body):
        if url:
            return url
    return None


def _rate_limited(response):
    return response.status == 429 or "google.com/sorry" in (response.url or "")


def cooling_down():
    """Nach einer Google-Sperre 30 Minuten Pause (gilt pro Prozess)."""
    return time.time() < _cooldown_until[0]


def _signature(article):
    """Zeitstempel + Signatur der Artikelseite, ``RATE_LIMITED`` oder None."""
    page = http.fetch("https://news.google.com/rss/articles/%s" % article, timeout=12,
                      max_bytes=1500000, headers={"Cookie": CONSENT_COOKIE}, mobile=True)
    if _rate_limited(page):
        _cooldown_until[0] = time.time() + _COOLDOWN_SECONDS
        return RATE_LIMITED
    if not page.ok:
        return None
    text = page.text()
    ts, sg = _TS.search(text), _SG.search(text)
    return (ts.group(1), sg.group(1)) if ts and sg else None


def _execute(entries):
    """batchexecute für [(Artikel-ID, ts, sg)] → URLs in Anfrage-Reihenfolge;
    ``RATE_LIMITED`` bei Sperre, ``[]`` bei anderen Fehlern."""
    body = urlencode({"f.req": batch_request(entries)}).encode("utf-8")
    answer = http.fetch(BATCH_URL, timeout=15, max_bytes=262144, data=body, mobile=True,
                        headers={"Cookie": CONSENT_COOKIE,
                                 "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"})
    if _rate_limited(answer):
        _cooldown_until[0] = time.time() + _COOLDOWN_SECONDS
        return RATE_LIMITED
    if not answer.ok:
        return []
    return parse_batch_responses(answer.text())


def resolve(url):
    """Verlags-URL, ``RATE_LIMITED`` oder None (nicht auflösbar)."""
    local = decode_local(url)
    if local:
        return local
    if cooling_down():
        return RATE_LIMITED
    article = article_id(url)
    if not article:
        return None
    signature = _signature(article)
    if signature == RATE_LIMITED:
        return RATE_LIMITED
    if not signature:
        return None
    urls = _execute([(article, signature[0], signature[1])])
    if urls == RATE_LIMITED:
        return RATE_LIMITED
    return urls[0] if urls else None


def resolve_many(articles, spacing=1.0, should_stop=None):
    """Mehrere Google-Links auf einmal: je Artikel einmal die Signaturseite holen
    (mit Abstand – Google drosselt), danach EIN batchexecute für alle zusammen.
    Halbiert die Zahl der Google-Anfragen gegenüber Einzelauflösung.

    Gibt {Link: Verlags-URL oder None} nur für tatsächlich versuchte Links zurück;
    Links nach einer Sperre oder einem Abbruch fehlen (nächste Runde)."""
    results = {}
    pending = []
    for article in articles:
        if should_stop and should_stop():
            break
        link = article["link"]
        local = decode_local(link)
        if local:
            results[link] = local
            continue
        if cooling_down():
            break
        raw = article_id(link)
        if not raw:
            results[link] = None
            continue
        signature = _signature(raw)
        if signature == RATE_LIMITED:
            break
        results[link] = None
        if signature:
            pending.append((raw, link, signature[0], signature[1]))
        time.sleep(spacing)
    if pending and not cooling_down() and not (should_stop and should_stop()):
        urls = _execute([(raw, ts, sg) for raw, link, ts, sg in pending])
        if urls != RATE_LIMITED:
            for (_, link, _, _), url in zip(pending, urls):
                if url:
                    results[link] = url
    return results
