# -*- coding: utf-8 -*-
"""Fenster-XML passend zum Bildschirm – Startseite und Lese-Fenster.

Kodi legt Add-on-Fenster in 1920×1080 Einheiten an und streckt sie auf jede Breite;
Schriften verzerrt Kodi dabei nicht (im Kartarium-Plugin auf Geräten erprobt). Deshalb
entsteht das XML beim Öffnen für das echte Seitenverhältnis: feste Formen (Kacheln,
Bilder, Knöpfe, Schein) rechnen waagerecht mit dem Faktor ``f``, Flächen füllen die
Breite. Breitere Bildschirme (21:9, 32:9) zeigen mehr Kacheln statt verzerrter, und jede
Reihe zeigt nur ganze Kacheln. Ab 1440 Zeilen kommen die hochauflösenden Hintergründe.

Texturen werden mit absolutem Pfad eingetragen (Medienordner des Add-ons); das XML
liegt im Profilordner (Kodi sucht es unter <Pfad>/resources/skins/Default/1080i/)."""
import io
import os
from xml.sax.saxutils import escape

W, H = 1920, 1080
ACCENT, TEXT, SOFT, MUTED, GOLD = "FF2DE1C2", "FFF0FBF8", "FFE1ECE9", "FF9AA9A6", "FFFFC24B"
PILL_FACTOR = {"16x9": 1.0, "21x9": 0.75, "32x9": 0.5}  # wie tools/make_art.py
ROWS = 6
MENU = [(301, "menu_all"), (302, "menu_positive"), (303, "menu_neutral"), (304, "menu_negative"),
        (305, "menu_topics"), (306, "menu_region"), (307, "menu_saved")]
ICON_BUTTONS = [(308, "search"), (309, "refresh"), (311, "meow"), (310, "settings")]
MEOW_ON = "String.IsEqual(Window.Property(meow),on)"
# Kachelgröße: Listen-ID-Basis, Gruppen-ID-Basis, Bild B×H, Kachel-Abstand, Reihenhöhe, Bedingung
SIZES = {
    "large": (600, 590, 400, 225, 430, 400, "!String.IsEqual(Window.Property(cards),small)"),
    "small": (700, 690, 300, 169, 325, 344, "String.IsEqual(Window.Property(cards),small)"),
}
M = 24  # Innenabstand der Kacheln: Listen beschneiden am Rand, Schein und Zoom brauchen Platz
# Hoch/Runter fest im XML: Highlight → große Reihen → kleine Reihen. Leere Listen kann Kodi nicht
# fokussieren und folgt dann deren eigener Navigation weiter (CGUIWindow::OnMove) – so gibt es keine
# Lücken. Nicht per Python (controlUp/controlDown): diese Aufrufe greifen direkt auf das Steuerelement
# zu, und nach einem Skin-Wechsel zeigen die alten Control-Objekte ins Leere → Kodi stürzt ab.
NAV_CHAIN = [600] + [600 + row for row in range(1, 7)] + [700 + row for row in range(1, 7)]
NAV_TOP = 301
READER_SCALES = (("90", 32, 35, 0.90), ("100", 30, 31, 1.0), ("115", 33, 36, 1.15), ("130", 34, 37, 1.30))
# Kodi verkleinert Texturen ohne Mipmaps (nur bilinear): ab etwa Faktor 1,5 fransen Kanten und
# feine Linien (Schnurrhaare) aus. Kleine Grafiken gibt es deshalb fertig in diesen Pixelhöhen
# (<name>_<höhe>.png, tools/make_art.py); größer als die letzte Stufe → Originaldatei <name>.png.
LADDERS = {
    "logo": (100, 130, 170, 220, 290, 380),
    "wordmark": (72, 96),
    "icon_search": (64, 84, 128),
    "icon_refresh": (64, 84, 128),
    "icon_settings": (64, 84, 128),
    "icon_meow": (64, 84, 128),
    "icon_meow_off": (64, 84, 128),
    "ring": (68, 92, 136),
}
LOGO_RATIO = 523 / 507.0  # Breite/Höhe des Katzenlogos
WORDMARK_RATIO = 695 / 147.0  # Breite/Höhe des Schriftzugs „Catnewz“


class Raster(object):
    def __init__(self, width, height):
        width, height = max(1, int(width or W)), max(1, int(height or H))
        self.f = (float(W) / H) * height / width
        ratio = float(width) / height
        self.aspect = "32x9" if ratio > 3.0 else "21x9" if ratio > 2.05 else "16x9"
        self.hd = height >= 1440
        self.scale = height / float(H)  # Bildschirmpixel je Einheit (senkrecht wie waagerecht mit f)

    def x(self, value):
        return int(round(value * self.f))


class Builder(object):
    def __init__(self, raster, media):
        self.r = raster
        self.media = media

    def x(self, value):
        return self.r.x(value)

    def tex(self, name):
        return escape(os.path.join(self.media, name))

    def background(self):
        return self.tex("bg_%s%s.png" % (self.r.aspect, "_hd" if self.r.hd else ""))

    def sized(self, name, units):
        """Vorberechnete Stufe für <units> Einheiten Höhe: kleinste, die nicht hochskaliert wird."""
        pixels = units * self.r.scale
        for height in LADDERS.get(name, ()):
            if height >= pixels * 0.97:
                return self.tex("%s_%d.png" % (name, height))
        return self.tex("%s.png" % name)

    def logo(self, left, top, width, height, extra="", attrs=""):
        """Katzenlogo (Seitenverhältnis bleibt) in der Stufe für die tatsächlich gezeigte Höhe."""
        shown = min(height, width / self.r.f / LOGO_RATIO)
        return self.image(left, top, width, height, self.sized("logo", shown),
                          extra="<aspectratio>keep</aspectratio>" + extra, attrs=attrs)

    # ------------------------------------------------------------ Bausteine

    def image(self, left, top, width, height, texture, extra="", visible=None, attrs=""):
        return ('<control type="image"><left>%d</left><top>%d</top><width>%d</width><height>%d</height>'
                '<texture%s>%s</texture>%s%s</control>\n' % (
                    left, top, width, height, attrs, texture, extra,
                    "<visible>%s</visible>" % visible if visible else ""))

    def label(self, left, top, width, height, text, font="font13", color=TEXT, align="left", extra="",
              visible=None, kind="label"):
        return ('<control type="%s"><left>%d</left><top>%d</top><width>%d</width><height>%d</height>'
                '<font>%s</font><textcolor>%s</textcolor><align>%s</align>%s<label>%s</label>%s</control>\n' % (
                    kind, left, top, width, height, font, color, align, extra, text,
                    "<visible>%s</visible>" % visible if visible else ""))

    # ------------------------------------------------------------ Startseite

    def card(self, size, list_id, focused):
        _, _, img_w, img_h, _, _, _ = SIZES[size]
        w, h = self.x(img_w), img_h
        title_top = h + 10
        parts = []
        if focused:
            parts.append(self.image(-self.x(20), -20, w + self.x(40), h + 40, self.tex("card_glow.png"),
                                    visible="Control.HasFocus(%d)" % list_id))
        parts.append(self.image(0, 0, w, h, self.tex("white.png"),
                                attrs=' colordiffuse="E60B141C" diffuse="%s"' % self.tex("card_mask.png")))
        logo = int(h * 0.6)
        parts.append(self.logo((w - self.x(logo)) // 2, h // 5, self.x(logo), logo, attrs=' colordiffuse="99FFFFFF"'))
        parts.append(self.image(0, 0, w, h, "$INFO[ListItem.Art(thumb)]",
                                extra='<aspectratio scalediffuse="false">scale</aspectratio>',
                                attrs=' diffuse="%s" background="true"' % self.tex("card_mask.png")))
        if focused:
            parts.append(self.image(0, 0, w, h, self.tex("card_frame.png"),
                                    visible="Control.HasFocus(%d)" % list_id))
        bx = int(round(16 * PILL_FACTOR[self.r.aspect]))
        parts.append(self.image(self.x(12), 12, self.x(190), 34, self.tex("pill_%s.png" % self.r.aspect),
                                visible="!String.IsEmpty(ListItem.Property(badge))",
                                attrs=' border="%d,16,%d,16" colordiffuse="E6040A10"' % (bx, bx)))
        parts.append(self.label(self.x(22), 12, self.x(170), 34, "$INFO[ListItem.Property(badge)]", font="font12",
                                align="center", extra="<aligny>center</aligny><scroll>false</scroll>"))
        parts.append(self.label(self.x(4), title_top, w - self.x(8), 62, "$INFO[ListItem.Label]", font="font12",
                                color=TEXT if focused else SOFT, kind="textbox"))
        parts.append(self.label(self.x(4), title_top + 64, w - self.x(8), 30, "$INFO[ListItem.Label2]",
                                font="font12", color=MUTED))
        zoom = ('<animation effect="zoom" start="100" end="105" center="%d,%d" time="160" tween="sine" '
                'easing="out" condition="Control.HasFocus(%d)">Conditional</animation>' % (w // 2, h // 2, list_id)
                if focused else "")
        tag = "focusedlayout" if focused else "itemlayout"
        return ('<%s width="%d" height="%d"><control type="group"><left>%d</left><top>%d</top>%s\n%s'
                '</control></%s>\n' % (tag, self.x(SIZES[size][4]), M + title_top + 100, self.x(M), M, zoom,
                                       "".join(parts), tag))

    @staticmethod
    def navigation(list_id):
        index = NAV_CHAIN.index(list_id)
        up = NAV_CHAIN[index - 1] if index else NAV_TOP
        down = NAV_CHAIN[index + 1] if index + 1 < len(NAV_CHAIN) else list_id
        return "<onup>%d</onup><ondown>%d</ondown>" % (up, down)

    def visible_cards(self, size):
        """So viele ganze Kacheln, wie in die Breite passen (keine halb abgeschnittenen)."""
        step = self.x(SIZES[size][4])
        content = W - 2 * self.x(64)
        gap = step - self.x(SIZES[size][2])
        return max(1, (content + gap) // step)

    def row(self, size, row):
        list_base, group_base, img_w, img_h, step, height, condition = SIZES[size]
        list_id, group_id = list_base + row, group_base + row
        count = self.visible_cards(size)
        width = count * self.x(step) + self.x(18)
        return ('<control type="group" id="%(gid)d"><width>%(W)d</width><height>%(h)d</height>'
                '<visible>Integer.IsGreater(Container(%(lid)d).NumItems,0) + %(cond)s</visible>\n'
                '%(title)s'
                '<control type="list" id="%(lid)d"><left>%(ll)d</left><top>%(lt)d</top><width>%(lw)d</width>'
                '<height>%(lh)d</height><orientation>horizontal</orientation>%(nav)s'
                '<scrolltime tween="sine" easing="out">220</scrolltime><preloaditems>2</preloaditems>\n'
                '%(item)s%(focus)s</control></control>\n') % {
            "gid": group_id, "W": W, "h": height, "lid": list_id, "cond": condition,
            "nav": self.navigation(list_id),
            "title": self.label(self.x(64), 0, W - 2 * self.x(64), 44,
                                "[B]$INFO[Window.Property(row%d_title)][/B]  [COLOR %s]$INFO[Window.Property(row%d_info)][/COLOR]"
                                % (row, MUTED, row)),
            "ll": self.x(64) - self.x(M), "lt": 46 - M, "lw": width, "lh": height - 46 + M,
            "item": self.card(size, list_id, False), "focus": self.card(size, list_id, True)}

    def hero(self):
        iw, ih = self.x(720), 405
        text_left = self.x(770)
        text_width = W - 2 * self.x(64) - text_left
        logo = 300

        def item(focused):
            parts = [
                self.image(0, 10, iw, ih, self.tex("white.png"),
                           attrs=' colordiffuse="E60B141C" diffuse="%s"' % self.tex("hero_mask.png")),
                self.logo((iw - self.x(260)) // 2, 62, self.x(260), logo),
                self.image(0, 10, iw, ih, "$INFO[ListItem.Art(fanart)]",
                           extra='<aspectratio scalediffuse="false">scale</aspectratio>',
                           attrs=' diffuse="%s" background="true"' % self.tex("hero_mask.png")),
            ]
            if focused:
                parts.append(self.image(0, 10, iw, ih, self.tex("hero_frame.png"), visible="Control.HasFocus(600)"))
            parts += [
                self.label(text_left, 16, text_width, 40, "$INFO[Window.Property(hero_badge)]", color=GOLD),
                self.label(text_left, 66, int(text_width / 1.25), 132, "[B]$INFO[ListItem.Label][/B]", kind="textbox",
                           extra='<animation effect="zoom" start="125" end="125" center="%d,66" time="0" '
                                 'condition="true">Conditional</animation>' % text_left),
                self.label(text_left, 246, text_width, 124, "$INFO[ListItem.Plot]", font="font12", color=SOFT,
                           kind="textbox"),
                self.label(text_left, 378, text_width, 36, "$INFO[ListItem.Label2]", font="font12", color=ACCENT),
            ]
            tag = "focusedlayout" if focused else "itemlayout"
            return '<%s width="%d" height="430">\n%s</%s>\n' % (tag, W - 2 * self.x(64), "".join(parts), tag)

        return ('<control type="group" id="590"><width>%d</width><height>440</height>'
                '<visible>Integer.IsGreater(Container(600).NumItems,0)</visible>\n'
                '<control type="list" id="600"><left>%d</left><top>0</top><width>%d</width><height>430</height>'
                '<orientation>horizontal</orientation>%s\n%s%s</control></control>\n') % (
            W, self.x(64), W - 2 * self.x(64), self.navigation(600), item(False), item(True))

    def menu(self):
        aspect = self.r.aspect
        bx = int(round(30 * PILL_FACTOR[aspect]))
        icon_size, icon_step = self.x(62), self.x(78)
        icons_left = W - self.x(64) - len(ICON_BUTTONS) * icon_step + (icon_step - icon_size)
        buttons = []
        for index, (button_id, prop) in enumerate(MENU):
            right = "<onright>%d</onright>" % ICON_BUTTONS[0][0] if index == len(MENU) - 1 else ""
            buttons.append(
                '<control type="button" id="%d"><width>auto</width><height>58</height><font>font13</font>'
                '<textoffsetx>%d</textoffsetx><aligny>center</aligny><textcolor>%s</textcolor>'
                '<focusedcolor>%s</focusedcolor>'
                '<texturefocus border="%d,30,%d,30">%s</texturefocus>'
                '<texturenofocus border="%d,30,%d,30" colordiffuse="1FFFFFFF">%s</texturenofocus>'
                '<label>$INFO[Window.Property(%s)]</label><ondown>500</ondown>%s'
                '<visible>!String.IsEmpty(Window.Property(%s))</visible></control>\n' % (
                    button_id, self.x(24), SOFT, TEXT, bx, bx, self.tex("pill_focus_%s.png" % aspect), bx, bx,
                    self.tex("pill_%s.png" % aspect), prop, right, prop))
        icons = []
        for index, (button_id, name) in enumerate(ICON_BUTTONS):
            left = icons_left + index * icon_step
            left_id = ICON_BUTTONS[index - 1][0] if index else MENU[-1][0]
            right_id = ICON_BUTTONS[index + 1][0] if index + 1 < len(ICON_BUTTONS) else button_id
            texture = self.sized("icon_%s" % name, 62)
            textures = ('<texturefocus>%s</texturefocus><texturenofocus colordiffuse="CCFFFFFF">%s</texturenofocus>'
                        % (texture, texture)) if name != "meow" else ""
            icons.append(
                '<control type="button" id="%d"><left>%d</left><top>148</top><width>%d</width><height>62</height>'
                '%s<label></label><onleft>%d</onleft><onright>%d</onright><ondown>500</ondown></control>\n' % (
                    button_id, left, icon_size, textures, left_id, right_id))
            if name == "meow":  # Schalter: Lautsprecher an (Teal) / aus (grau) wie in der App-Leiste
                dim = ('<animation effect="fade" start="100" end="80" time="0" condition="!Control.HasFocus(%d)">'
                       'Conditional</animation>' % button_id)
                icons.append(self.image(left, 148, icon_size, 62, texture, extra=dim, visible=MEOW_ON))
                icons.append(self.image(left, 148, icon_size, 62, self.sized("icon_meow_off", 62), extra=dim,
                                        visible="!" + MEOW_ON))
            icons.append(self.image(left - self.x(3), 145, self.x(68), 68, self.sized("ring", 68),
                                    visible="Control.HasFocus(%d)" % button_id))
        width = icons_left - self.x(20) - self.x(64)
        return ('<control type="grouplist" id="300"><left>%d</left><top>150</top><width>%d</width><height>58</height>'
                '<orientation>horizontal</orientation><itemgap>%d</itemgap><ondown>500</ondown>'
                '<onright>%d</onright>\n%s</control>\n%s') % (
            self.x(64), width, self.x(12), ICON_BUTTONS[0][0], "".join(buttons), "".join(icons))

    def home(self):
        right = W - self.x(64)
        rows = "".join(self.row(size, row) for size in ("large", "small") for row in range(1, ROWS + 1))
        header = (
            self.logo(self.x(58), 26, self.x(100), 97)
            + self.image(self.x(172), 32, self.x(330), 86, self.sized("wordmark", min(86, 330 / WORDMARK_RATIO)),
                         extra='<aspectratio align="left">keep</aspectratio>')
            + self.label(self.x(176), 104, self.x(900), 36, "$INFO[Window.Property(tagline)]", font="font12",
                         color=MUTED)
            + self.label(right - self.x(700), 30, self.x(700), 46, "[B]$INFO[System.Time][/B]", align="right")
            + self.label(right - self.x(700), 72, self.x(700), 36, "$INFO[System.Date]", font="font12", color=SOFT,
                         align="right")
            + self.label(right - self.x(1000), 104, self.x(1000), 36,
                         "$INFO[Window.Property(updated)]$INFO[Window.Property(hint),  ·  ]", font="font12",
                         color=MUTED, align="right", visible="String.IsEmpty(Window.Property(busy))")
            + self.label(right - self.x(1000), 104, self.x(1000), 36, "$INFO[Window.Property(busy)]", font="font12",
                         color=ACCENT, align="right", visible="!String.IsEmpty(Window.Property(busy))",
                         extra='<animation effect="fade" start="100" end="35" time="700" pulse="true" '
                               'condition="true">Conditional</animation>'))
        return (
            '<?xml version="1.0" encoding="UTF-8"?>\n'
            '<!-- Catnewz-Startseite – erzeugt von catnewz/layout.py für %s (f=%.3f) -->\n'
            '<window><defaultcontrol always="true">500</defaultcontrol>\n'
            '<animation effect="fade" start="0" end="100" time="260">WindowOpen</animation>\n'
            '<animation effect="fade" start="100" end="0" time="180">WindowClose</animation>\n<controls>\n'
            '%s%s%s%s'
            '<control type="grouplist" id="500"><left>0</left><top>232</top><width>%d</width><height>848</height>'
            '<orientation>vertical</orientation><itemgap>16</itemgap>'
            '<scrolltime tween="sine" easing="out">260</scrolltime><onup>300</onup>\n%s%s</control>\n'
            '</controls></window>\n') % (
            self.r.aspect, self.r.f, self.moving_background(), header, self.menu(), "", W, self.hero(), rows)

    def moving_background(self, dim="4D040A10"):
        """Hologlas-Hintergrund, langsam bewegt (wie in der App)."""
        return (self.image(-self.x(96), -54, W + 2 * self.x(96), H + 108, self.background(),
                           extra='<animation effect="zoom" start="100" end="106" center="auto" time="24000" '
                                 'pulse="true" condition="true">Conditional</animation>'
                                 '<animation effect="slide" start="-%d,-12" end="%d,12" time="17000" pulse="true" '
                                 'condition="true">Conditional</animation>' % (self.x(24), self.x(24)))
                + self.image(0, 0, W, H, self.tex("white.png"), attrs=' colordiffuse="%s"' % dim))

    # ------------------------------------------------------------ Lese-Fenster

    def reader(self):
        right = W - self.x(100)
        col = self.x(830)
        body_w = right - col - self.x(30)
        hero_l, hero_w = self.x(84), self.x(672)
        theme = ("!String.IsEqual(Window.Property(theme),light) + !String.IsEqual(Window.Property(theme),sepia)",
                 "String.IsEqual(Window.Property(theme),light)", "String.IsEqual(Window.Property(theme),sepia)")
        parts = [self.image(0, 0, W, H, self.background()),
                 self.image(0, 0, W, H, self.tex("white.png"), attrs=' colordiffuse="D9040A10"', visible=theme[0]),
                 self.image(0, 0, W, H, self.tex("white.png"), attrs=' colordiffuse="F5EEF4F2"', visible=theme[1]),
                 self.image(0, 0, W, H, self.tex("white.png"), attrs=' colordiffuse="F5F1E6CF"', visible=theme[2]),
                 self.image(hero_l, 114, hero_w, 384, self.tex("white.png"),
                            attrs=' colordiffuse="FF0B141C" diffuse="%s"' % self.tex("mask_hero.png")),
                 self.logo(hero_l + (hero_w - self.x(260)) // 2, 156, self.x(260), 300),
                 self.image(hero_l, 114, hero_w, 384, "$INFO[Window.Property(image)]",
                            extra='<aspectratio scalediffuse="false">scale</aspectratio>',
                            attrs=' diffuse="%s" background="true"' % self.tex("mask_hero.png"),
                            visible="!String.IsEmpty(Window.Property(image))"),
                 self.image(hero_l, 114, hero_w, 384, self.tex("frame_hero.png")),
                 self.label(self.x(90), 530, self.x(660), 44, "$INFO[Window.Property(mood)]"),
                 self.label(self.x(90), 580, self.x(660), 44, "$INFO[Window.Property(meta)]", color=ACCENT),
                 self.label(self.x(90), 630, self.x(660), 100, "$INFO[Window.Property(badges)]", color=GOLD,
                            kind="textbox"),
                 self.label(self.x(90), 940, self.x(660), 40, "$INFO[Window.Property(original)]", color=MUTED),
                 self.label(self.x(90), 985, self.x(700), 80, "$INFO[Window.Property(hint)]", color="FF6F7E7B",
                            kind="textbox"),
                 self.label(col, 108, right - col, 176, "[B]$INFO[Window.Property(title)][/B]", kind="textbox"),
                 self.image(col, 300, right - col, 4, self.tex("iris.png"))]
        for scale, text_id, bar_id, zoom in READER_SCALES:
            if scale == "100":
                visible = ("String.IsEmpty(Window.Property(fontscale)) | "
                           "String.IsEqual(Window.Property(fontscale),100)")
            else:
                visible = "String.IsEqual(Window.Property(fontscale),%s)" % scale
            animation = ('<animation effect="zoom" start="%d" end="%d" center="%d,330" time="0" condition="true">'
                         'Conditional</animation>' % (zoom * 100, zoom * 100, col)) if zoom != 1.0 else ""
            parts.append(
                '<control type="textbox" id="%d"><left>%d</left><top>330</top><width>%d</width><height>%d</height>'
                '<font>font13</font><textcolor>%s</textcolor><pagecontrol>%d</pagecontrol><autoscroll>false</autoscroll>'
                '<label>$INFO[Window.Property(body)]</label>%s<visible>%s</visible></control>\n' % (
                    text_id, col, int(body_w / zoom), int(700 / zoom), SOFT, bar_id, animation, visible))
            parts.append(
                '<control type="scrollbar" id="%d"><left>%d</left><top>330</top><width>%d</width><height>700</height>'
                '<texturesliderbackground colordiffuse="22888888">%s</texturesliderbackground>'
                '<texturesliderbar colordiffuse="882DE1C2">%s</texturesliderbar>'
                '<texturesliderbarfocus colordiffuse="FF2DE1C2">%s</texturesliderbarfocus>'
                '<orientation>vertical</orientation><showonepage>false</showonepage>'
                '<onleft>%d</onleft><onright>%d</onright><visible>%s</visible></control>\n' % (
                    bar_id, right + self.x(10), max(4, self.x(10)), self.tex("white.png"), self.tex("white.png"),
                    self.tex("white.png"), bar_id, bar_id, visible))
        return ('<?xml version="1.0" encoding="UTF-8"?>\n'
                '<!-- Catnewz-Lese-Fenster – erzeugt von catnewz/layout.py für %s (f=%.3f) -->\n'
                '<window><defaultcontrol always="true">31</defaultcontrol>\n'
                '<animation effect="fade" start="0" end="100" time="220">WindowOpen</animation>\n'
                '<animation effect="fade" start="100" end="0" time="160">WindowClose</animation>\n'
                '<controls>\n%s</controls></window>\n') % (self.r.aspect, self.r.f, "".join(parts))


def media_path(addon_path):
    return os.path.join(addon_path, "resources", "skins", "Default", "media", "catnewz")


def write(profile, name, xml):
    """XML in den Profilordner legen; Rückgabe: Pfad für WindowXML (scriptPath)."""
    base = os.path.join(profile, "layout")
    folder = os.path.join(base, "resources", "skins", "Default", "1080i")
    if not os.path.isdir(folder):
        os.makedirs(folder)
    with io.open(os.path.join(folder, name), "w", encoding="utf-8") as handle:
        handle.write(xml)
    return base


def build(kind, width, height, addon_path, profile):
    """kind: "home" oder "reader" → (scriptPath, Dateiname) für WindowXML/WindowXMLDialog."""
    builder = Builder(Raster(width, height), media_path(addon_path))
    name = "script-catnewz-%s.xml" % kind
    return write(profile, name, builder.home() if kind == "home" else builder.reader()), name
