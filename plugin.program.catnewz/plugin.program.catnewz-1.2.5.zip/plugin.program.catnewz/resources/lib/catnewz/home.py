# -*- coding: utf-8 -*-
"""Catnewz-Startseite: eigene Oberfläche beim Öffnen des Add-ons (wie die App).

Kopf mit Logo und Uhrzeit, Menü (Alle, Stimmungen, Themen, Region, Gemerkt, Suchen,
Aktualisieren, Einstellungen), „Gute Nachricht des Tages“ und bis zu sechs Reihen
mit Kacheln – welche Reihen in welcher Reihenfolge, legt der Nutzer fest
(Einstellungen › Startseite oder direkt hier über die Menü-Taste).

Die Listen des Plugins (plugin://…) bleiben unverändert – für Widgets, Video-Add-ons
und „Alle anzeigen“. Das Layout entsteht beim Öffnen passend zum Bildschirm (layout.py)."""
import threading
import time

import xbmc
import xbmcgui

from catnewz import images, kodi, layout, news
from catnewz.kodi import L
from catnewz.plugin import MENU_ICONS, MOODS, S, TOPICS, Plugin

BASE = "plugin://plugin.program.catnewz/"
ROW_TYPES = ("new", "POSITIVE", "NEUTRAL", "NEGATIVE", "ADOPTION", "RESCUE", "SHELTER", "FUNNY", "KNOWLEDGE",
             "local", "saved", "history", "off")
DEFAULT_ROWS = ("new", "POSITIVE", "ADOPTION", "local", "FUNNY", "saved")
ROW_COUNT = 6
ITEMS_PER_ROW = 20
HERO_LIST = 600
LIST_BASE = {"large": 600, "small": 700}
MENU = {301: "all", 302: "POSITIVE", 303: "NEUTRAL", 304: "NEGATIVE", 305: "topics", 306: "local",
        307: "saved", 308: "search", 309: "refresh", 310: "settings", 311: "meow"}
CONTEXT_ACTIONS = (117, 11)       # Kontextmenü, Info
CLOSE_ACTIONS = (10, 92)          # PreviousMenu, NavBack
H = {"tagline": 30200, "new_for_you": 30201, "region": 30202, "off": 30203, "hero": 30204, "show_all": 30205,
     "busy": 30206, "row_change": 30207, "row_remove": 30208, "hint": 30209, "read": 30219,
     "badge_adoption": 30230, "badge_local": 30231, "meow_on": 30234, "meow_off": 30235}


def row_label(kind, region=""):
    if kind == "new":
        return L(H["new_for_you"])
    if kind == "local":
        return region or L(H["region"])
    if kind == "off":
        return L(H["off"])
    return L(S[{"saved": "saved", "history": "history"}.get(kind, kind)])


def row_params(kind):
    """plugin://-Parameter für „Alle anzeigen“."""
    if kind in MOODS:
        return {"mood": kind}
    if kind in TOPICS:
        return {"topic": kind}
    return {"local": {"local": "1"}, "saved": {"saved": "1"}, "history": {"history": "1"}}.get(kind, {})


class Home(object):
    """Daten der Startseite (ohne Fenster – testbar)."""

    def __init__(self):
        self.plugin = Plugin([BASE, "-1", ""])
        self.store = self.plugin.store
        self.config = self.plugin.config

    def rows(self):
        kinds = []
        for slot in range(1, ROW_COUNT + 1):
            kind = kodi.setting_str("home_row%d" % slot, DEFAULT_ROWS[slot - 1])
            kinds.append(kind if kind in ROW_TYPES else "off")
        return kinds

    def articles(self, kind):
        store, config = self.store, self.config
        if kind == "new":
            config.sort = news.SORT_NEWEST
            return news.visible(store, config)
        if kind in MOODS:
            return news.visible(store, config, mood=kind)
        if kind in TOPICS:
            return news.visible(store, config, topic=kind)
        if kind == "local":
            return news.visible(store, config, local=True) if config.region else []
        if kind == "saved":
            return news.sort_articles(list(store.user["bookmarks"].values()), news.SORT_PUBLISHED)
        if kind == "history":
            read = sorted(store.user["read"].items(), key=lambda kv: kv[1], reverse=True)
            return [a for a in (store.article(aid) for aid, _ in read) if a]
        return []

    def hero(self):
        """Gute Nachricht des Tages: beste positive Meldung der letzten 48 Stunden, mit Bild bevorzugt."""
        since = time.time() - 2 * 86400
        positive = [a for a in news.visible(self.store, self.config, mood="POSITIVE")
                    if a.get("published", 0) >= since]
        if not positive:
            return None
        return sorted(positive, key=lambda a: (bool(a.get("image")), a.get("score", 0), a.get("published", 0)),
                      reverse=True)[0]

    def counts(self):
        visible = news.visible(self.store, self.config)
        counts = {"all": len(visible), "local": sum(1 for a in visible if a.get("local")),
                  "saved": len(self.store.user["bookmarks"])}
        for mood in MOODS:
            counts[mood] = sum(1 for a in visible if self.store.mood(a) == mood)
        boundary = self.store.user.get("visit_boundary", 0)
        counts["new"] = sum(1 for a in visible if boundary and a.get("fetched", 0) > boundary)
        return counts

    def is_stale(self):
        data = self.store.data
        age = time.time() - data.get("last_refresh", 0)
        return (not data["articles"] or age > max(5, kodi.setting_int("cache_minutes", 30)) * 60
                or data.get("language") != self.config.language or data.get("region", "") != self.config.region)


class HomeWindow(xbmcgui.WindowXML):
    home = None
    slots = None          # Listen-ID → Reihen-Art
    first_fill = True
    refreshing = False
    hd = False

    # ------------------------------------------------------------ Aufbau

    def onInit(self):
        self.fill()
        if self.first_fill:
            self.first_fill = False
            self.home.store.touch_visit()
            if self.home.is_stale():
                self.refresh_in_background()

    def card_size(self):
        return "small" if kodi.setting_str("home_cards", "large") == "small" else "large"

    def fill(self, keep_focus=False):
        home = self.home
        counts = home.counts()
        region = home.config.region
        muted = kodi.MUTED
        self.setProperty("tagline", L(H["tagline"]))
        self.setProperty("hint", L(H["hint"]))
        self.setProperty("updated", L(S["updated"]) % home.plugin.when(home.store.data.get("last_refresh", 0)))
        self.setProperty("cards", "small" if self.card_size() == "small" else "")
        self.setProperty("hero_badge", L(H["hero"]))
        self.setProperty("meow", "on" if kodi.setting_bool("meow_sound", False) else "")
        self.setProperty("menu_all", "%s  [COLOR %s]%d[/COLOR]" % (L(S["all"]), muted, counts["all"]))
        for button, mood in ((302, "POSITIVE"), (303, "NEUTRAL"), (304, "NEGATIVE")):
            self.setProperty(MENU_PROPS[button], "[COLOR %s]•[/COLOR]  %s  [COLOR %s]%d[/COLOR]" % (
                kodi.MOOD_COLORS[mood], L(S[mood]), muted, counts[mood]))
        self.setProperty("menu_topics", L(S["topics"]))
        self.setProperty("menu_region", "%s  [COLOR %s]%d[/COLOR]" % (region, muted, counts["local"]) if region else "")
        self.setProperty("menu_saved", "%s  [COLOR %s]%d[/COLOR]" % (L(S["saved"]), muted, counts["saved"]))
        self.setProperty("menu_search", L(S["search"]))
        self.setProperty("menu_refresh", L(S["refresh"]))
        self.setProperty("menu_settings", L(S["settings"]))

        boundary = home.store.user.get("visit_boundary", 0)
        hero_list = self.getControl(HERO_LIST)
        hero_list.reset()
        hero = home.hero() if kodi.setting_bool("home_hero", True) else None
        if hero:
            hero_list.addItem(self.hero_item(hero))

        size = self.card_size()
        self.slots = {}
        filled = 0
        for base in LIST_BASE.values():  # beide Größen leeren, nur eine wird gezeigt
            for slot in range(1, ROW_COUNT + 1):
                self.getControl(base + slot).reset()
                self.setProperty("row%d_title" % slot, "")
                self.setProperty("row%d_info" % slot, "")
        for slot, kind in enumerate(home.rows(), 1):
            if kind == "off":
                continue
            articles = home.articles(kind)
            if not articles:
                continue
            filled += 1
            list_id = LIST_BASE[size] + filled
            self.slots[list_id] = (slot, kind)
            info = L(S["n_new"]) % counts["new"] if kind == "new" and counts["new"] else str(len(articles))
            self.setProperty("row%d_title" % filled, row_label(kind, region))
            self.setProperty("row%d_info" % filled, info)
            items = [self.card_item(a, boundary) for a in articles[:ITEMS_PER_ROW]]
            items.append(self.show_all_item(kind, len(articles)))
            self.getControl(list_id).addItems(items)
        # Hoch/Runter steht fest im XML (layout.NAV_CHAIN). Hier nur Kodi-Nachrichten (leeren, füllen,
        # Fokus) – die bleiben auch nach einem Skin-Wechsel sicher, wenn Kodi das Fenster neu aufbaut.
        if not keep_focus:
            self.focus_first([HERO_LIST] if hero else sorted(self.slots))

    def focus_first(self, ids):
        """Fokus erst setzen, wenn das Ziel sichtbar ist (Sichtbarkeit greift im nächsten Bild)."""
        target = ids[0] if ids else 301
        for _ in range(25):
            try:
                self.setFocusId(target)
                if self.getFocusId() == target:
                    return
            except RuntimeError:
                pass
            xbmc.sleep(20)

    # ------------------------------------------------------------ Kacheln

    def card_label(self, article, boundary):
        store = self.home.store
        mood = store.mood(article)
        read = store.is_read(article["id"])
        prefix = "[COLOR %s]•[/COLOR] " % kodi.MOOD_COLORS.get(mood, kodi.GOLD)
        if boundary and article.get("fetched", 0) > boundary and not read:
            prefix += "[COLOR %s][B]%s[/B][/COLOR] " % (kodi.ACCENT, L(S["new"]))
        title = "[COLOR %s]%s[/COLOR]" % (kodi.MUTED, article["title"]) if read else article["title"]
        return prefix + title

    def card_item(self, article, boundary):
        mood = self.home.store.mood(article)
        item = xbmcgui.ListItem(label=self.card_label(article, boundary),
                                label2="%s · %s" % (article.get("source", ""),
                                                    self.home.plugin.when(article.get("published"))),
                                offscreen=True)
        width, height = (800, 450) if self.hd else (640, 360)
        thumb = images.thumb(article, width, height) or kodi.placeholder(mood, card=True)
        item.setArt({"thumb": thumb, "fanart": self.home.plugin.backdrop})
        item.setProperty("id", article["id"])
        item.setProperty("badge", self.badge(article))
        return item

    def badge(self, article):
        if article.get("topic") == "ADOPTION":
            return "[COLOR %s]%s[/COLOR]" % (kodi.ACCENT, L(H["badge_adoption"]))
        if article.get("local"):
            return "[COLOR %s]%s[/COLOR]" % (kodi.GOLD, L(H["badge_local"]))
        if article.get("paywall"):
            return "[COLOR FFFF6B7A]%s[/COLOR]" % L(S["paywall"])
        return ""

    def hero_item(self, article):
        item = xbmcgui.ListItem(label=article["title"],
                                label2="%s · %s" % (article.get("source", ""),
                                                    self.home.plugin.when(article.get("published"))),
                                offscreen=True)
        width, height = (1920, 1080) if self.hd else (1280, 720)
        image = images.thumb(article, width, height) or kodi.placeholder("POSITIVE")
        item.setArt({"thumb": image, "fanart": image})
        try:
            item.getVideoInfoTag().setPlot(article.get("snippet") or "")
        except AttributeError:
            item.setInfo("video", {"plot": article.get("snippet") or ""})
        item.setProperty("id", article["id"])
        return item

    def show_all_item(self, kind, total):
        item = xbmcgui.ListItem(label="[B]%s  »[/B]" % L(H["show_all"]),
                                label2="%d" % total, offscreen=True)
        icon = MENU_ICONS.get(kind) or {"new": "all.png", "local": "region.png", "saved": "saved.png",
                                       "history": "history.png"}.get(kind, "all.png")
        item.setArt({"thumb": kodi.media(icon)})
        item.setProperty("action", "all")
        item.setProperty("kind", kind)
        return item

    # ------------------------------------------------------------ Bedienung

    def onClick(self, control_id):
        if MENU.get(control_id) == "meow":
            self.toggle_meow()
            return
        kodi.meow()  # wie die App: Miau bei jeder Berührung (Einstellung „Miau-Sound“)
        if control_id in MENU:
            self.menu(MENU[control_id])
            return
        if control_id == HERO_LIST or control_id in (self.slots or {}):
            item = self.getControl(control_id).getSelectedItem()
            if item is None:
                return
            if item.getProperty("action") == "all":
                self.open_list(row_params(item.getProperty("kind")))
            else:
                self.read(item)

    def onAction(self, action):
        action_id = action.getId()
        if action_id in CLOSE_ACTIONS:
            self.close()
        elif action_id in CONTEXT_ACTIONS:
            control_id = self.getFocusId()
            if control_id == HERO_LIST or control_id in (self.slots or {}):
                self.card_menu(control_id)

    def open_list(self, params):
        url = BASE + "?" + "&".join("%s=%s" % kv for kv in sorted(dict(params, action="list").items()))
        xbmc.executebuiltin("ActivateWindow(Videos,%s,return)" % url)

    def read(self, item):
        plugin = self.home.plugin
        plugin.params = {"id": item.getProperty("id")}
        plugin.read()
        article = self.home.store.article(item.getProperty("id"))
        if article:  # gelesen → Titel gedimmt, ohne die Reihe neu aufzubauen
            item.setLabel(self.card_label(article, self.home.store.user.get("visit_boundary", 0)))

    def menu(self, key):
        if key == "all":
            self.open_list({})
        elif key in MOODS:
            self.open_list({"mood": key})
        elif key == "topics":
            xbmc.executebuiltin("ActivateWindow(Videos,%s?action=topics,return)" % BASE)
        elif key == "local":
            self.open_list({"local": "1"})
        elif key == "saved":
            self.open_list({"saved": "1"})
        elif key == "search":
            term = xbmcgui.Dialog().input(L(S["search_term"]))
            if term and term.strip():
                self.open_list({"query": term.strip()})
        elif key == "refresh":
            self.refresh_in_background(force=True)
        elif key == "settings":
            kodi.addon().openSettings()
            self.reload()

    def toggle_meow(self):
        """Schnell-Umschalter wie in der App-Leiste; beim Einschalten zur Bestätigung miauen."""
        enabled = not kodi.setting_bool("meow_sound", False)
        kodi.addon().setSetting("meow_sound", "true" if enabled else "false")
        self.setProperty("meow", "on" if enabled else "")
        kodi.notify(L(H["meow_on"] if enabled else H["meow_off"]), milliseconds=2000)
        if enabled:
            kodi.meow(force=True)

    def reload(self):
        """Einstellungen geändert → Daten und Reihen neu."""
        self.home = Home()
        self.fill()
        if self.home.is_stale():
            self.refresh_in_background()

    def refresh_in_background(self, force=False):
        if self.refreshing:
            return
        self.refreshing = True
        self.setProperty("busy", L(H["busy"]))

        def work():
            try:
                new_count = self.home.plugin.ensure_fresh(force=force)
                self.home.store.reload()
                self.fill(keep_focus=True)
                if force and new_count is not None:
                    kodi.notify(L(S["loaded_new"]) % new_count if new_count else L(S["loaded_none"]))
            except Exception as error:  # noqa: BLE001 – Startseite bleibt benutzbar
                kodi.log("Startseite: Aktualisierung fehlgeschlagen: %r" % error, xbmc.LOGWARNING)
            finally:
                self.refreshing = False
                self.setProperty("busy", "")
        thread = threading.Thread(target=work)
        thread.daemon = True
        thread.start()
        return thread

    def card_menu(self, control_id):
        """Menü-Taste auf einer Kachel: Aktionen wie im Kontextmenü der Listen + Reihe anpassen."""
        item = self.getControl(control_id).getSelectedItem()
        slot_kind = (self.slots or {}).get(control_id)
        store = self.home.store
        article = store.article(item.getProperty("id")) if item is not None and item.getProperty("id") else None
        entries = []
        if article:
            aid = article["id"]
            entries.append(("read", L(H["read"])))
            entries.append(("bookmark", L(S["unbookmark"] if store.is_bookmarked(aid) else S["bookmark"])))
            entries.append(("hide", L(S["hide"])))
            if article.get("source"):
                entries.append(("mute_source", L(S["mute_source"]) % article["source"]))
            if article.get("topic"):
                entries.append(("mute_topic", L(S["less_topic"]) % L(S[article["topic"]])))
            entries.append(("not_cat", L(S["not_cat"])))
            entries.append(("mood", L(S["fix_mood"])))
        if slot_kind:
            entries.append(("row_change", L(H["row_change"])))
            entries.append(("row_remove", L(H["row_remove"])))
        if not entries:
            return
        choice = xbmcgui.Dialog().contextmenu([label for _, label in entries])
        if choice < 0:
            return
        key = entries[choice][0]
        if key == "read":
            self.read(item)
            return
        if key in ("row_change", "row_remove"):
            slot = slot_kind[0]
            if key == "row_remove":
                kodi.addon().setSetting("home_row%d" % slot, "off")
            else:
                options = [k for k in ROW_TYPES if k != "off"]
                picked = xbmcgui.Dialog().select(L(H["row_change"]),
                                                 [row_label(k, self.home.config.region) for k in options],
                                                 preselect=options.index(slot_kind[1]) if slot_kind[1] in options else -1)
                if picked < 0:
                    return
                kodi.addon().setSetting("home_row%d" % slot, options[picked])
            self.fill()
            return
        plugin = self.home.plugin
        plugin.params = {"id": article["id"], "on": "0" if key == "bookmark" and store.is_bookmarked(article["id"])
                         else "1"}
        getattr(plugin, {"bookmark": "act_bookmark", "hide": "act_hide", "mute_source": "act_mute_source",
                         "mute_topic": "act_mute_topic", "not_cat": "act_not_cat", "mood": "act_mood"}[key])()
        self.fill(keep_focus=True)


MENU_PROPS = {301: "menu_all", 302: "menu_positive", 303: "menu_neutral", 304: "menu_negative"}


def run(argv=None):
    if kodi.setting_str("open_mode", "home") == "lists":
        xbmc.executebuiltin("ActivateWindow(Videos,%s,return)" % BASE)
        return
    width, height = kodi.screen_size()
    script_path, name = layout.build("home", width, height, kodi.addon_path(), kodi.profile_path())
    window = HomeWindow(name, script_path, "Default", "1080i")
    window.home = Home()
    window.hd = height >= 1440
    window.doModal()
    del window
