# -*- coding: utf-8 -*-
"""Klare Stimmung für die Listen „Positiv“, „Neutral“ und „Negativ“.

Die Bewertung der App (``classify.analyze_sentiment``, bitgenau portiert) bleibt
unverändert – sie liefert Wert und Grundstimmung. Für die Listen in Kodi kommt
hier eine strengere Stufe dazu, damit „Positiv“ wirklich nur gute Nachrichten
und „Negativ“ alle traurigen enthält:

* Positiv: klares Happy End (Wert ≥ 0.5), Vermittlungen („sucht ein Zuhause“)
  oder deutlich positiver Wert ohne traurige Signale. Ein einzelnes nettes Wort
  („gesund“, „süß“) reicht nicht mehr – solche Meldungen sind neutral.
* Negativ: alles, was die App negativ einstuft (außer Vermittlungen), dazu
  neutrale Meldungen mit traurigen Signalen (Tod/Notlage im Teaser, Notlage im
  Titel, belastende Wörter im Titel) – Ratgeber und Wissen bleiben neutral.
* Neutral: der Rest, auch Gemischtes.

Korrekturen des Nutzers („Stimmung korrigieren“) gehen weiterhin immer vor."""
import re

from catnewz.classify import sentiment as _sentiment
from catnewz.classify._rules import any_match
from catnewz.classify.text import normalize

POSITIVE, NEUTRAL, NEGATIVE = "POSITIVE", "NEUTRAL", "NEGATIVE"
VERSION = 1  # erhöhen, wenn sich die Regeln ändern → gespeicherte Meldungen werden neu eingestuft

DECISIVE = 0.5          # Happy End / Tod / Notlage im Titel (App: ±0.55 … ±0.9)
CLEAR_POSITIVE = 0.31   # darunter genügt meist ein einzelnes nettes Wort
SAD_TITLE_WEIGHT = 0.25  # Summe belastender Wörter im Titel einer neutralen Meldung
LEANS_NEGATIVE = -0.1    # neutrale Meldung, die die App schon deutlich ins Negative rechnet

# Ratgeber/Tipps, die die App-Regeln (Neutralisierer) nicht erfassen – nur für schwach positive Titel
_ADVICE = {
    "de": r"\btipps?\b|\bratgeber\b|\bhacks?\b|\bso (geht|klappt|gelingt)|\bwas (wirklich|halter)\b|\btest\b",
    "en": r"\btips?\b|\bhacks?\b|\bguide\b|\bhow to\b|\bpicks\b|\breview\b",
    "es": r"\bconsejos?\b|\btrucos?\b|\bguía\b|\bcómo\b",
    "fr": r"\bconseils?\b|\bastuces?\b|\bguide\b|\bcomment\b",
    "it": r"\bconsigli\b|\btrucchi\b|\bguida\b",
}
_ADVICE_RX = dict((code, re.compile(pattern, re.I | re.U)) for code, pattern in _ADVICE.items())

# Wendung zum Guten, die die App-Regeln nicht kennen – verhindert, dass eine neutrale
# Meldung mit traurigem Anfang („… gravely ill … pulled through“) nach „Negativ“ rutscht
_TURNAROUND = {
    "de": r"überleb|geschafft|doch noch|trotz (allem|alle)|genesen|wieder gesund|erholt|kämpft sich",
    "en": r"pulled through|surviv|recover|beat the odds|against (all )?(the )?odds|made it|"
          r"refused to give up|thriving|on the mend",
    "es": r"sobreviv|se recuper|contra todo pronóstico|salió adelante",
    "fr": r"surviv|s'en (est )?sorti|rétabli|malgré tout|tiré d'affaire",
    "it": r"sopravviss|si è ripres|nonostante tutto|ce l'ha fatta",
}
_TURNAROUND_RX = dict((code, re.compile(pattern, re.I | re.U)) for code, pattern in _TURNAROUND.items())


def clear_mood(title, snippet, language, score, sentiment, topic=None):
    code = (language or "").lower()[:2]
    lex = _sentiment._lexicon((language or "").lower())
    n_title = normalize(title or "")
    n_snippet = normalize(snippet or "")
    full_text = n_title if not n_snippet else n_title + " " + n_snippet

    fatal_title = any_match(lex.fatal, n_title)
    distress_title = any_match(lex.severe_distress, n_title)
    happy_title = any_match(lex.happy_outcome, n_title)
    fatal_snippet = bool(n_snippet) and any_match(lex.fatal, n_snippet)
    distress_snippet = bool(n_snippet) and any_match(lex.severe_distress, n_snippet)
    happy_snippet = bool(n_snippet) and any_match(lex.happy_outcome, n_snippet)
    advice = any_match(lex.neutralizers, full_text)
    sad_title_weight = sum(weight for rx, weight in lex.negative if rx.search(n_title))
    nice_title = any(rx.search(n_title) for rx, _ in lex.positive)
    # Vermittlung: ausdrücklicher Aufruf im Titel zählt immer; das Thema allein nur
    # ohne belastende Wörter im Titel („… entgeht tödlicher Falle und ist gelähmt“).
    appeal = (not fatal_title and not distress_title
              and (any_match(lex.adoption_appeal, n_title) or (topic == "ADOPTION" and not sad_title_weight)))

    if sentiment == POSITIVE:
        if score >= DECISIVE or appeal:
            return POSITIVE
        # Schwach positiv: bleibt positiv (Wohlfühl-Geschichten), außer es spricht etwas dagegen –
        # traurige Signale oder es ist eigentlich Ratgeber/Wissen bzw. eine offene Frage.
        sad = sad_title_weight or fatal_snippet or distress_snippet
        advice_words = _ADVICE_RX.get(code, _ADVICE_RX["en"])
        informative = (advice or topic == "KNOWLEDGE" or "?" in (title or "")
                       or advice_words.search(title or "") is not None)
        return NEUTRAL if sad or informative else POSITIVE

    if sentiment == NEGATIVE:
        if appeal and score > -DECISIVE:
            return NEUTRAL  # Vermittlungen sind nie negativ (wie in der App), traurige Details → neutral
        return NEGATIVE

    if appeal:
        return POSITIVE
    # Neutral → negativ nur bei eindeutig traurigen Signalen ohne jedes Gegengewicht
    # („… gravely ill … pulled through together“ bleibt neutral).
    sad_signals = fatal_snippet or distress_title or (distress_snippet and not happy_snippet)
    nice_anywhere = nice_title or happy_snippet or any(rx.search(n_snippet) for rx, _ in lex.positive)
    turnaround = _TURNAROUND_RX.get(code, _TURNAROUND_RX["en"]).search(
        (title or "") + " " + (snippet or "")) is not None
    if not advice and not happy_title and not turnaround and score <= LEANS_NEGATIVE and not nice_anywhere and (
            sad_signals or sad_title_weight >= SAD_TITLE_WEIGHT):
        return NEGATIVE
    return NEUTRAL
