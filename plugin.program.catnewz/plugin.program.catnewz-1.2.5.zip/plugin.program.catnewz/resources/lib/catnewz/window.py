# -*- coding: utf-8 -*-
"""Eigenes Lese-Fenster im Catnewz-Holo-Look (Bild, Stimmung, Quelle, Volltext).

Das Fenster bringt sein Layout und seine Grafiken selbst mit
(resources/skins/Default) – es läuft daher mit jedem Skin. Inhalte kommen als
Fenster-Eigenschaften, das XML zeigt sie über $INFO[Window.Property(…)] an.

Wie in der App: Schriftgröße (Links/Rechts) und Lesefläche Dunkel/Hell/Sepia
(Menü-Taste); beides wird gespeichert. Die Schriftgröße wechselt zwischen vier
Textfeldern, die per Zoom-Animation skaliert sind – das funktioniert mit jeder
Skin-Schrift (font13)."""
import xbmc
import xbmcgui

from catnewz import images, kodi, layout
from catnewz.kodi import L

CLOSE_ACTIONS = (9, 10, 13, 92)  # ParentDir, PreviousMenu, Stop, NavBack
SMALLER_ACTIONS = (1,)           # Links
LARGER_ACTIONS = (2,)            # Rechts
THEME_ACTIONS = (117, 11)        # Kontextmenü, Info

FONT_SCALES = ("90", "100", "115", "130")
SCROLLBARS = {"90": 35, "100": 31, "115": 36, "130": 37}
THEMES = ("dark", "light", "sepia")
PALETTES = {
    "dark": {"title": "FFF0FBF8", "body": "FFE1ECE9", "muted": "FF9AA9A6", "accent": "FF2DE1C2",
             "gold": "FFFFC24B", "POSITIVE": "FF3EE68F", "NEUTRAL": "FFFFC24B", "NEGATIVE": "FFFF6B7A"},
    "light": {"title": "FF10202A", "body": "FF1F2D33", "muted": "FF55666B", "accent": "FF0B7F6D",
              "gold": "FF9A6A00", "POSITIVE": "FF1E8E50", "NEUTRAL": "FF9A6A00", "NEGATIVE": "FFC0394A"},
    "sepia": {"title": "FF3B2F1E", "body": "FF4A3B26", "muted": "FF7A6A52", "accent": "FF7A4E18",
              "gold": "FF8C5A1E", "POSITIVE": "FF3F7A2E", "NEUTRAL": "FF8C5A1E", "NEGATIVE": "FFA33A2E"},
}
THEME_LABELS = {"dark": 30089, "light": 30090, "sepia": 30091}


def _setting_scale():
    value = str(kodi.setting_int("reader_font", 100))
    return value if value in FONT_SCALES else "100"


def _setting_theme():
    value = kodi.setting_str("reader_theme", "dark")
    return value if value in THEMES else "dark"


class ReaderWindow(xbmcgui.WindowXMLDialog):
    article = None
    content = None
    mood = "NEUTRAL"
    scale = "100"
    theme = "dark"

    def onInit(self):
        self.apply()

    def apply(self):
        for key, value in build_properties(self.article, self.content, self.mood, self.theme).items():
            self.setProperty(key, value)
        self.setProperty("fontscale", self.scale)
        self.setProperty("theme", self.theme)
        self.focus_scrollbar()

    def focus_scrollbar(self):
        """Die Leiste der neuen Schriftgröße wird erst im nächsten Bild sichtbar –
        bis dahin lehnt Kodi den Fokus ab, deshalb kurz nachfassen."""
        target = SCROLLBARS[self.scale]
        for _ in range(25):
            try:
                self.setFocusId(target)
                if self.getFocusId() == target:
                    return
            except RuntimeError:
                pass
            xbmc.sleep(20)

    def onAction(self, action):
        action_id = action.getId()
        if action_id in CLOSE_ACTIONS:
            self.close()
        elif action_id in SMALLER_ACTIONS + LARGER_ACTIONS:
            index = FONT_SCALES.index(self.scale) + (-1 if action_id in SMALLER_ACTIONS else 1)
            if 0 <= index < len(FONT_SCALES):
                self.scale = FONT_SCALES[index]
                kodi.addon().setSetting("reader_font", self.scale)
                self.apply()
        elif action_id in THEME_ACTIONS:
            self.theme = THEMES[(THEMES.index(self.theme) + 1) % len(THEMES)]
            kodi.addon().setSetting("reader_theme", self.theme)
            self.apply()
            kodi.notify(L(30088) % L(THEME_LABELS[self.theme]), milliseconds=1500)


def _body(article, content, palette):
    from catnewz.plugin import S
    blocks = (content or {}).get("blocks") or []
    parts = []
    if blocks:
        for kind, text in blocks:
            parts.append("[B][COLOR %s]%s[/COLOR][/B]" % (palette["accent"], text) if kind == "h" else text)
    else:
        parts.append("[I][COLOR %s]%s[/COLOR][/I]" % (palette["muted"], L(S["no_fulltext"])))
        if article.get("snippet"):
            parts.append(article["snippet"])
    also = article.get("also") or []
    if also:
        parts.append("[COLOR %s]%s: %s[/COLOR]" % (palette["muted"], L(S["also"]), ", ".join(a[0] for a in also)))
    return "[COLOR %s]%s[/COLOR]" % (palette["body"], "[CR][CR]".join(parts))


def build_properties(article, content, mood, theme="dark"):
    from catnewz.plugin import S
    palette = PALETTES.get(theme, PALETTES["dark"])
    size = (1920, 1080) if kodi.hd_screen() else (1280, 720)
    image = (content or {}).get("image") or images.thumb(article, size[0], size[1]) or ""
    badges = []
    if article.get("topic"):
        badges.append(L(S[article["topic"]]))
    if article.get("local"):
        badges.append(L(S["local"]))
    if article.get("paywall"):
        badges.append(L(S["paywall"]))
    url = (content or {}).get("url") or article["link"]
    host = url.split("/")[2] if "://" in url else url
    return {
        "title": "[COLOR %s]%s[/COLOR]" % (palette["title"], article["title"]),
        "image": image,
        "mood": "[COLOR %s]•  %s[/COLOR]" % (palette.get(mood, palette["gold"]), L(S[mood])),
        "meta": "[COLOR %s]%s  ·  %s[/COLOR]" % (palette["accent"], article.get("source", ""),
                                                kodi.time_label(article.get("published"))),
        "badges": "[COLOR %s]%s[/COLOR]" % (palette["gold"], "  ·  ".join(badges)) if badges else "",
        "body": _body(article, content, palette),
        "original": "[COLOR %s]%s[/COLOR]" % (palette["muted"], L(S["original"]) % host.replace("www.", "")),
        "hint": "[COLOR %s]%s[/COLOR]" % (palette["muted"], L(S["reader_hint"])),
    }


def show(article, content, mood):
    width, height = kodi.screen_size()
    script_path, name = layout.build("reader", width, height, kodi.addon_path(), kodi.profile_path())
    window = ReaderWindow(name, script_path, "Default", "1080i")
    window.article, window.content, window.mood = article, content, mood
    window.scale, window.theme = _setting_scale(), _setting_theme()
    for key, value in build_properties(article, content, mood, window.theme).items():
        window.setProperty(key, value)
    window.setProperty("fontscale", window.scale)
    window.setProperty("theme", window.theme)
    window.doModal()
    del window
