# -*- coding: utf-8 -*-
"""Catnewz für Kodi.

Aufbau: alles ohne Kodi-Abhängigkeit (Feeds, RSS, Lesemodus, Speicher,
Klassifikation) ist reines Python und testbar; nur ``kodi``, ``plugin`` und
``service`` sprechen mit Kodi. Läuft ab Kodi 19 (Python 3.8), nur Standardbibliothek.
"""
