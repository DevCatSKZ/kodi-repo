# -*- coding: utf-8 -*-
"""Lesemodus: Volltext eines Artikels aus der Verlagsseite (wie
ArticleExtractor.kt) – JSON-LD articleBody, sonst <p>/<h2>/<h3>-Blöcke ohne
Navigation/Werbung. Dazu die Seiten-Vorschau (og:image/og:description) für
Artikel ohne Bild/Teaser und die MSN-Auflösung zur Verlagsseite."""
import html
import json
import re

from catnewz import google, http, meta

MIN_PARAGRAPH = 50
MIN_TOTAL = 350
MAX_BLOCKS = 80
MAX_ARTICLE_BYTES = 600000
MAX_PREVIEW_BYTES = 160000

_REMOVE = [re.compile(p, re.I) for p in (
    r"<script\b[^>]*>[\s\S]*?</script>", r"<style\b[^>]*>[\s\S]*?</style>",
    r"<noscript\b[^>]*>[\s\S]*?</noscript>", r"<template\b[^>]*>[\s\S]*?</template>",
    r"<svg\b[^>]*>[\s\S]*?</svg>", r"<iframe\b[^>]*>[\s\S]*?</iframe>",
    r"<form\b[^>]*>[\s\S]*?</form>", r"<nav\b[^>]*>[\s\S]*?</nav>",
    r"<header\b[^>]*>[\s\S]*?</header>", r"<footer\b[^>]*>[\s\S]*?</footer>",
    r"<aside\b[^>]*>[\s\S]*?</aside>", r"<figure\b[^>]*>[\s\S]*?</figure>", r"<!--[\s\S]*?-->")]
_BLOCK = re.compile(r"<(p|h2|h3|li)\b[^>]*>([\s\S]*?)</\1>", re.I)
_LINK_TAG = re.compile(r"<a\b", re.I)
_ARTICLE = re.compile(r"<article\b[^>]*>([\s\S]*?)</article>", re.I)
_MAIN = re.compile(r"<main\b[^>]*>([\s\S]*?)</main>", re.I)
_H1 = re.compile(r"<h1[^>]*>([\s\S]*?)</h1>", re.I)
_LD_JSON = re.compile(r"""<script[^>]+application/ld\+json[^>]*>([\s\S]*?)</script>""", re.I)
_JUNK = [re.compile(p, re.I) for p in (
    r"function\s*\(", r"document\.", r"window\.", r"querySelector", r"addEventListener",
    r"cookie", r"newsletter", r"(anzeige|advertisement|sponsored)", r"alle rechte vorbehalten",
    r"^(mehr zum thema|lesen sie auch|auch interessant|das könnte sie)",
    r"jetzt (abonnieren|registrieren|anmelden)", r"^(share|teilen|folgen sie uns)")]
_MSN_SOURCES = [re.compile(p) for p in (
    r'"sourceHref"\s*:\s*"(https?://[^"]+)', r'"originalUrl"\s*:\s*"(https?://[^"]+)',
    r'"providerContentUrl"\s*:\s*"(https?://[^"]+)')]


def strip_html(text):
    text = re.sub(r"<[^>]*>", " ", text or "")
    text = html.unescape(text).replace(" ", " ").replace("­", "")
    return re.sub(r"\s+", " ", text).strip()


def _paragraphs_from_body(body):
    lines = [strip_html(line) for line in re.split(r"[\r\n]+", body)]
    lines = [line for line in lines if len(line) >= MIN_PARAGRAPH]
    if len(lines) >= 2:
        return lines
    text = strip_html(body)
    if len(text) < MIN_PARAGRAPH:
        return []
    chunks, current, count = [], [], 0
    for sentence in re.split(r"(?<=[.!?…])\s+", text):
        if not sentence.strip():
            continue
        current.append(sentence)
        count += 1
        if count >= 3 and len(" ".join(current)) >= 180:
            chunks.append(" ".join(current))
            current, count = [], 0
    if current:
        chunks.append(" ".join(current))
    return [chunk for chunk in chunks if len(chunk) >= 20]


def _find_article_node(node):
    if isinstance(node, dict):
        body = node.get("articleBody")
        if isinstance(body, str) and len(body) >= 200:
            return node
        for value in node.values():
            found = _find_article_node(value)
            if found:
                return found
    elif isinstance(node, list):
        for value in node:
            found = _find_article_node(value)
            if found:
                return found
    return None


def _image_from_ld(image):
    if isinstance(image, str):
        return image if image.startswith("http") else None
    if isinstance(image, dict):
        url = image.get("url")
        return url if isinstance(url, str) and url.startswith("http") else None
    if isinstance(image, list):
        for entry in image:
            url = _image_from_ld(entry)
            if url:
                return url
    return None


def extract(page_html):
    """dict(title, image, blocks=[('h'|'p', text)]) oder None (zu wenig Text)."""
    if not page_html:
        return None
    tags = meta.parse(page_html)
    hero = meta.first_image(tags)
    title = tags.get("og:title")
    if not title:
        h1 = _H1.search(page_html)
        title = strip_html(h1.group(1)) if h1 else None
    else:
        title = strip_html(title)

    for match in _LD_JSON.finditer(page_html):
        raw = match.group(1).strip()
        if "articleBody" not in raw:
            continue
        try:
            node = _find_article_node(json.loads(raw))
        except ValueError:
            continue
        if not node:
            continue
        paragraphs = _paragraphs_from_body(node.get("articleBody", ""))
        if sum(len(p) for p in paragraphs) >= MIN_TOTAL:
            headline = node.get("headline")
            return {
                "title": title or (strip_html(headline) if isinstance(headline, str) else None),
                "image": hero or _image_from_ld(node.get("image")),
                "blocks": [("p", p) for p in paragraphs[:MAX_BLOCKS]],
            }

    cleaned = page_html
    for pattern in _REMOVE:
        cleaned = pattern.sub(" ", cleaned)
    area = _ARTICLE.search(cleaned) or _MAIN.search(cleaned)
    content = area.group(1) if area else cleaned

    blocks, total = [], 0
    for match in _BLOCK.finditer(content):
        if len(blocks) >= MAX_BLOCKS:
            break
        tag, inner = match.group(1).lower(), match.group(2)
        links = len(_LINK_TAG.findall(inner))
        text = strip_html(inner)
        if not text or (links >= 2 and len(text) < links * 80):
            continue
        if any(pattern.search(text) for pattern in _JUNK):
            continue
        if tag in ("h2", "h3"):
            if 8 <= len(text) <= 120:
                blocks.append(("h", text))
        elif len(text) >= MIN_PARAGRAPH:
            blocks.append(("p", text))
            total += len(text)
    while blocks and blocks[-1][0] != "p":
        blocks.pop()
    if total < MIN_TOTAL:
        return None
    return {"title": title, "image": hero, "blocks": blocks}


def resolve_msn(url):
    if "msn.com" not in url:
        return url
    page = http.fetch(url, timeout=10, max_bytes=400000)
    if not page.ok:
        return url
    text = page.text()
    for pattern in _MSN_SOURCES:
        match = pattern.search(text)
        if match and "msn.com" not in match.group(1):
            return match.group(1).replace("\\/", "/")
    return url


def resolve_link(url):
    """Google-/MSN-Weiterleitungen → Verlags-URL (Google gedrosselt → Original)."""
    if "news.google.com" in url:
        resolved = google.resolve(url)
        if resolved and resolved != google.RATE_LIMITED:
            return resolved
        return url
    return resolve_msn(url)


def load(url):
    """Artikel laden: dict(url, title, image, blocks) – blocks leer, wenn nicht extrahierbar."""
    final = resolve_link(url)
    page = http.fetch(final, timeout=15, max_bytes=MAX_ARTICLE_BYTES)
    if not page.ok:
        return {"url": final, "title": None, "image": None, "blocks": [], "error": page.status or "network"}
    text = page.text()
    article = extract(text) or {"title": None, "image": meta.first_image(meta.parse(text), page.url), "blocks": []}
    article["url"] = page.url or final
    if not article.get("image"):
        article["image"] = meta.first_image(meta.parse(text), page.url)
    return article


def preview(url):
    """Vorschau einer Verlagsseite: dict(image, description, paywall) oder None."""
    page = http.fetch(url, timeout=12, max_bytes=MAX_PREVIEW_BYTES, mobile=True, accept="text/html")
    if not page.ok:
        return None
    text = page.text()
    tags = meta.parse(text)
    return {"image": meta.first_image(tags, page.url), "description": meta.first_description(tags),
            "html": text, "url": page.url}
