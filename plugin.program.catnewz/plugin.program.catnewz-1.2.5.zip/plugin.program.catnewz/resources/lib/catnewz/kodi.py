# -*- coding: utf-8 -*-
"""Kodi-Anbindung (Kodi 19 Matrix … 22): Einstellungen, Texte, Pfade,
Meldungen. Alles Kodi-Spezifische liegt hier, damit der Rest testbar bleibt."""
import os
import re
import time

import xbmc
import xbmcaddon
import xbmcgui

from catnewz import http, news

ADDON_ID = "plugin.program.catnewz"

ACCENT = "FF2DE1C2"
VIOLET = "FFA08CFF"
GOLD = "FFFFC24B"
MUTED = "FF9AA9A6"
MOOD_COLORS = {"POSITIVE": "FF3EE68F", "NEUTRAL": "FFFFC24B", "NEGATIVE": "FFFF6B7A"}
# Sichtbare Zeichen nur aus Latin-1 und Satzzeichen (• » · – „“ …): Kodi zeichnet mit der Schrift des
# Skins, und z. B. Aeon Nox SiLVO kennt ● ★ → ✓ nicht (Kästchen). Stimmungspunkt daher „•“.


def addon():
    return xbmcaddon.Addon(ADDON_ID)


def translate_path(path):
    try:
        import xbmcvfs
        return xbmcvfs.translatePath(path)
    except (ImportError, AttributeError):  # Kodi < 19
        return xbmc.translatePath(path)


def addon_path():
    return translate_path(addon().getAddonInfo("path"))


def profile_path():
    return translate_path(addon().getAddonInfo("profile"))


def media(name):
    return "%s/resources/media/%s" % (addon_path().rstrip("/\\").replace("\\", "/"), name)


def asset(name):
    """icon.png liegt im Add-on-Hauptordner (wie im DevCatSKZ-Repository üblich)."""
    return "%s/%s" % (addon_path().rstrip("/\\").replace("\\", "/"), name)


def backdrop():
    """Hintergrundbild (Fanart) laut addon.xml – der Dateiname trägt eine Nummer,
    damit Kodis Bild-Cache nach einer Änderung nicht das alte Bild zeigt."""
    path = translate_path(addon().getAddonInfo("fanart") or "")
    return path.replace("\\", "/") if path else media("backdrop-4.png")


def placeholder(mood, card=False):
    """Platzhalter je Stimmung (Hologlas-Hintergrund + Logo); Nummer im Namen wegen Kodis Bild-Cache.
    card: 800×450 für die Kacheln der Startseite (Kodi verkleinert ohne Mipmaps)."""
    return media("placeholder-2-%s%s.jpg" % ((mood or "neutral").lower(), "-card" if card else ""))


def meow(force=False):
    """Leises Miau wie in der App (Einstellung „Miau-Sound“, Standard aus). Kodi spielt es über
    die Oberflächenklänge – sind die aus oder läuft Passthrough, bleibt es still."""
    if not (force or setting_bool("meow_sound", False)):
        return False
    try:
        xbmc.playSFX(media("meow.wav"))
    except (AttributeError, RuntimeError, TypeError):
        return False
    return True


def screen_size():
    try:
        return xbmcgui.getScreenWidth() or 1920, xbmcgui.getScreenHeight() or 1080
    except Exception:  # noqa: BLE001
        return 1920, 1080


def hd_screen():
    """Ab 1440 Zeilen (WQHD, 21:9/32:9 mit 1440, 4K) größere Bilder anfordern."""
    return screen_size()[1] >= 1440


_PO_STRINGS = {}
_PO_ENTRY = re.compile(r'msgctxt "#(\d+)"\s*\nmsgid "((?:[^"\\]|\\.)*)"\s*\nmsgstr "((?:[^"\\]|\\.)*)"')


def L(string_id):
    """Text aus strings.po. Kodi hält die Texte im Speicher – nach einem Update ohne
    Neustart können neue Texte fehlen; dann direkt aus der eigenen Sprachdatei."""
    text = addon().getLocalizedString(string_id)
    return text if text else _po_strings().get(string_id, "")


def _po_strings():
    if not _PO_STRINGS:
        try:
            code = (xbmc.getLanguage(xbmc.ISO_639_1) or "en").lower()[:2]
        except Exception:  # noqa: BLE001
            code = "en"
        folder = {"de": "de_de", "es": "es_es", "fr": "fr_fr", "it": "it_it"}.get(code, "en_gb")
        for name in ("en_gb", folder):  # Englisch als Grundlage, Kodi-Sprache darüber
            path = os.path.join(addon_path(), "resources", "language", "resource.language.%s" % name, "strings.po")
            try:
                with open(path, encoding="utf-8") as handle:
                    for string_id, msgid, msgstr in _PO_ENTRY.findall(handle.read()):
                        value = (msgstr or msgid).replace('\\"', '"').replace("\\\\", "\\")
                        if value:
                            _PO_STRINGS[int(string_id)] = value
            except (OSError, ValueError):
                continue
    return _PO_STRINGS


def log(message, level=xbmc.LOGINFO):
    xbmc.log("[Catnewz] %s" % message, level)


def _setting(kind, key, default):
    a = addon()
    try:
        if kind == "bool":
            return a.getSettingBool(key)
        if kind == "int":
            return a.getSettingInt(key)
        return a.getSettingString(key)
    except (RuntimeError, TypeError, AttributeError):
        raw = a.getSetting(key)
        if raw == "":
            return default
        if kind == "bool":
            return raw.lower() == "true"
        if kind == "int":
            try:
                return int(float(raw))
            except ValueError:
                return default
        return raw


def setting_bool(key, default=False):
    return _setting("bool", key, default)


def setting_int(key, default=0):
    return _setting("int", key, default)


def setting_str(key, default=""):
    return _setting("str", key, default) or default


def news_language():
    chosen = setting_str("language", "auto")
    if chosen in ("de", "en", "es", "fr", "it"):
        return chosen
    try:
        kodi_language = xbmc.getLanguage(xbmc.ISO_639_1) or ""
    except Exception:  # noqa: BLE001
        kodi_language = ""
    kodi_language = kodi_language.lower()[:2]
    return kodi_language if kodi_language in ("de", "en", "es", "fr", "it") else "en"


def config():
    language = news_language()
    http.set_language(language)
    return news.Config(
        language=language,
        region=setting_str("region", ""),
        hide_ads=setting_bool("hide_ads", True),
        hide_paywall=setting_bool("hide_paywall", False),
        max_age_days=setting_int("max_age", 14),
        sort=setting_str("sort", news.SORT_NEWEST),
        use_google=setting_bool("use_google", True),
        show_hidden=setting_bool("show_hidden", False),
    )


def notify(message, heading="Catnewz", milliseconds=4000, icon=None):
    xbmcgui.Dialog().notification(heading, message, icon or asset("icon.png"), milliseconds, False)


def _time_format():
    try:
        return xbmc.getRegion("time").replace(":%S", "").strip() or "%H:%M"
    except Exception:  # noqa: BLE001
        return "%H:%M"


def time_label(timestamp, relative=None):
    """Zeitangabe einer Meldung: relativ wie in der App („vor 5 Min.“, „gestern, 14:32“,
    „5. Juli“) oder – Einstellung aus – Uhrzeit/Datum im Format der Kodi-Region."""
    if not timestamp:
        return ""
    if relative is None:
        relative = setting_bool("relative_time", True)
    if relative:
        return relative_label(timestamp)
    moment = time.localtime(timestamp)
    today = time.localtime()
    try:
        date_format = xbmc.getRegion("dateshort") or "%d.%m.%Y"
    except Exception:  # noqa: BLE001
        date_format = "%d.%m.%Y"
    if moment.tm_yday == today.tm_yday and moment.tm_year == today.tm_year:
        return time.strftime(_time_format(), moment)
    return time.strftime(date_format, moment)


def relative_label(timestamp, now=None):
    """Wie TimeLabels.kt der App: heute relativ, gestern mit Uhrzeit, sonst Tag + Monat."""
    now = now or time.time()
    seconds = max(0, now - timestamp)
    moment, today = time.localtime(timestamp), time.localtime(now)
    if seconds < 60:
        return L(30066)
    if seconds < 3600:
        return L(30067) % int(seconds // 60)
    if (moment.tm_year, moment.tm_yday) == (today.tm_year, today.tm_yday):
        return L(30068) % int(seconds // 3600)
    yesterday = time.localtime(now - 86400)
    if (moment.tm_year, moment.tm_yday) == (yesterday.tm_year, yesterday.tm_yday):
        return L(30069) % time.strftime(_time_format(), moment)
    month = xbmc.getLocalizedString(20 + moment.tm_mon)  # Kodi: 21 = Januar … 32 = Dezember
    if moment.tm_year == today.tm_year:
        return L(30070).format(day=moment.tm_mday, month=month)
    return L(30071).format(day=moment.tm_mday, month=month, year=moment.tm_year)


# ------------------------------------------------------------------ Darstellung

VIEWS = ("auto", "cards", "holo", "fullscreen", "compact", "magazine")
# App-Ansicht → (Kodi-Inhaltsart, Ansicht in Estuary, Ansicht in Skins auf Aeon-Nox-SiLVO-Basis).
# Die Inhaltsart entscheidet, welche Ansichten ein Skin überhaupt anbietet.
VIEW_MODES = {
    "cards": ("episodes", 55, 507),
    "holo": ("movies", 54, 51),
    "fullscreen": ("movies", 502, 504),
    "compact": ("videos", 50, 50),
    "magazine": ("movies", 500, 503),
}


def view_setting():
    value = setting_str("view", "auto")
    return value if value in VIEWS else "auto"


def list_content(view):
    return VIEW_MODES[view][0] if view in VIEW_MODES else "videos"


def skin_family():
    """„estuary“, „silvo“ (Aeon Nox: SiLVO und Skins darauf) oder None (Ansicht bleibt beim Skin)."""
    skin = xbmc.getSkinDir() or ""
    if skin == "skin.estuary":
        return "estuary"
    try:
        import xbmcvfs
        if (xbmcvfs.exists("special://skin/16x9/View_507_BigList.xml")
                and xbmcvfs.exists("special://skin/16x9/View_503_Wall.xml")):
            return "silvo"
    except Exception:  # noqa: BLE001
        pass
    return None


def apply_view(view):
    """Passende Skin-Ansicht einstellen (nur für bekannte Skins, sonst entscheidet der Skin)."""
    family = skin_family() if view in VIEW_MODES else None
    if family:
        xbmc.executebuiltin("Container.SetViewMode(%d)" % VIEW_MODES[view][1 if family == "estuary" else 2])
    return family


def date_added(timestamp):
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(timestamp or 0))
