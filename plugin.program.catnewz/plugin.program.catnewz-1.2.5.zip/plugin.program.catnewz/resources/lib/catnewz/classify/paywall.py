# -*- coding: utf-8 -*-
"""Port von ``PaywallDetector``.

Stufe 1+2 (``is_paywalled``): Hart-Paywall-Hosts, Plus-Marker in URL und Titel.
Stufe 3 (``paywall_in_html``): schema.org ``isAccessibleForFree: false`` und
eindeutige CSS-/Text-Marker im Seiten-HTML.

Die Marker sind in Kotlin plain ``Regex(...)`` (teils mit IGNORE_CASE) und
laufen auf dem ROHEN Link/Titel (nicht normalisiert).
"""
from ._rules import as_text, cached, is_blank, plain_rx


class _Rules(object):
    __slots__ = ("hosts", "url", "title", "html")


def _build(r):
    p = r["paywall"]
    out = _Rules()
    out.hosts = tuple(p["hardPaywallHosts"])
    out.url = tuple(plain_rx(s) for s in p["urlMarkers"])
    out.title = tuple(plain_rx(s) for s in p["titleMarkers"])
    out.html = tuple(plain_rx(s) for s in p["htmlMarkers"])
    return out


def _remove_prefix(text, prefix):
    # str.removeprefix gibt es erst ab Python 3.9
    return text[len(prefix):] if text.startswith(prefix) else text


def is_paywalled(link, title):
    """``PaywallDetector.byLinkOrTitle(link, title)``."""
    r = cached(("paywall",), _build)
    link = as_text(link)
    title = as_text(title)
    host = link.lower()
    host = _remove_prefix(host, "https://")
    host = _remove_prefix(host, "http://")
    host = _remove_prefix(host, "www.")
    host = host.split("/", 1)[0]  # substringBefore('/')
    for h in r.hosts:
        if host == h or host.endswith("." + h):
            return True
    for rx in r.url:
        if rx.search(link) is not None:
            return True
    for rx in r.title:
        if rx.search(title) is not None:
            return True
    return False


def paywall_in_html(html):
    """``PaywallDetector.inHtml(html)``."""
    html = as_text(html)
    if is_blank(html):
        return False
    r = cached(("paywall",), _build)
    for rx in r.html:
        if rx.search(html) is not None:
            return True
    return False
