# -*- coding: utf-8 -*-
"""Port von ``SentimentEngine`` + ``Lexicons`` (Regeln aus rules.json).

Entscheidungslogik in Kotlin-Reihenfolge:
 1. FATAL im Titel                         → -0.9  (NEGATIV, schlägt alles)
 2. HAPPY OUTCOME im Titel, kein Versuchs-/Widerspruchs-Marker → +0.8
 3. SCHWERE NOTLAGE im Titel: Happy End im Snippet (ohne Marker) → +0.55,
    sonst -0.75 – außer bei Vermittlungsaufruf im Titel (dann weiter mit 4.)
 4. Gewichtetes Scoring (Titel 2x, Snippet 1x) + abgeschwächte Snippet-Signale
    (Fatal -0.35, Notlage -0.25, Happy +0.3), Titel-Dominanz
 5. Ratgeber/Wissen → Score * 0.35
 6. Vermittlungsaufruf im Titel → Score mindestens 0
 7. Schwellen: >= +0.18 POSITIVE, <= -0.18 NEGATIVE, sonst NEUTRAL

Alle Rechenschritte laufen in float32 (Kotlin ``Float``) – ``f32`` nach jeder
Operation –, damit Grenzfälle an den Schwellen bitgenau gleich ausfallen.
"""
from ._rules import any_match, as_text, cached, coerce_in, f32, rules, rx_list, select, weighted_list
from .text import normalize

POSITIVE = "POSITIVE"
NEUTRAL = "NEUTRAL"
NEGATIVE = "NEGATIVE"

# Konstanten aus SentimentEngine.analyze (Programmlogik, nicht in rules.json)
_FATAL_TITLE = f32(-0.9)
_HAPPY_TITLE = f32(0.8)
_DISTRESS_HAPPY_SNIPPET = f32(0.55)
_DISTRESS = f32(-0.75)
_TWO = f32(2.0)
_THREE = f32(3.0)
_SNIPPET_FATAL = f32(0.35)
_SNIPPET_DISTRESS = f32(0.25)
_SNIPPET_HAPPY = f32(0.3)
_TITLE_DOMINANCE = f32(-0.3)
_HALF = f32(0.5)
_NEUTRALIZER_DAMPING = f32(0.35)
_ONE = f32(1.0)
_MINUS_ONE = f32(-1.0)


class _Lexicon(object):
    __slots__ = ("fatal", "severe_distress", "happy_outcome", "positive", "negative",
                 "neutralizers", "attempt_markers", "adoption_appeal")

    def __init__(self, spec):
        self.fatal = rx_list(spec["fatal"])
        self.severe_distress = rx_list(spec["severeDistress"])
        self.happy_outcome = rx_list(spec["happyOutcome"])
        self.positive = weighted_list(spec["positive"])
        self.negative = weighted_list(spec["negative"])
        self.neutralizers = rx_list(spec["neutralizers"])
        self.attempt_markers = rx_list(spec["attemptMarkers"])
        self.adoption_appeal = rx_list(spec["adoptionAppeal"])


def _thresholds(r):
    s = r["sentiment"]
    return f32(s["positiveThreshold"]), f32(s["negativeThreshold"])


_by_language = {}


def _lexicon(language):
    """``Lexicons.forLanguage(language)`` (lowercase, Fallback Englisch)."""
    lex = _by_language.get(language)
    if lex is None:
        _, key = select(rules()["sentiment"]["lexiconFor"], language)
        lex = cached(("sentiment", key), lambda r: _Lexicon(r["sentiment"]["lexicons"][key]))
        _by_language[language] = lex
    return lex


def _weighted_score(lex, text):
    if text == "":  # normalisiert: isBlank() ⇔ leer
        return 0.0
    score = 0.0
    for rx, weight in lex.positive:
        if rx.search(text) is not None:
            score = f32(score + weight)
    for rx, weight in lex.negative:
        if rx.search(text) is not None:
            score = f32(score - weight)
    return coerce_in(score, _MINUS_ONE, _ONE)


def _result(score):
    pos, neg = cached(("sentiment-thresholds",), _thresholds)
    if score >= pos:
        return score, POSITIVE
    if score <= neg:
        return score, NEGATIVE
    return score, NEUTRAL


def analyze_sentiment(title, snippet, language):
    """``SentimentEngine.forLanguage(language).analyze(title, snippet)``.

    Liefert ``(score, sentiment)`` – score als float (Wert des Kotlin-Floats),
    sentiment ``"POSITIVE"``/``"NEUTRAL"``/``"NEGATIVE"``.
    """
    lex = _lexicon(as_text(language))
    n_title = normalize(as_text(title))
    n_snippet = normalize(as_text(snippet))
    full_text = n_title if n_snippet == "" else n_title + " " + n_snippet

    fatal_in_title = any_match(lex.fatal, n_title)
    happy_in_title = any_match(lex.happy_outcome, n_title)
    distress_in_title = any_match(lex.severe_distress, n_title)
    appeal_in_title = any_match(lex.adoption_appeal, n_title)

    # 1. Tödlicher Ausgang im Titel schlägt alles.
    if fatal_in_title:
        return _result(_FATAL_TITLE)

    # 2. Happy End im Titel – außer Versuch/Widerspruch.
    blocked = any_match(lex.attempt_markers, full_text)
    if happy_in_title and not blocked:
        return _result(_HAPPY_TITLE)

    # 3. Schwere Notlage ohne Happy End.
    if distress_in_title:
        happy_in_snippet = any_match(lex.happy_outcome, n_snippet)
        if happy_in_snippet and not blocked:
            return _result(_DISTRESS_HAPPY_SNIPPET)
        if not appeal_in_title:
            return _result(_DISTRESS)

    # 4. Gewichtetes Scoring.
    title_score = _weighted_score(lex, n_title)
    snippet_score = _weighted_score(lex, n_snippet)
    combined = f32(f32(f32(title_score * _TWO) + snippet_score) / _THREE)

    if n_snippet != "":
        if any_match(lex.fatal, n_snippet):
            combined = f32(combined - _SNIPPET_FATAL)
        if any_match(lex.severe_distress, n_snippet):
            combined = f32(combined - _SNIPPET_DISTRESS)
        if not blocked and any_match(lex.happy_outcome, n_snippet):
            combined = f32(combined + _SNIPPET_HAPPY)

    # Titel-Dominanz
    if title_score <= _TITLE_DOMINANCE and combined > 0.0:
        combined = f32(title_score * _HALF)

    # 5. Ratgeber/Wissen/Quiz → Richtung Neutral.
    if any_match(lex.neutralizers, full_text):
        combined = f32(combined * _NEUTRALIZER_DAMPING)

    # 6. Vermittlungsaufrufe sind nie negativ.
    if appeal_in_title and combined < 0.0:
        combined = 0.0

    return _result(coerce_in(combined, _MINUS_ONE, _ONE))
