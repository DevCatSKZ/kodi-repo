# -*- coding: utf-8 -*-
"""Port von ``TextNormalizer``: HTML-Entities dekodieren, unsichtbare Zeichen
und URLs entfernen, Kleinschreibung, Whitespace bündeln, trimmen.

Die Schrittfolge kommt aus rules.json (``normalizer.ops``) und entspricht der
Aufrufkette in ``TextNormalizer.normalize``.
"""
import re

from functools import lru_cache

from ._rules import KOTLIN_WS, cached

_SURROGATE = re.compile("[\ud800-\udfff]")

_LITERAL, _REGEX, _ENTITY, _LOWER, _TRIM = range(5)


def _entity(match):
    # Kotlin: groupValues[1].toIntOrNull(); 32..65535 → Zeichen, sonst " "
    try:
        code = int(match.group(1))
    except ValueError:
        return " "
    if 32 <= code <= 65535:
        return chr(code)
    return " "


def _build(rules):
    spec = rules["normalizer"]
    # Regex("...") ohne Option → keine Flags
    regexes = {name: re.compile(src) for name, src in spec["regex"].items()}
    steps = []
    for op in spec["ops"]:
        kind = op[0]
        if kind == "literal":
            steps.append((_LITERAL, op[1], op[2]))
        elif kind == "regex":
            steps.append((_REGEX, regexes[op[1]], op[2]))
        elif kind == "numericEntity":
            steps.append((_ENTITY, regexes["numericEntity"], None))
        elif kind == "lowercase":
            steps.append((_LOWER, None, None))
        elif kind == "trim":
            steps.append((_TRIM, None, None))
        else:
            raise ValueError("rules.json: unknown normalizer op %r" % (kind,))
    return tuple(steps)


@lru_cache(maxsize=2048)
def _normalize(text):
    steps = cached(("normalizer",), _build)
    for kind, a, b in steps:
        if kind == _LITERAL:
            text = text.replace(a, b)
        elif kind == _REGEX:
            text = a.sub(b, text)
        elif kind == _ENTITY:
            text = a.sub(_entity, text)
            if _SURROGATE.search(text) is not None:
                # Kotlin-Strings sind UTF-16: "&#55357;&#56832;" ergibt dort ein
                # gültiges Surrogat-Paar (= 1 Codepoint für die Regex-Engine).
                text = text.encode("utf-16-le", "surrogatepass").decode("utf-16-le", "surrogatepass")
        elif kind == _LOWER:
            text = text.lower()
        else:
            text = text.strip(KOTLIN_WS)
    return text


def normalize(text):
    """``TextNormalizer.normalize(text)``."""
    if not text:
        return ""
    return _normalize(text)
