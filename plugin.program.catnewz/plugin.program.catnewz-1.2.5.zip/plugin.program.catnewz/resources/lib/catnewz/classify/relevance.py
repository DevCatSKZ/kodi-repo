# -*- coding: utf-8 -*-
"""Port von ``CatRelevance``: handelt der Artikel wirklich von Hauskatzen?

 1. Harter Ausschluss (global + sprachspezifisch) und "Katze" in
    Anführungszeichen als Spitzname → nie relevant.
 2. Katzen-Keyword im Titel → relevant.
 3. Katzenspezifische Quelle: Keyword im Snippet reicht, außer der Titel ist
    ein Meinungsstück.

Sprachauswahl wie in Kotlin per ``when (language)`` – OHNE lowercase.
"""
from ._rules import any_match, as_text, cached, plain_rx, rules, rx_list, select
from .text import normalize


class _Rules(object):
    __slots__ = ("global_exclude", "cat", "exclude", "opinion", "nickname")


_by_language = {}


def _rules_for(language):
    found = _by_language.get(language)
    if found is None:
        found = _by_language[language] = _resolve(language)
    return found


def _resolve(language):
    spec = rules()["relevance"]
    keys = []
    raw = []
    for role in ("cat", "exclude", "opinion", "quotedNickname"):
        key, value = select(spec[role], language)
        keys.append(key)
        raw.append(value)

    def build(r):
        out = _Rules()
        out.global_exclude = rx_list(r["relevance"]["globalExclude"])
        out.cat = rx_list(raw[0])
        out.exclude = rx_list(raw[1])
        out.opinion = rx_list(raw[2])
        out.nickname = plain_rx(raw[3])
        return out

    return cached(("relevance",) + tuple(keys), build)


def _texts(title, snippet):
    n_title = normalize(as_text(title))
    n_snippet = normalize(as_text(snippet))
    full = n_title if n_snippet == "" else n_title + " " + n_snippet
    return n_title, n_snippet, full


def is_relevant(title, snippet, language, cat_specific_source):
    """``CatRelevance.isRelevant(title, snippet, language, isCatSpecificSource)``."""
    r = _rules_for(as_text(language))
    n_title, n_snippet, full = _texts(title, snippet)

    # 1. Harter Ausschluss (global + sprachspezifisch)
    if any_match(r.global_exclude, full):
        return False
    if any_match(r.exclude, full):
        return False
    if r.nickname.search(n_title) is not None and \
            not any_match(r.cat, r.nickname.sub(" ", n_title)):
        return False

    # 2. Katze im Titel → relevant
    if any_match(r.cat, n_title):
        return True

    # 3. Katzenspezifische Quelle: Beschreibung zählt, Meinungsstücke nicht
    if cat_specific_source and any_match(r.cat, n_snippet) and not any_match(r.opinion, n_title):
        return True
    return False


def is_hard_excluded(title, snippet, language):
    """``CatRelevance.isHardExcluded`` – nur der harte Ausschluss (Bestands-Bereinigung)."""
    r = _rules_for(as_text(language))
    _, _, full = _texts(title, snippet)
    return any_match(r.global_exclude, full) or any_match(r.exclude, full)
