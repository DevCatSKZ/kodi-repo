# -*- coding: utf-8 -*-
"""Duplikat-Erkennung: dieselbe Meldung aus mehreren Quellen nur einmal.
Gleicher Link oder sehr ähnliche Titel (Wortmengen nach Normalisierung,
Stoppwörtern und einfachem Stemming). Mit Wort-Index statt Vergleich jeder
mit jedem – auch auf einem Raspberry Pi 3 flott."""
import re
import unicodedata

_STOP = set("""
der die das den dem des ein eine einer einen einem und oder aber mit von vom zum zur im in am an auf aus
für fuer bei nach vor über ueber unter durch ist sind war wird werden wurde hat haben sich nicht noch auch
nur wie was wer wo so als dass es er sie ihr ihre sein seine man jetzt hier dort mehr sehr ganz schon
the a an and or but with from for of to in on at by is are was were be been has have had it its this that
these those as not no new how why what when who will can after before over into out up
el la los las un una y o con de del en por para es son que se su sus al lo
le la les un une et ou avec de du des en au aux pour par est sont qui que se sa son ses ce cette
il lo la i gli le un una e o con di del della dei in per da su che si suo sua è sono al alla
katze katzen kater kätzchen katzchen cat cats kitten kittens gato gatos gata chat chats chaton gatto gatti
""".split())

_SUFFIXES = ("innen", "ungen", "chen", "lein", "ern", "en", "er", "es", "e", "s", "n")
_WORD = re.compile(r"[a-z0-9]+")
_SOURCE_SUFFIX = re.compile(r"\s+[-–—|]\s+[^-–—|]{2,48}$")


def _fold(text):
    text = (text or "").lower().replace("ß", "ss")
    decomposed = unicodedata.normalize("NFD", text)
    return "".join(ch for ch in decomposed if unicodedata.category(ch) != "Mn")


def _stem(token):
    if len(token) < 5:
        return token
    for suffix in _SUFFIXES:
        if token.endswith(suffix) and len(token) - len(suffix) >= 4:
            return token[: -len(suffix)]
    return token


def tokens(title):
    text = _SOURCE_SUFFIX.sub("", _fold(title))
    return frozenset(_stem(word) for word in _WORD.findall(text) if len(word) >= 3 and word not in _STOP)


def snippet_key(snippet):
    """Schluessel fuer "gleicher Teaser": dieselbe Pressemeldung erscheint oft mit
    verschiedenen Titeln, aber identischem Anfangstext. None = Teaser zu kurz."""
    text = " ".join(_WORD.findall(_fold(snippet)))
    return text[:90] if len(text) >= 60 else None


_NUMBER = re.compile(r"^\d+$")
_YEAR = re.compile(r"^(19|20)\d{2}$")
EVENT_MIN_SHARED = 5
EVENT_WINDOW = 72 * 3600


def body_tokens(title, snippet):
    return tokens("%s. %s" % (title, snippet))


def same_event(a, b):
    """Dieselbe Meldung mit eigenem Titel und Text (z.B. Polizeibericht, den mehrere Zeitungen
    umschreiben): viele gemeinsame Woerter aus Titel + Teaser, ohne widerspruechliche Zahlen.
    Jahreszahlen zaehlen nicht als Beleg."""
    shared = [t for t in a if t in b and not _YEAR.match(t)]
    if len(shared) < EVENT_MIN_SHARED:
        return False
    numbers_a = [t for t in a if _NUMBER.match(t) and not _YEAR.match(t)]
    numbers_b = [t for t in b if _NUMBER.match(t) and not _YEAR.match(t)]
    if numbers_a and numbers_b and not any(t in numbers_b for t in numbers_a):
        return False
    containment = len(shared) / float(min(len(a), len(b)))
    jaccard = len(shared) / float(len(a | b))
    return containment >= 0.5 and jaccard >= 0.3


def normalize_link(link):
    return (link or "").lower().strip().split("?", 1)[0].split("#", 1)[0].rstrip("/")


def similar(a, b):
    if len(a) < 3 or len(b) < 3:
        return False
    common = len(a & b)
    if common < 3:
        return False
    jaccard = common / float(len(a | b))
    containment = common / float(min(len(a), len(b)))
    return jaccard >= 0.55 or (containment >= 0.8 and common >= 4)


class Session(object):
    """Bekannte Meldungen; ``check_and_add`` liefert die ID des Originals oder None."""

    def __init__(self):
        self._links = {}
        self._entries = []  # (tokens, id)
        self._index = {}    # token -> [positions]
        self._snippets = {}  # Teaser-Schluessel -> (id, Titel-Woerter)
        self._bodies = []    # (Titel+Teaser-Woerter, id, Zeit)
        self._body_index = {}  # Wort -> [Positionen in _bodies]

    def add(self, title, link, article_id, snippet="", published=0):
        nlink = normalize_link(link)
        if nlink:
            self._links.setdefault(nlink, article_id)
        toks = tokens(title)
        key = snippet_key(snippet)
        if key:
            self._snippets.setdefault(key, (article_id, toks))
        if snippet and published:
            body = body_tokens(title, snippet)
            position = len(self._bodies)
            self._bodies.append((body, article_id, published))
            for token in body:
                self._body_index.setdefault(token, []).append(position)
        position = len(self._entries)
        self._entries.append((toks, article_id))
        for token in toks:
            self._index.setdefault(token, []).append(position)

    def find(self, title, link, snippet="", published=0):
        nlink = normalize_link(link)
        if nlink and nlink in self._links:
            return self._links[nlink]
        toks = tokens(title)
        key = snippet_key(snippet)
        if key in self._snippets:
            other_id, other_toks = self._snippets[key]
            if toks & other_toks:  # Schutz vor Standardtexten bei fremden Titeln
                return other_id
        candidates = set()
        for token in toks:
            candidates.update(self._index.get(token, ()))
        for position in sorted(candidates):
            other, other_id = self._entries[position]
            if similar(toks, other):
                return other_id
        if snippet and published:
            body = body_tokens(title, snippet)
            positions = set()
            for token in body:
                positions.update(self._body_index.get(token, ()))
            for position in sorted(positions):
                other, other_id, other_time = self._bodies[position]
                if abs(other_time - published) <= EVENT_WINDOW and same_event(body, other):
                    return other_id
        return None

    def check_and_add(self, title, link, article_id, snippet="", published=0):
        original = self.find(title, link, snippet, published)
        if original is None:
            self.add(title, link, article_id, snippet, published)
        return original
