# -*- coding: utf-8 -*-
"""Lokaler Bild-Cache: Das Add-on lädt Artikelbilder selbst, prüft sie am Dateikopf und
gibt Kodi nur noch lokale Dateien. Kodis eigener Bildlader scheitert still an Servern mit
falschem oder fehlendem Content-Type, abgelehntem Kodi-User-Agent oder zu langsamen Antworten –
dann blieb auf der Kachel nur das Logo. Bing-Vorschaubilder (schon in Zielgröße) bleiben remote."""
import os
import time
from concurrent.futures import ThreadPoolExecutor

from catnewz import http, rss

FOLDER = "images"
EXTENSIONS = (".jpg", ".png", ".webp", ".gif")
MAX_BYTES = 1536 * 1024
MIN_BYTES = 800
RETRY = 86400
WORKERS = 4
ACCEPT = "image/jpeg,image/png,image/webp,image/gif;q=0.9,image/*;q=0.5"


def _dir(folder=None):
    if not folder:
        from catnewz import kodi
        folder = kodi.profile_path()
    return os.path.join(folder, FOLDER)


def sniff(body):
    """Dateiendung nach den ersten Bytes; None = kein von Kodi lesbares Bild (z.B. AVIF, HTML)."""
    head = body[:12]
    if head[:3] == b"\xff\xd8\xff":
        return ".jpg"
    if head[:8] == b"\x89PNG\r\n\x1a\n":
        return ".png"
    if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
        return ".webp"
    if head[:4] in (b"GIF8",):
        return ".gif"
    return None


def _is_bing(url):
    return rss.bing_sized(url, 1, 1) != url


def cacheable(url):
    return bool(url) and url.startswith("http") and not _is_bing(url)


def local_file(article_id, folder=None):
    base = os.path.join(_dir(folder), article_id)
    for extension in EXTENSIONS:
        if os.path.isfile(base + extension):
            return (base + extension).replace("\\", "/")
    return None


def thumb(article, width, height, folder=None):
    """Bild für Kacheln und Listen: lokale Datei, sonst Bing in Zielgröße, sonst die Adresse selbst."""
    found = local_file(article["id"], folder) if article.get("id") else None
    return found or rss.bing_sized(article.get("image"), width, height)


def _failed(article_id, url, folder):
    """Fehlschlag-Marker jünger als RETRY – nur für DIESELBE Adresse (eine neue
    Bild-Adresse der Meldung darf sofort versucht werden)."""
    marker = os.path.join(_dir(folder), article_id + ".fail")
    try:
        if time.time() - os.path.getmtime(marker) >= RETRY:
            return False
        with open(marker, "r", encoding="utf-8") as handle:
            return handle.read().strip() == url
    except OSError:
        return False


def _download(article, folder):
    target_dir = _dir(folder)
    response = http.fetch(article["image"], timeout=12, max_bytes=MAX_BYTES + 1, accept=ACCEPT,
                          headers={"Referer": article.get("link", "")} if article.get("link") else None)
    if response.status == 0:  # Netzfehler: nicht als dauerhaft kaputt merken
        return False
    extension = sniff(response.body) if response.ok else None
    base = os.path.join(target_dir, article["id"])
    if extension is None or not MIN_BYTES <= len(response.body) <= MAX_BYTES:
        with open(base + ".fail", "w", encoding="utf-8") as handle:
            handle.write(article["image"])
        return False
    with open(base + ".tmp", "wb") as handle:
        handle.write(response.body)
    os.replace(base + ".tmp", base + extension)
    return True


def sync(articles, limit=40, folder=None, should_stop=None):
    """Fehlende Bilder herunterladen (neueste zuerst) und Bilder gelöschter Meldungen entfernen.
    Gibt die Zahl der Versuche zurück (0 = nichts mehr zu tun)."""
    target_dir = _dir(folder)
    os.makedirs(target_dir, exist_ok=True)
    wanted = {}
    for article in articles:
        wanted[article["id"]] = article
    for name in os.listdir(target_dir):
        stem = name.rsplit(".", 1)[0]
        if stem not in wanted:
            try:
                os.remove(os.path.join(target_dir, name))
            except OSError:
                pass
    todo = [a for a in wanted.values()
            if cacheable(a.get("image")) and not local_file(a["id"], folder)
            and not _failed(a["id"], a.get("image"), folder)]
    todo.sort(key=lambda a: (a.get("fetched", 0), a.get("published", 0)), reverse=True)
    todo = todo[:limit]

    def work(article):
        if should_stop and should_stop():
            return False
        try:
            return _download(article, folder)
        except OSError:
            return False

    with ThreadPoolExecutor(max_workers=WORKERS) as pool:
        list(pool.map(work, todo))
    return len(todo)
