# -*- coding: utf-8 -*-
"""Catnewz-Plugin: Menüs, Listen, Lesemodus und Aktionen.

Nur Standard-Listen und -Dialoge von Kodi (plus ein eigenes, mitgeliefertes
Lese-Fenster) – funktioniert mit jedem Skin und auf jeder Plattform. Jede
Liste ist auch als Widget nutzbar, z. B.
``plugin://plugin.program.catnewz/?action=list&mood=POSITIVE``.

Filter, Sortierung und Darstellung entsprechen der App: Stimmung, Thema und
Region lassen sich kombinieren („Filter & Sortierung“ oben in jeder Liste),
Meldungen lassen sich ausblenden, Quellen an- und abschalten."""
import time
from urllib.parse import parse_qsl, urlencode

import xbmc
import xbmcgui
import xbmcplugin

from catnewz import feeds, http, images, kodi, news, reader, rss
from catnewz.kodi import L
from catnewz.store import Store

PAGE_SIZE = 50
MOODS = ("POSITIVE", "NEUTRAL", "NEGATIVE")
TOPICS = ("ADOPTION", "RESCUE", "SHELTER", "FUNNY", "KNOWLEDGE")
SORTS = (news.SORT_NEWEST, news.SORT_PUBLISHED, news.SORT_MOOD)
LIST_PARAMS = ("mood", "topic", "local", "sort", "query")
QUIET_ACTIONS = ("", "topics", "list", "noop")  # Ordner – Kodi lädt sie auch still für Widgets
DIRECTORY_ACTIONS = ("", "topics", "list")

S = {
    "all": 30000, "POSITIVE": 30001, "NEUTRAL": 30002, "NEGATIVE": 30003, "topics": 30004,
    "ADOPTION": 30005, "RESCUE": 30006, "SHELTER": 30007, "FUNNY": 30008, "KNOWLEDGE": 30009,
    "region": 30010, "saved": 30011, "history": 30012, "search": 30013, "stats": 30014,
    "refresh": 30015, "settings": 30016, "more": 30017, "new": 30018, "n_new": 30019,
    "loading": 30020, "loaded_new": 30021, "loaded_none": 30022, "load_failed": 30023,
    "nothing": 30024, "no_saved": 30025, "bookmark": 30026, "unbookmark": 30027,
    "mute_source": 30028, "less_topic": 30029, "not_cat": 30030, "fix_mood": 30031,
    "loading_article": 30032, "no_fulltext": 30033, "bookmarked": 30034, "muted": 30035,
    "hidden": 30036, "paywall": 30037, "ad": 30038, "local": 30039, "also": 30040,
    "original": 30041, "reader_hint": 30042, "search_term": 30043, "mood_set": 30044,
    "updated": 30045, "stats_week": 30046, "stats_sources": 30047, "new_since": 30049,
    "reset_muted": 30051, "reset_notcat": 30052, "cache_cleared": 30053,
    "hide": 30056, "unhide": 30057, "hidden_badge": 30058, "filter_sort": 30059, "all_topics": 30060,
    "all_regions": 30061, "topic_is": 30062, "only_region": 30063, "sort_is": 30064, "divider": 30065,
    "manage_sources": 30072, "add_source": 30073, "source_name": 30074, "source_url": 30075,
    "source_cats": 30076, "source_added": 30077, "source_empty": 30078, "remove_sources": 30079,
    "active_sources": 30080, "manage_less": 30081, "less_source": 30082, "less_notcat": 30084,
    "nothing_muted": 30085, "all_moods": 30086, "mood_is": 30087, "hidden_ok": 30096,
    "sources_saved": 30092, "region_is": 30095,
}
SORT_LABELS = {news.SORT_NEWEST: 30116, news.SORT_PUBLISHED: 30117, news.SORT_MOOD: 30118}

MENU_ICONS = {
    "all": "all.png", "POSITIVE": "positive.png", "NEUTRAL": "neutral.png", "NEGATIVE": "negative.png",
    "topics": "topics.png", "ADOPTION": "adoption.png", "RESCUE": "rescue.png", "SHELTER": "shelter.png",
    "FUNNY": "funny.png", "KNOWLEDGE": "knowledge.png", "region": "region.png", "saved": "saved.png",
    "history": "history.png", "search": "search.png", "stats": "stats.png", "refresh": "refresh.png",
    "settings": "settings.png",
}


class Plugin(object):
    def __init__(self, argv):
        self.base = argv[0]
        self.handle = int(argv[1]) if len(argv) > 1 and argv[1].lstrip("-").isdigit() else -1
        self.params = dict(parse_qsl(argv[2][1:])) if len(argv) > 2 and argv[2] else {}
        self.config = kodi.config()
        self.store = Store(kodi.profile_path())
        news.ensure_moods(self.store, self.config.language)
        self.backdrop = kodi.backdrop()
        self.show_images = kodi.setting_bool("show_images", True)
        self.relative_time = kodi.setting_bool("relative_time", True)

    # ------------------------------------------------------------ Hilfen

    def url(self, **params):
        return "%s?%s" % (self.base, urlencode(params))

    def run_url(self, **params):
        return "RunPlugin(%s)" % self.url(**params)

    def when(self, timestamp):
        return kodi.time_label(timestamp, self.relative_time)

    def ensure_fresh(self, force=False):
        """Bei Bedarf aktualisieren (alter Stand, andere Sprache/Region)."""
        data = self.store.data
        age = time.time() - data.get("last_refresh", 0)
        cache_seconds = max(5, kodi.setting_int("cache_minutes", 30)) * 60
        stale = (force or not data["articles"] or age > cache_seconds
                 or data.get("language") != self.config.language
                 or data.get("region", "") != self.config.region)
        if not stale:
            return None
        if not self.store.acquire_lock():
            # Der Hintergrunddienst lädt gerade – kurz warten, dann dessen Stand nehmen.
            for _ in range(40):
                if not self.store.is_locked():
                    break
                xbmc.sleep(250)
            self.store.reload()
            return None
        progress = xbmcgui.DialogProgressBG()
        progress.create("Catnewz", L(S["loading"]))
        try:
            def report(done, total):
                progress.update(int(done * 100 / max(1, total)), "Catnewz", L(S["loading"]))
            new_count, ok, _total = news.refresh(self.store, self.config, report)
        except Exception as error:  # noqa: BLE001 – Liste trotzdem zeigen
            kodi.log("Aktualisierung fehlgeschlagen: %r" % error, xbmc.LOGWARNING)
            new_count, ok = 0, 0
        finally:
            progress.close()
            self.store.release_lock()
        if not ok:
            kodi.notify(L(S["load_failed"]))
        return new_count

    def folder(self, label, url, icon, plot="", is_folder=True, context=None):
        item = xbmcgui.ListItem(label=label, offscreen=True)
        art = kodi.media(MENU_ICONS[icon]) if icon in MENU_ICONS else kodi.asset("icon.png")
        item.setArt({"icon": art, "thumb": art, "fanart": self.backdrop})
        if plot:
            _set_info(item, title=label, plot=plot)
        if context:
            item.addContextMenuItems(context)
        if not is_folder:
            # Aktions-Eintrag, kein Abspielen: ohne das wartet Kodi auf setResolvedUrl und zeigt
            # ein Busy-Fenster, das Dialoge und Container.Update der Aktion blockiert (Widgets).
            item.setProperty("IsPlayable", "false")
        return url, item, is_folder

    @staticmethod
    def show_list(target, replace=False):
        """Liste öffnen. Im Plugin-Fenster ersetzt/aktualisiert Kodi den Ordner; aus einem Widget auf
        dem Startbildschirm gibt es keinen Ordner zum Ersetzen (Kodi bliebe im Busy-Fenster hängen):
        dann in einem eigenen Fenster öffnen, „Zurück“ führt zum Startbildschirm."""
        if xbmc.getCondVisibility("Window.IsMedia"):
            xbmc.executebuiltin("Container.Update(%s%s)" % (target, ",replace" if replace else ""))
        else:
            xbmc.executebuiltin("ActivateWindow(videos,%s,return)" % target)

    def finish(self, items, content="files", sort=False, view=None):
        if items:
            xbmcplugin.addDirectoryItems(self.handle, items, len(items))
        xbmcplugin.setContent(self.handle, content)
        try:  # Hintergrund für das ganze Verzeichnis (u. a. den „..“-Eintrag, je nach Skin)
            xbmcplugin.setPluginFanart(self.handle, self.backdrop)
        except (AttributeError, TypeError, RuntimeError):
            pass
        if sort:
            # Masken: eigene Beschriftung (%L, mit Stimmungspunkt und NEU) statt Kodis
            # Standard „Titel“ (%T); rechts die Quelle (%U = Studio).
            for method in (xbmcplugin.SORT_METHOD_UNSORTED, xbmcplugin.SORT_METHOD_DATE,
                           xbmcplugin.SORT_METHOD_DATEADDED, xbmcplugin.SORT_METHOD_TITLE):
                xbmcplugin.addSortMethod(self.handle, method, labelMask="%L", label2Mask="%U")
        xbmcplugin.endOfDirectory(self.handle, succeeded=True, cacheToDisc=False)
        if view:
            kodi.apply_view(view)

    def mark_stale(self):
        """Quellen geändert → beim nächsten Öffnen neu laden."""
        self.store.data["last_refresh"] = 0
        self.store.save_articles()

    # ------------------------------------------------------------ Menüs

    def root(self):
        self.ensure_fresh()
        boundary = self.store.touch_visit()
        visible = news.visible(self.store, self.config)
        new_count = sum(1 for a in visible if boundary and a.get("fetched", 0) > boundary)
        per_mood = {m: 0 for m in MOODS}
        for article in visible:
            per_mood[self.store.mood(article)] = per_mood.get(self.store.mood(article), 0) + 1
        updated = self.when(self.store.data.get("last_refresh", 0))

        def count_label(key, count, extra=""):
            return "%s  [COLOR %s](%d)[/COLOR]%s" % (L(S[key]), kodi.MUTED, count, extra)

        items = [self.folder(L(30220), self.url(action="home"), "all", is_folder=False)]
        new_suffix = "  [COLOR %s]%s[/COLOR]" % (kodi.ACCENT, L(S["n_new"]) % new_count) if new_count else ""
        items.append(self.folder(count_label("all", len(visible), new_suffix), self.url(action="list"), "all",
                                 L(S["updated"]) % updated))
        for mood in MOODS:
            label = "[COLOR %s]%s[/COLOR]  [COLOR %s](%d)[/COLOR]" % (
                kodi.MOOD_COLORS[mood], L(S[mood]), kodi.MUTED, per_mood.get(mood, 0))
            items.append(self.folder(label, self.url(action="list", mood=mood), mood))
        items.append(self.folder(L(S["topics"]), self.url(action="topics"), "topics"))
        if self.config.region:
            local = sum(1 for a in visible if a.get("local"))
            label = "%s  [COLOR %s](%d)[/COLOR]" % (L(S["region"]) % self.config.region, kodi.MUTED, local)
            items.append(self.folder(label, self.url(action="list", local="1"), "region"))
        items.append(self.folder(count_label("saved", len(self.store.user["bookmarks"])),
                                 self.url(action="list", saved="1"), "saved"))
        items.append(self.folder(L(S["history"]), self.url(action="list", history="1"), "history"))
        items.append(self.folder(L(S["search"]), self.url(action="search"), "search", is_folder=False))
        items.append(self.folder(L(S["stats"]), self.url(action="stats"), "stats", is_folder=False))
        items.append(self.folder(L(S["refresh"]), self.url(action="refresh"), "refresh",
                                 L(S["updated"]) % updated, is_folder=False))
        items.append(self.folder(L(S["settings"]), self.url(action="settings"), "settings", is_folder=False))
        self.finish(items)

    def topics(self):
        self.ensure_fresh()
        items = []
        for topic in TOPICS:
            count = len(news.visible(self.store, self.config, topic=topic))
            label = "%s  [COLOR %s](%d)[/COLOR]" % (L(S[topic]), kodi.MUTED, count)
            items.append(self.folder(label, self.url(action="list", topic=topic), topic))
        self.finish(items)

    # ------------------------------------------------------------ Listen

    def list_params(self, **changes):
        params = dict((k, v) for k, v in self.params.items() if k in LIST_PARAMS and v)
        for key, value in changes.items():
            if value:
                params[key] = value
            else:
                params.pop(key, None)
        return params

    def current_sort(self):
        sort = self.params.get("sort")
        return sort if sort in SORTS else self.config.sort

    def article_list(self):
        params = self.params
        page = int(params.get("page", "0") or 0)
        saved, history = params.get("saved") == "1", params.get("history") == "1"
        personal = saved or history
        if not personal:
            self.ensure_fresh()
        boundary = self.store.user.get("visit_boundary", 0)
        sort = self.current_sort()
        if saved:
            articles = news.sort_articles(list(self.store.user["bookmarks"].values()),
                                          sort if sort == news.SORT_MOOD else news.SORT_PUBLISHED, self.store)
        elif history:
            read = self.store.user["read"]
            articles = [self.store.article(aid) for aid, _ in sorted(read.items(), key=lambda kv: kv[1], reverse=True)]
            articles = [a for a in articles if a]
            if sort == news.SORT_MOOD:
                articles = news.sort_articles(articles, sort, self.store)
        else:
            self.config.sort = sort
            articles = news.visible(self.store, self.config, mood=params.get("mood"), topic=params.get("topic"),
                                    local=params.get("local") == "1", query=params.get("query"))
        if not articles:
            kodi.notify(L(S["no_saved"]) if saved else L(S["nothing"]))
        start = page * PAGE_SIZE
        items = []
        if not personal and page == 0:
            items.append(self.filter_item())
        divider_at = -1
        if not personal and sort == news.SORT_NEWEST and boundary and kodi.setting_bool("new_divider", True):
            new = [i for i, a in enumerate(articles) if a.get("fetched", 0) > boundary]
            if new and len(new) < len(articles):
                divider_at = new[-1] + 1
        for index, article in enumerate(articles[start:start + PAGE_SIZE], start):
            if index == divider_at:
                items.append(self.divider_item(boundary))
            items.append(self.article_item(article, boundary))
        if len(articles) > start + PAGE_SIZE:
            more = dict(params)
            more["page"] = str(page + 1)
            items.append(self.folder("%s  [COLOR %s](%d)[/COLOR]" % (
                L(S["more"]), kodi.MUTED, len(articles) - start - PAGE_SIZE), self.url(**more), "all"))
        view = kodi.view_setting()
        self.finish(items, content=kodi.list_content(view), sort=True, view=view)

    def filter_summary(self):
        params = self.params
        parts = [L(S[params["mood"]]) if params.get("mood") in MOODS else L(S["all_moods"]),
                 L(S[params["topic"]]) if params.get("topic") in TOPICS else L(S["all_topics"])]
        if self.config.region:
            parts.append(L(S["only_region"]) % self.config.region if params.get("local") == "1"
                         else L(S["all_regions"]))
        parts.append(L(SORT_LABELS[self.current_sort()]))
        return " · ".join(parts)

    def filter_item(self):
        label = "[COLOR %s]%s[/COLOR]  [COLOR %s]%s[/COLOR]" % (kodi.ACCENT, L(S["filter_sort"]), kodi.MUTED,
                                                              self.filter_summary())
        url = self.url(action="filter", **self.list_params())
        url_item, item, _ = self.folder(label, url, "settings", plot=self.filter_summary(), is_folder=False)
        item.setProperty("SpecialSort", "top")  # bleibt bei jeder Kodi-Sortierung oben
        return url_item, item, False

    def divider_item(self, boundary):
        label = "[COLOR %s]────  %s  ────[/COLOR]" % (kodi.ACCENT, L(S["divider"]) % self.when(boundary))
        item = xbmcgui.ListItem(label=label, offscreen=True)
        item.setProperty("IsPlayable", "false")
        art = kodi.media("history.png")
        item.setArt({"icon": art, "thumb": art, "fanart": self.backdrop})
        _set_info(item, title=label, plot=label, date_added=kodi.date_added(boundary), premiered=boundary)
        return self.url(action="noop"), item, False

    def article_item(self, article, boundary):
        mood = self.store.mood(article)
        aid = article["id"]
        read = self.store.is_read(aid)
        is_new = bool(boundary) and article.get("fetched", 0) > boundary and not read
        prefix = "[COLOR %s]•[/COLOR] " % kodi.MOOD_COLORS.get(mood, kodi.GOLD)
        if is_new:
            prefix += "[COLOR %s][B]%s[/B][/COLOR] " % (kodi.ACCENT, L(S["new"]))
        if self.store.is_hidden(aid):
            prefix += "[COLOR %s]%s[/COLOR] " % (kodi.MUTED, L(S["hidden_badge"]))
        title = "[COLOR %s]%s[/COLOR]" % (kodi.MUTED, article["title"]) if read else article["title"]
        item = xbmcgui.ListItem(label=prefix + title,
                                label2="%s · %s" % (article.get("source", ""), self.when(article.get("published"))),
                                offscreen=True)
        if self.show_images:
            thumb = images.thumb(article, 640, 360) or kodi.placeholder(mood)
        else:  # Textliste wie in der App: nur das Stimmungs-Symbol
            thumb = kodi.media(MENU_ICONS[mood])
        # Hintergrund immer Catnewz (Logo + Aurora, im Skin bewegt); das Artikelbild ist
        # oft klein und wirkt als Vollbild unscharf – es bleibt Vorschaubild.
        item.setArt({"thumb": thumb, "icon": thumb, "landscape": thumb, "poster": thumb, "fanart": self.backdrop})
        _set_info(item, title=article["title"], plot=self.plot(article, mood, is_new),
                  date_added=kodi.date_added(article.get("fetched")), premiered=article.get("published"),
                  playcount=1 if read else 0, studio=article.get("source", ""))
        item.setProperty("IsPlayable", "false")
        item.addContextMenuItems(self.context_menu(article))
        return self.url(action="read", id=aid), item, False

    def plot(self, article, mood, is_new):
        badges = []
        if is_new:
            badges.append("[COLOR %s]%s[/COLOR]" % (kodi.ACCENT, L(S["new"])))
        if article.get("topic"):
            badges.append("[COLOR %s]%s[/COLOR]" % (kodi.ACCENT if article["topic"] == "ADOPTION" else kodi.VIOLET,
                                                    L(S[article["topic"]])))
        if article.get("local"):
            badges.append("[COLOR %s]%s[/COLOR]" % (kodi.GOLD, L(S["local"])))
        if article.get("paywall"):
            badges.append("[COLOR FFFF6B7A]%s[/COLOR]" % L(S["paywall"]))
        if self.store.is_hidden(article["id"]):
            badges.append("[COLOR %s]%s[/COLOR]" % (kodi.MUTED, L(S["hidden_badge"])))
        lines = ["[B]%s[/B]" % article["title"]]
        if article.get("snippet"):
            lines.append(article["snippet"])
        lines.append("")
        lines.append("[COLOR %s]%s · %s[/COLOR]" % (kodi.MUTED, article.get("source", ""),
                                                    self.when(article.get("published"))))
        lines.append("[COLOR %s]• %s[/COLOR]%s" % (kodi.MOOD_COLORS.get(mood), L(S[mood]),
                                                       ("   " + " · ".join(badges)) if badges else ""))
        return "[CR]".join(lines)

    def context_menu(self, article):
        aid = article["id"]
        menu = []
        if self.store.is_bookmarked(aid):
            menu.append((L(S["unbookmark"]), self.run_url(action="bookmark", id=aid, on="0")))
        else:
            menu.append((L(S["bookmark"]), self.run_url(action="bookmark", id=aid, on="1")))
        if self.store.is_hidden(aid):
            menu.append((L(S["unhide"]), self.run_url(action="hide", id=aid, on="0")))
        else:
            menu.append((L(S["hide"]), self.run_url(action="hide", id=aid, on="1")))
        if article.get("source"):
            menu.append((L(S["mute_source"]) % article["source"], self.run_url(action="mute_source", id=aid)))
        if article.get("topic"):
            menu.append((L(S["less_topic"]) % L(S[article["topic"]]), self.run_url(action="mute_topic", id=aid)))
        menu.append((L(S["not_cat"]), self.run_url(action="not_cat", id=aid)))
        menu.append((L(S["fix_mood"]), self.run_url(action="mood", id=aid)))
        menu.append((L(S["refresh"]), self.run_url(action="refresh")))
        return menu

    # ------------------------------------------------------------ Filter & Sortierung

    def act_filter(self):
        """Stimmung, Thema, Region und Sortierung der Liste umstellen (wie die Chips der App)."""
        dialog = xbmcgui.Dialog()
        params = self.params
        current_mood = params.get("mood") if params.get("mood") in MOODS else ""
        current_topic = params.get("topic") if params.get("topic") in TOPICS else ""
        rows = [("mood", L(S["mood_is"]) % (L(S[current_mood]) if current_mood else L(S["all_moods"]))),
                ("topic", L(S["topic_is"]) % (L(S[current_topic]) if current_topic else L(S["all_topics"])))]
        if self.config.region:
            rows.append(("local", L(S["region_is"]) % (
                L(S["only_region"]) % self.config.region if params.get("local") == "1" else L(S["all_regions"]))))
        rows.append(("sort", L(S["sort_is"]) % L(SORT_LABELS[self.current_sort()])))
        choice = dialog.select(L(S["filter_sort"]), [label for _, label in rows])
        if choice < 0:
            return
        key = rows[choice][0]
        changes = {}
        if key == "mood":
            options = [""] + list(MOODS)
            picked = dialog.select(L(S["filter_sort"]), [L(S["all_moods"])] + [L(S[m]) for m in MOODS],
                                   preselect=options.index(current_mood))
            if picked < 0:
                return
            changes["mood"] = options[picked]
        elif key == "topic":
            options = [""] + list(TOPICS)
            picked = dialog.select(L(S["filter_sort"]), [L(S["all_topics"])] + [L(S[t]) for t in TOPICS],
                                   preselect=options.index(current_topic))
            if picked < 0:
                return
            changes["topic"] = options[picked]
        elif key == "local":
            changes["local"] = "" if params.get("local") == "1" else "1"
        else:
            picked = dialog.select(L(S["filter_sort"]), [L(SORT_LABELS[s]) for s in SORTS],
                                   preselect=SORTS.index(self.current_sort()))
            if picked < 0:
                return
            changes["sort"] = "" if SORTS[picked] == self.config.sort else SORTS[picked]
        target = self.url(action="list", **self.list_params(**changes))
        self.show_list(target, replace=True)

    # ------------------------------------------------------------ Lesemodus

    def read(self):
        article = self.store.article(self.params.get("id", ""))
        if not article:
            return
        content = self.store.cached_reader(article["id"])
        if content is None:
            busy = xbmcgui.DialogProgress()
            busy.create("Catnewz", L(S["loading_article"]))
            try:
                content = reader.load(article["link"])
            finally:
                busy.close()
            if content.get("url") and content["url"] != article["link"] and "news.google.com" in article["link"]:
                article["link"] = content["url"]
                article["google"] = False
                self.store.save_articles()
            if content.get("blocks"):
                self.store.cache_reader(article["id"], content)
        newly_read = not self.store.is_read(article["id"])
        self.store.mark_read(article["id"])
        show_reader(article, content, self.store.mood(article))
        if newly_read:
            xbmc.executebuiltin("Container.Refresh")

    # ------------------------------------------------------------ Aktionen

    def act_bookmark(self):
        article = self.store.article(self.params.get("id", ""))
        if article:
            on = self.params.get("on") == "1"
            self.store.set_bookmark(article, on)
            if on:
                kodi.notify(L(S["bookmarked"]))
            xbmc.executebuiltin("Container.Refresh")

    def act_hide(self):
        article = self.store.article(self.params.get("id", ""))
        if article:
            on = self.params.get("on") == "1"
            self.store.set_hidden(article["id"], on)
            if on:
                kodi.notify(L(S["hidden_ok"]))
            xbmc.executebuiltin("Container.Refresh")

    def act_mute_source(self):
        article = self.store.article(self.params.get("id", ""))
        if article and article.get("source"):
            self.store.set_source_muted(article["source"], True)
            kodi.notify(L(S["muted"]) % article["source"])
            xbmc.executebuiltin("Container.Refresh")

    def act_mute_topic(self):
        article = self.store.article(self.params.get("id", ""))
        if article and article.get("topic"):
            self.store.set_topic_muted(article["topic"], True)
            kodi.notify(L(S["muted"]) % L(S[article["topic"]]))
            xbmc.executebuiltin("Container.Refresh")

    def act_not_cat(self):
        article = self.store.article(self.params.get("id", ""))
        if not article:
            return
        self.store.add_not_cat(article["title"])
        from catnewz import dedupe
        reported = dedupe.tokens(article["title"])
        for aid in [k for k, a in self.store.articles.items()
                    if k == article["id"] or dedupe.similar(dedupe.tokens(a["title"]), reported)]:
            if not self.store.is_bookmarked(aid):
                self.store.articles.pop(aid, None)
        self.store.save_articles()
        kodi.notify(L(S["hidden"]))
        xbmc.executebuiltin("Container.Refresh")

    def act_mood(self):
        article = self.store.article(self.params.get("id", ""))
        if not article:
            return
        current = self.store.mood(article)
        labels = [("» " if m == current else "") + L(S[m]) for m in MOODS]
        choice = xbmcgui.Dialog().select(L(S["fix_mood"]), labels, preselect=MOODS.index(current))
        if choice >= 0:
            self.store.set_mood(article["id"], MOODS[choice])
            kodi.notify(L(S["mood_set"]) % L(S[MOODS[choice]]))
            xbmc.executebuiltin("Container.Refresh")

    def act_search(self):
        term = xbmcgui.Dialog().input(L(S["search_term"]))
        if term and term.strip():
            self.show_list(self.url(action="list", query=term.strip()))

    def act_refresh(self):
        new_count = self.ensure_fresh(force=True)
        if new_count is not None:
            kodi.notify(L(S["loaded_new"]) % new_count if new_count else L(S["loaded_none"]))
        xbmc.executebuiltin("Container.Refresh")

    def act_stats(self):
        self.ensure_fresh()
        week = time.time() - 7 * 86400
        recent = [a for a in news.visible(self.store, self.config) if a.get("published", 0) >= week]
        moods = {m: 0 for m in MOODS}
        sources, topics = {}, {}
        for article in recent:
            moods[self.store.mood(article)] += 1
            sources[article.get("source", "")] = sources.get(article.get("source", ""), 0) + 1
            if article.get("topic"):
                topics[article["topic"]] = topics.get(article["topic"], 0) + 1
        total = max(1, len(recent))
        lines = ["[B]%s[/B]  (%d)" % (L(S["stats_week"]), len(recent)), ""]
        for mood in MOODS:
            share = moods[mood] * 100 // total
            bar = "█" * max(1, share // 4) if moods[mood] else ""
            lines.append("[COLOR %s]%-10s %s[/COLOR]  %d  (%d %%)" % (kodi.MOOD_COLORS[mood], L(S[mood]), bar,
                                                                     moods[mood], share))
        lines += ["", "[B]%s[/B]" % L(S["topics"])]
        for topic in TOPICS:
            lines.append("%s: %d" % (L(S[topic]), topics.get(topic, 0)))
        lines += ["", "[B]%s[/B]" % L(S["stats_sources"])]
        for source, count in sorted(sources.items(), key=lambda kv: kv[1], reverse=True)[:10]:
            lines.append("%s: %d" % (source, count))
        xbmcgui.Dialog().textviewer("Catnewz – %s" % L(S["stats"]), "\n".join(lines))

    def act_settings(self):
        kodi.addon().openSettings()

    # ------------------------------------------------------------ Quellen & „Weniger davon“

    def act_sources(self):
        """Quellen an- und abschalten (wie in den App-Einstellungen)."""
        language = self.config.language
        available = feeds.available(language, self.config.region, self.store.user.get("custom_feeds", []))
        disabled = set(self.store.user.get("disabled_feeds", []))
        labels = [feed.name for feed in available]
        preselect = [i for i, feed in enumerate(available) if feed.url not in disabled]
        chosen = xbmcgui.Dialog().multiselect(L(S["active_sources"]), labels, preselect=preselect)
        if chosen is None:
            return
        keep = set(available[i].url for i in chosen)
        other_languages = [url for url in disabled if url not in set(f.url for f in available)]
        self.store.user["disabled_feeds"] = other_languages + [f.url for f in available if f.url not in keep]
        self.store.save_user()
        self.mark_stale()
        kodi.notify(L(S["sources_saved"]))

    def act_add_source(self):
        dialog = xbmcgui.Dialog()
        url = (dialog.input(L(S["source_url"]), "https://") or "").strip()
        if not url or url == "https://":
            return
        default_name = url.split("/")[2] if "://" in url else url
        name = (dialog.input(L(S["source_name"]), default_name) or "").strip() or default_name
        cat_specific = dialog.yesno("Catnewz", L(S["source_cats"]))
        response = http.fetch(url, timeout=15, accept="application/rss+xml,application/xml,text/xml,*/*;q=0.8")
        count = len(rss.parse(response.text(), name)) if response.ok else 0
        if not count:
            dialog.ok("Catnewz", L(S["source_empty"]))
            return
        entries = [e for e in self.store.user.get("custom_feeds", []) if e.get("url") != url]
        entries.append({"name": name, "url": url, "language": self.config.language, "cat_specific": cat_specific})
        self.store.user["custom_feeds"] = entries
        self.store.save_user()
        self.mark_stale()
        kodi.notify(L(S["source_added"]) % count)

    def act_remove_sources(self):
        entries = self.store.user.get("custom_feeds", [])
        if not entries:
            kodi.notify(L(S["nothing_muted"]))
            return
        chosen = xbmcgui.Dialog().multiselect(L(S["remove_sources"]),
                                              ["%s  (%s)" % (e.get("name"), e.get("url")) for e in entries])
        if not chosen:
            return
        self.store.user["custom_feeds"] = [e for i, e in enumerate(entries) if i not in set(chosen)]
        self.store.save_user()
        self.mark_stale()
        kodi.notify(L(S["sources_saved"]))

    def act_manage_less(self):
        """Stummschaltungen einzeln zurücknehmen: abgewählte Einträge werden wieder gezeigt."""
        user = self.store.user
        entries = ([("source", s, L(S["less_source"]) % s) for s in user.get("muted_sources", [])]
                   + [("topic", t, L(S["topic_is"]) % L(S[t])) for t in user.get("muted_topics", []) if t in S]
                   + [("not_cat", t, L(S["less_notcat"]) % t) for t in user.get("not_cat", [])])
        if not entries:
            kodi.notify(L(S["nothing_muted"]))
            return
        chosen = xbmcgui.Dialog().multiselect(L(S["manage_less"]), [label for _, _, label in entries],
                                              preselect=list(range(len(entries))))
        if chosen is None:
            return
        keep = set(chosen)
        user["muted_sources"] = [v for i, (k, v, _) in enumerate(entries) if k == "source" and i in keep]
        user["muted_topics"] = [v for i, (k, v, _) in enumerate(entries) if k == "topic" and i in keep]
        user["not_cat"] = [v for i, (k, v, _) in enumerate(entries) if k == "not_cat" and i in keep]
        self.store.save_user()
        kodi.notify(L(S["reset_muted"]))

    def act_reset_muted(self):
        self.store.user["muted_sources"] = []
        self.store.user["muted_topics"] = []
        self.store.save_user()
        kodi.notify(L(S["reset_muted"]))

    def act_reset_notcat(self):
        self.store.user["not_cat"] = []
        self.store.save_user()
        kodi.notify(L(S["reset_notcat"]))

    def act_clear_cache(self):
        self.store.data["articles"] = {}
        self.store.data["last_refresh"] = 0
        self.store.save_articles()
        self.store.user["reader"] = {}
        self.store.save_user()
        kodi.notify(L(S["cache_cleared"]))

    def act_noop(self):
        pass

    def act_home(self):
        xbmc.executebuiltin("RunScript(plugin.program.catnewz)")

    # ------------------------------------------------------------ Router

    def dispatch(self):
        action = self.params.get("action", "")
        routes = {
            "": self.root, "topics": self.topics, "list": self.article_list, "read": self.read,
            "filter": self.act_filter, "bookmark": self.act_bookmark, "hide": self.act_hide,
            "mute_source": self.act_mute_source, "mute_topic": self.act_mute_topic,
            "not_cat": self.act_not_cat, "mood": self.act_mood, "search": self.act_search,
            "refresh": self.act_refresh, "stats": self.act_stats, "settings": self.act_settings,
            "sources": self.act_sources, "add_source": self.act_add_source,
            "remove_sources": self.act_remove_sources, "manage_less": self.act_manage_less,
            "reset_muted": self.act_reset_muted, "reset_notcat": self.act_reset_notcat,
            "clear_cache": self.act_clear_cache, "noop": self.act_noop, "home": self.act_home,
        }
        if action in routes and action not in QUIET_ACTIONS:
            kodi.meow()  # wie die App bei jeder Berührung – nur bei Klick-Aktionen, nie bei Widgets
        try:
            routes.get(action, self.root)()
        finally:
            if action in routes and action not in DIRECTORY_ACTIONS and self.handle >= 0:
                # Aus einem Widget aufgerufene Aktion (z. B. Filter): Kodi wartet sonst auf eine
                # Wiedergabe und bleibt im Busy-Fenster. „Nichts abzuspielen“ gibt es sofort frei.
                try:
                    xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
                except (RuntimeError, TypeError):
                    pass


def _set_info(item, title="", plot="", date_added=None, premiered=None, playcount=None, studio=""):
    """Video-Infos für Kodi 20+ (InfoTagVideo) mit Rückfall auf setInfo (Kodi 19)."""
    premiered_text = time.strftime("%Y-%m-%d", time.localtime(premiered)) if premiered else None
    if premiered:  # Datum für Kodis Sortierung „Datum“
        try:
            item.setDateTime(time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(premiered)))
        except (AttributeError, TypeError, RuntimeError):
            pass
    try:
        tag = item.getVideoInfoTag()
    except AttributeError:
        tag = None
    if tag is not None and hasattr(tag, "setPlot"):
        tag.setMediaType("video")
        tag.setTitle(title)
        tag.setPlot(plot)
        if date_added:
            tag.setDateAdded(date_added)
        if premiered_text:
            tag.setPremiered(premiered_text)
        if playcount is not None:
            tag.setPlaycount(playcount)
        if studio:
            tag.setStudios([studio])
        return
    info = {"mediatype": "video", "title": title, "plot": plot}
    if date_added:
        info["dateadded"] = date_added
    if premiered_text:
        info["premiered"] = premiered_text
        info["date"] = time.strftime("%d.%m.%Y", time.localtime(premiered))
    if playcount is not None:
        info["playcount"] = playcount
    if studio:
        info["studio"] = studio
    item.setInfo("video", info)


def show_reader(article, content, mood):
    """Eigenes Lese-Fenster (mit Bild); Rückfall auf Kodis Textansicht."""
    try:
        from catnewz import window
        window.show(article, content, mood)
    except Exception as error:  # noqa: BLE001 – Textansicht geht immer
        kodi.log("Lese-Fenster nicht verfügbar (%r) – Textansicht" % error, xbmc.LOGWARNING)
        xbmcgui.Dialog().textviewer(article["title"], reader_text(article, content, mood))


def reader_text(article, content, mood):
    lines = ["[COLOR %s]%s · %s[/COLOR]" % (kodi.MUTED, article.get("source", ""),
                                            kodi.time_label(article.get("published"))),
             "[COLOR %s]• %s[/COLOR]" % (kodi.MOOD_COLORS.get(mood), L(S[mood])), ""]
    blocks = (content or {}).get("blocks") or []
    if blocks:
        for kind, text in blocks:
            lines.append("[B][COLOR %s]%s[/COLOR][/B]" % (kodi.ACCENT, text) if kind == "h" else text)
            lines.append("")
    else:
        lines.append("[I]%s[/I]" % L(S["no_fulltext"]))
        lines.append("")
        lines.append(article.get("snippet") or "")
        lines.append("")
    also = article.get("also") or []
    if also:
        lines.append("[COLOR %s]%s: %s[/COLOR]" % (kodi.MUTED, L(S["also"]), ", ".join(a[0] for a in also)))
    lines.append("[COLOR %s]%s[/COLOR]" % (kodi.MUTED, L(S["original"]) % ((content or {}).get("url") or article["link"])))
    return "\n".join(lines)


def run(argv):
    Plugin(argv).dispatch()
