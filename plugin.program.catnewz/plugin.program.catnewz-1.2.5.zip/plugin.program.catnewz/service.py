# -*- coding: utf-8 -*-
"""Catnewz für Kodi – Hintergrunddienst: hält die Meldungen aktuell und
ergänzt Bilder/Teaser, damit sich das Plugin sofort öffnet."""
import os
import sys

_LIB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib")
if _LIB not in sys.path:
    sys.path.insert(0, _LIB)

from catnewz import service  # noqa: E402

if __name__ == "__main__":
    service.run()
