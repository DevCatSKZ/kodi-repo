# -*- coding: utf-8 -*-
"""Catnewz für Kodi – Einstieg: Startseite (Programme › Catnewz) oder Listen/Widgets (plugin://…)."""
import os
import sys

_LIB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib")
if _LIB not in sys.path:
    sys.path.insert(0, _LIB)

if __name__ == "__main__":
    if sys.argv and sys.argv[0].startswith("plugin://"):
        from catnewz import plugin  # noqa: E402
        plugin.run(sys.argv)
    else:
        from catnewz import home  # noqa: E402
        home.run(sys.argv)
